fun main() {
    val shifts = 6 % 5
    System.out.println(shifts)
}

