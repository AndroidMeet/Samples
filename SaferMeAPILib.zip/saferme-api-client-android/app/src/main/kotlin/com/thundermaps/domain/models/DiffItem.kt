package com.thundermaps.domain.models

interface DiffItem {
    val uniqueId: Any
}
