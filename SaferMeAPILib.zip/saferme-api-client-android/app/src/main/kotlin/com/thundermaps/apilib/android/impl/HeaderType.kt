package com.thundermaps.apilib.android.impl

internal object HeaderType {
    const val xInstallationId = "X-InstallationID"
    const val xAppId = "X-AppID"
    const val xTeamId = "X-TeamID"
}
