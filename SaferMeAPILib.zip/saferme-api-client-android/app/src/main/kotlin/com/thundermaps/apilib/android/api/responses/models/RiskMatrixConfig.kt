package com.thundermaps.apilib.android.api.responses.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport

@ExcludeFromJacocoGeneratedReport
data class RiskMatrixConfig(
    @Expose val id: Int? = 0,
    @Expose val likelihoods: List<Likelihood> = ArrayList(),
    @Expose val severities: List<Severity> = ArrayList(),
    @SerializedName("risk_levels") @Expose val riskLevels: List<RiskLevel> = ArrayList()
)
