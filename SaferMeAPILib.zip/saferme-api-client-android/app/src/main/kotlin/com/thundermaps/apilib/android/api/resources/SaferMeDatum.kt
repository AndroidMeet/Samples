package com.thundermaps.apilib.android.api.resources

/* Super type for all 'data' resources */
interface SaferMeDatum
