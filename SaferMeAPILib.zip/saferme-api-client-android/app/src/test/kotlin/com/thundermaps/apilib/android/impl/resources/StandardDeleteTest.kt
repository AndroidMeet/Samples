package com.thundermaps.apilib.android.impl.resources

import android.util.Log
import com.thundermaps.apilib.android.api.requests.SaferMeApiError
import com.thundermaps.apilib.android.api.requests.SaferMeApiStatus
import com.thundermaps.apilib.android.impl.AndroidClient
import com.thundermaps.apilib.android.impl.resources.TestHelpers.Companion.testClient
import com.thundermaps.apilib.android.impl.resources.TestHelpers.Companion.testCreateRequest
import com.thundermaps.apilib.android.impl.resources.TestHelpers.Companion.testDeleteRequest
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.http.ContentType
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.http.headersOf
import io.ktor.util.KtorExperimentalAPI
import io.ktor.util.toMap
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.impl.annotations.MockK
import io.mockk.mockkStatic
import java.util.Random
import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Tests for the StandardMethod.create Method
 */
class StandardDeleteTest {

    @MockK
    lateinit var defaultAPI: AndroidClient

    @Before
    fun setUp() {
        MockKAnnotations.init(this)
        mockkStatic(Log::class)
        every { Log.v(any(), any()) } returns 0
        every { Log.d(any(), any()) } returns 0
        every { Log.i(any(), any()) } returns 0
        every { Log.e(any(), any()) } returns 0
    }

    /**
     * GENERAL HTTP TESTS
     * These test check that the StandardMethods 'Create' will construct the right
     * request when given various options
     */

    /** Test for correct HTTP Method Call **/
    @KtorExperimentalAPI
    @Test
    fun testDeleteHTTPMethod() {
        var called = false
        testDeleteRequest(api = defaultAPI, client = testClient(requestInspector = {
            assertEquals(it.method, HttpMethod.Delete)
            called = true
        }))
        assertTrue(called)
    }

    /**
     * Test the correct host is used
     */
    @KtorExperimentalAPI
    @Test
    fun testDeleteHost() {
        var called = false
        val testHost = "TestHostString"
        val params = TestHelpers.defaultParams.copy(host = testHost)
        testCreateRequest(
            api = defaultAPI,
            client = testClient(requestInspector = {
                assertEquals(it.url.host, testHost)
                called = true
            }),
            params = params
        )
        assertTrue(called)
    }

    /**
     * Test the correct path is used
     */
    @KtorExperimentalAPI
    @Test
    fun testDeletePath() {
        var called = false
        val testPath = "Some/Test/Path"
        val version = Random().nextInt(999)
        val params = TestHelpers.defaultParams.copy(api_version = version)
        val expectedPath = "/api/v$version/$testPath" // '/api/v' prefix automatically applied
        testDeleteRequest(
            api = defaultAPI,
            path = testPath,
            params = params,
            client = testClient(requestInspector = {
                assertEquals(it.url.encodedPath, expectedPath)
                called = true
            }
        ))
        assertTrue(called)
    }

    /**
     * Test the correct port is used
     */
    @KtorExperimentalAPI
    @Test
    fun testDeletePort() {
        var called = false
        val testPort = Random().nextInt(65535)
        val params = TestHelpers.defaultParams.copy(port = testPort)
        testDeleteRequest(
            api = defaultAPI,
            params = params,
            client = testClient(requestInspector = {
                assertEquals(it.url.port, testPort)
                called = true
            }
        ))
        assertTrue(called)
    }

    /**
     * Test Request Builder is correctly applied
     */
    @KtorExperimentalAPI
    @Test
    fun testRequestBuilderHeaders() {
        var called = false
        val name = "A_Random-TestName"
        val value = "ARandom-Test_Value!"
        val builder = HttpRequestBuilder().apply {
            headers.append(name, value)
        }

        testDeleteRequest(
            api = defaultAPI,
            httpRequestBuilder = builder,
            client = testClient(requestInspector = {
                assertTrue(it.headers.contains(name))
                assertEquals(it.headers[name], value)
                called = true
            }
        ))

        assertTrue(called)
    }

    /**
     * CREATE Functional Tests
     * These tests check that the StandardMethods 'Delete' will construct the right
     * kind of object(s) for different responses, and will call the right callbacks.
     */

    /**
     * Test the the success callback is called with the correct data transformed from the HTTP Response
     */
    @KtorExperimentalAPI
    @Test
    fun testDeleteSuccess() {
        var successLambdaCalls = 0
        var failLambdaCalls = 0
        val returnObject = GenericTestObject.random().toJsonString()
        val responseHeaders = headersOf("Content-Type" to listOf(ContentType.Application.Json.toString()))

        val client = testClient(
            content = returnObject,
            status = HttpStatusCode.Accepted,
            headers = responseHeaders
        )

        testDeleteRequest(
            api = defaultAPI,
            client = client,
            success = {
            synchronized(successLambdaCalls) {
                successLambdaCalls++
            }
            // Correct status type
            assertEquals(it.serverStatus, SaferMeApiStatus.ACCEPTED)
            // Response object captures all the headers in the response
            assertEquals(it.responseHeaders, responseHeaders.toMap())
        }, failure = {
            synchronized(failLambdaCalls) { failLambdaCalls++ }
        })

        // Ensure callbacks called the correct number of times
        assertEquals(successLambdaCalls, 1)
        assertEquals(failLambdaCalls, 0)
    }

    /**
     * Test that a valid request with an unexpected response generates the correct
     * API Exception with useful data. this is non-exceptional because no actual Exception
     * is involved, just an unexpected response
     */
    @KtorExperimentalAPI
    @Test
    fun testDeleteNonExceptionFailure() {
        // Client response data:
        val responseHeaders = headersOf("Content-Type" to listOf(ContentType.Application.Json.toString()))
        val returnObject = GenericTestObject.random()
        val status = HttpStatusCode.UnprocessableEntity

        var successLambdaCalls = 0
        var failLambdaCalls = 0

        val client = testClient(
            headers = responseHeaders,
            content = returnObject.toJsonString(),
            status = status
        )

        testDeleteRequest(
            api = defaultAPI,
            client = client,
            success = { synchronized(successLambdaCalls) { successLambdaCalls++ } },
            failure = {
                    synchronized(failLambdaCalls) { failLambdaCalls++ }

                    // We should get a SaferMeApiError Class
                    assertEquals(it::class, SaferMeApiError::class)
                    val error = it as SaferMeApiError

                    // Correct status code
                    assertEquals(error.serverStatus, SaferMeApiStatus.statusForCode(HttpStatusCode.UnprocessableEntity.value))

                    // Correct response headers
                    assertEquals(error.responseHeaders, responseHeaders.toMap())
        })

        // Ensure callbacks called the correct number of times
        assertEquals(successLambdaCalls, 0)
        assertEquals(failLambdaCalls, 1)
    }

        // Call the delete method and test the result is correct

    /**
     * Test that a thrown exception will call the failure callback and provide the exception
     */
    @KtorExperimentalAPI
    @Test
    fun testDeleteExceptionFailure() {
        // Keep a count of how many times the success and fail handlers are called

        var successLambdaCalls = 0
        var failLambdaCalls = 0

        val errorMessage = "A Test Error Message"

        val client = testClient(requestInspector = { throw Exception(errorMessage) })

        testDeleteRequest(
            api = defaultAPI,
            client = client,
            success = { synchronized(successLambdaCalls) { successLambdaCalls++ } },
            failure = {
                synchronized(failLambdaCalls) { failLambdaCalls++ }

                // We should get a SaferMeApiError Class
                assertEquals(it.message, errorMessage)
            })

        // Ensure callbacks called the correct number of times
        assertEquals(successLambdaCalls, 0)
        assertEquals(failLambdaCalls, 1)
    }
}
