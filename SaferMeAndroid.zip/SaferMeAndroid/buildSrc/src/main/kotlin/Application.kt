object Application {
    const val saferMeId = "com.thundermaps.saferme"
    const val smartOysters = "com.thundermaps.smartoysters"
    const val testId = "com.thundermaps.saferme.tests"
}
