object Constants {
    val projectMap = mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))

    const val DEFAULT_VERSION_NAME = "1"
    const val DEFAULT_VERSION_CODE = 1

    const val GROUP = "Reporting"
    const val CREATE_DIST = "createDist"
    const val JACOCO_DEBUG_TEST_REPORT = "jacocoDebugTestReport"
    const val VERSION_NAME = "versionName"
    const val VERSION_CODE = "versionCode"
    const val TEST_COVERAGE_ENABLED = "testCoverageEnabled"
    const val RETRIEVE_TEST_COVERAGE_ENABLED = "retrieveTestCoverageEnabled"
    const val TEST_RUNNER = "com.thundermaps.saferme.CustomTestRunner"
    const val TEST = "test"
    const val TEST_DEBUG_UNIT_TEST = "testDebugUnitTest"
    const val CONNECTED_DEBUG_ANDROID_TEST = "connectedDebugAndroidTest"
    const val CREATED_DEBUG_COVERAGE_REPORT = "createDebugCoverageReport"
    const val TEST_SAFER_ME_DEBUG_UNIT_TEST = "testSafermeDebugUnitTest"
    const val CONNECTED_SAFER_ME_DEBUG_ANDROID_TEST = "connectedSafermeDebugAndroidTest"
    const val CREATED_SAFER_ME_DEBUG_COVERAGE_REPORT = "createSafermeDebugCoverageReport"
    const val JACOCO_ANDROID_VERIFICATION = "jacocoAndroidCoverageVerification"
}
