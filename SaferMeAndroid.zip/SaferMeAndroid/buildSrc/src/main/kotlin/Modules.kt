object Modules {
    const val app = ":app"
}
