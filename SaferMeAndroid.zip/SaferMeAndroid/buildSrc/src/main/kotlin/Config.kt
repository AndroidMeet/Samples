object Config {
    object Dependencies {
        const val androidPlugin = "com.android.tools.build:gradle:${Versions.gradle}"
        const val firebaseCrashlytics = "com.google.firebase:firebase-crashlytics-gradle:${Versions.firebaseCrashlyticsGradle}"
        const val googleService = "com.google.gms:google-services:${Versions.googleService}"
        const val hilt = "com.google.dagger:hilt-android-gradle-plugin:${Versions.hilt}"
        const val kotlinPlugin = "gradle-plugin"
        const val navigationSafeArgs = "androidx.navigation:navigation-safe-args-gradle-plugin:${Versions.navigation}"
        const val jacoco = "org.jacoco:org.jacoco.core:${Versions.jacoco}"
        const val kotlinSerialization = "serialization"
        const val spotless = "com.diffplug.spotless:spotless-plugin-gradle:${Versions.spotless}"
    }

    object PluginIds {
        const val android = "com.android.application"
        const val androidLibrary = "com.android.library"
        const val javaLibrary = "java-library"
        const val kotlin = "kotlin"
        const val kapt = "kotlin-kapt"
        const val hilt = "dagger.hilt.android.plugin"
        const val kotlinAndroid = "kotlin-android"
        const val kotlinParcelize = "kotlin-parcelize"
        const val fireBaseCrashlytics = "com.google.firebase.crashlytics"
        const val googleService = "com.google.gms.google-services"
        const val jacoco = "jacoco"
        const val kotlinxSerialization = "kotlinx-serialization"
        const val navigation = "androidx.navigation.safeargs.kotlin"
        const val spotless = "com.diffplug.gradle.spotless"
    }

    object Repositories {
        const val gradleMaven = "https://plugins.gradle.org/m2/"
        const val saferMeMaven = "https://maven.pkg.github.com/SaferMe/obsidian-service-android"
        const val mapboxMaven = "https://api.mapbox.com/downloads/v2/releases/maven"
        const val jitpack = "https://jitpack.io"
        const val googleSupport = "https://maven.google.com"
    }
}
