import java.io.FileInputStream
import java.io.FileNotFoundException
import java.util.Properties

object Maven {
    private const val GPR_LOCAL_KEY = "gpr.key"
    private const val GPR_LOCAL_USER = "gpr.user"
    private const val MAPBOX_LOCAL_DOWNLOAD_TOKEN = "mapbox_download_token"

    private const val GPR_ENV_KEY = "GPR_KEY"
    private const val GPR_ENV_USER = "GPR_USER"
    private const val MAPBOX_ENV_DOWNLOAD_TOKEN = "MAPBOX_DOWNLOAD_TOKEN"
    private const val DEFAULT_VALUE = "unspecified"

    private const val LOCAL_PROPERTIES_PATH = "buildSrc/local.properties"

    private val localProperties: Properties by lazy {
        Properties().apply {
            try {
                this.load(FileInputStream(LOCAL_PROPERTIES_PATH))
            } catch (ex: FileNotFoundException) {
                this.setProperty(GPR_LOCAL_USER, DEFAULT_VALUE)
                this.setProperty(GPR_LOCAL_KEY, DEFAULT_VALUE)
                this.setProperty(MAPBOX_LOCAL_DOWNLOAD_TOKEN, DEFAULT_VALUE)
            }
        }
    }

    val gprUser: String = when {
        System.getenv().containsKey(GPR_ENV_USER) -> System.getenv(GPR_ENV_USER)
        localProperties.containsKey(GPR_LOCAL_USER) -> localProperties.getProperty(GPR_LOCAL_USER).trim()
        else -> DEFAULT_VALUE
    }

    val gprKey: String = when {
        System.getenv().containsKey(GPR_ENV_KEY) -> System.getenv(GPR_ENV_KEY)
        localProperties.containsKey(GPR_LOCAL_KEY) -> localProperties.getProperty(GPR_LOCAL_KEY).trim()
        else -> DEFAULT_VALUE
    }

    const val mapboxUser = "mapbox"

    val mapboxDownloadToken: String = when {
        System.getenv().containsKey(MAPBOX_ENV_DOWNLOAD_TOKEN) -> System.getenv(MAPBOX_ENV_DOWNLOAD_TOKEN)
        localProperties.containsKey(MAPBOX_LOCAL_DOWNLOAD_TOKEN) -> localProperties.getProperty(MAPBOX_LOCAL_DOWNLOAD_TOKEN).trim()
        else -> DEFAULT_VALUE
    }
}
