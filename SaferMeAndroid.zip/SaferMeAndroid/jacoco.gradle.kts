apply(plugin = Config.PluginIds.jacoco)

tasks.withType<Test> {
    configure<JacocoTaskExtension> {
        isIncludeNoLocationClasses = true
        excludes = listOf("jdk.internal.*")
    }
}

val fileFilter = listOf(
    "**/R.class",
    "**/R\$*.class",
    "**/BuildConfig.*",
    "**/Manifest*.*",
    "**/*Test*.*",
    "android/**/*.*",
    "**/*\$Lambda$*.*",
    "**/*\$inlined$*.*",
    "**/*Application*.*",
    //Lifecycle-generated Classes
    "**/*_LifecycleAdapter*.*",
    //ButterKnife-generated Classes
    "**/*_ViewBinding*.*",
    //Dagger-Generated Classes
    "**/*_MembersInjector*.*",
    "**/*_Factory*.*",
    "**/*Dagger*.*",
    "**/*Module*.*",
    "**/*Component*.*",
    "**/*Scope.*",
    //Hilt
    "**/hilt_aggregated_deps/*.class",
    "**/dagger/hilt/internal/**/*",
    "**/dagger/hilt/internal/**/*.*",
    "**/Hilt_\$*.*",
    "**/_HiltComponents*.*",
    "**/DataBinder*.*",
    "**/Hilt_SaferMeApplication*.*",
    "**/di/*.*",
    //Android Components
    "**/*Retrofit*.*",
    "**/*Fragment*.*",
    "**/*BottomModal*.*",
    "**/*Activity*.*",
    "**/*Dialog*.*",
    "**/*Service*.*",
    "**/*Receiver*.*",
    "**/*Adapter*.*",
    "**/*ViewHolder*.*",
    //data binding
    "**/com/thundermaps/saferme/databinding/*",
    "**/*Binding*.*",
    "**/databinding/\$*Binding\$*.class",
    "**/android/databinding/*.*",
    "**/androidx/databinding/*.*",
    "**/*Binding*.*",
    "**/*BR*.*",
    "**/databinding/*",
    "**/*\$ViewBinder*.*",
    //Exceptions
    "**/*Exception.class",
    //Extensions
    "**/*ExtensionsKt.*",
    "**/extensions/*",
    //Debug
    "**/*Debug*.class",
    "**/debugviews/**/*.class",
    //Views
    "**/ui/views/*.class",
    "**/*Watcher.*",
    "**/*Watcher.new",
    "**/widgets/*.*",
    "**/com/thundermaps/saferme/*.*",
    "**/OnClickListener*"
)

fun getClassDirectories(project: Project) = listOf(
    fileTree("${project.buildDir}/intermediates/javac/safermeDebug") {
        setExcludes(fileFilter)
    },
    fileTree("${project.buildDir}/intermediates/javac/debug") {
        setExcludes(fileFilter)
    },
    fileTree("${project.buildDir}/tmp/kotlin-classes/safermeDebug") {
        setExcludes(fileFilter)
    },
    fileTree("${project.buildDir}/tmp/kotlin-classes/debug") {
        setExcludes(fileFilter)
    },
    fileTree("${project.buildDir}/classes") {
        setExcludes(fileFilter)
    }
)

fun getSourceDirectories(project: Project) = listOf(
    fileTree("${project.buildDir}") {
        include(
            "src/main/java/**",
            "src/saferme/java/**",
            "src/saferme/kotlin/**",
            "src/main/kotlin/**",
        )
        setExcludes(fileFilter)
    }
)

fun getExecutionData(project: Project) = listOf(fileTree(project.buildDir) {
    include(
        listOf(
            "outputs/code_coverage/safermeDebugAndroidTest/connected/**/coverage.ec",
            "outputs/code_coverage/debugAndroidTest/connected/**/*coverage.ec",
            "**/safermeDebugUnitTest/*.exec"
        )
    )
})

fun JacocoReportsContainer.reports() {
    xml.isEnabled = true
    html.isEnabled = true
    html.destination = file("${buildDir}/reports/jacoco/jacocoTestReport/html")
}

fun JacocoReport.setDirectories() {
    if (project == rootProject) {
        dependsOn(subprojects.map { "${it.name}:${Constants.JACOCO_DEBUG_TEST_REPORT}" })
        classDirectories.setFrom(subprojects.map { getClassDirectories(it) }.flatten())
        sourceDirectories.setFrom(subprojects.map { getSourceDirectories(it) }.flatten())
        executionData.setFrom(subprojects.map { getExecutionData(it) }.flatten())
    } else {
        // Need to add depends on in each sub-project's build.gradle.kts
        classDirectories.setFrom(getClassDirectories(project))
        sourceDirectories.setFrom(getSourceDirectories(project))
        executionData.setFrom(getExecutionData(project))
    }
}

if (tasks.findByName(Constants.JACOCO_DEBUG_TEST_REPORT) == null) {
    tasks.register(Constants.JACOCO_DEBUG_TEST_REPORT, JacocoReport::class) {
        group = Constants.GROUP
        description = "Generate Jacoco coverage reports"

        reports {
            reports()
        }

        setDirectories()
    }
}

if (tasks.findByName(Constants.CREATE_DIST) == null) {
    tasks.register(Constants.CREATE_DIST, Zip::class) {
        archiveName = "coverage.zip"
        destinationDir = File("build/reports/jacoco/jacocoDebugTestReport")
        from(files("./build/reports/jacoco/jacocoTestReport/html"))
        println(destinationDir.absolutePath)
    }
}

fun JacocoCoverageVerification.setDerectories() {
    if (project == rootProject) {
        dependsOn(subprojects.map { "${it.name}:${Constants.JACOCO_DEBUG_TEST_REPORT}" })
        classDirectories.setFrom(subprojects.map { getClassDirectories(it) }.flatten())
        sourceDirectories.setFrom(subprojects.map { getSourceDirectories(it) }.flatten())
        executionData.setFrom(subprojects.map { getExecutionData(it) }.flatten())
    } else {
        // Need to add depends on in each sub-project's build.gradle.kts
        classDirectories.setFrom(getClassDirectories(project))
        sourceDirectories.setFrom(getSourceDirectories(project))
        executionData.setFrom(getExecutionData(project))
    }
}

if (tasks.findByName(Constants.JACOCO_ANDROID_VERIFICATION) == null) {
    tasks.register(Constants.JACOCO_ANDROID_VERIFICATION, JacocoCoverageVerification::class) {
        group = Constants.GROUP
        description = "Code coverage verification for Android both Android and Unit tests."
        dependsOn(subprojects.map { "${it.name}:${Constants.JACOCO_DEBUG_TEST_REPORT}" })
        setDerectories()
    }
}
