buildscript {
    repositories {
        google()
        mavenCentral()
//        mavenLocal()
    }
    
    dependencies {
        classpath(Config.Dependencies.androidPlugin)
        classpath(kotlin(Config.Dependencies.kotlinPlugin, Versions.kotlin))
        classpath(Config.Dependencies.jacoco)
        classpath(Config.Dependencies.hilt)
        classpath(Config.Dependencies.firebaseCrashlytics)
        classpath(Config.Dependencies.navigationSafeArgs)
        classpath(Config.Dependencies.googleService)
        classpath(Config.Dependencies.spotless)
        classpath(kotlin(Config.Dependencies.kotlinSerialization, Versions.kotlin))
    }
}

fun retrieveTestCoverageEnabled() = if (project.hasProperty(Constants.TEST_COVERAGE_ENABLED)) {
    project.ext[Constants.TEST_COVERAGE_ENABLED].toString().toBoolean()
} else {
    true
}

allprojects {
    ext {
        set(Constants.RETRIEVE_TEST_COVERAGE_ENABLED, retrieveTestCoverageEnabled())
    }
    apply(from = "${rootProject.projectDir}/spotless.gradle")
    repositories {
        google()
        mavenCentral()
//        mavenLocal()
        maven(
            url = Config.Repositories.saferMeMaven,
            action = {
                credentials {
                    username = Maven.gprUser
                    password = Maven.gprKey
                }
            }
        )
        maven(
            url = Config.Repositories.mapboxMaven,
            action = {
                authentication {
                    create("basic", BasicAuthentication::class.java)
                }
                credentials {
                    username = Maven.mapboxUser
                    password = Maven.mapboxDownloadToken
                }
            }
        )
        maven (url = Config.Repositories.jitpack)
    }
}

subprojects {
    configurations.all {
        resolutionStrategy {
            eachDependency {
                if ("org.jacoco" == requested.group) {
                    useVersion(Versions.jacoco)
                }
            }
        }
    }
}
