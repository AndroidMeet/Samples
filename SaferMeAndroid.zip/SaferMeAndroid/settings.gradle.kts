object Modules {
    const val app = ":app"
}

include(
    Modules.app
)
