# Create a snapshot in case we need to recover
lokalise2 \
snapshot create \
--title Backup \
--token $LOKALISE_TOKEN \
--project-id $LOKALISE_ANDROID_PROJECT_ID

# Upload the english strings file
lokalise2 \
file upload \
--token $LOKALISE_TOKEN \
--project-id $LOKALISE_ANDROID_PROJECT_ID \
--lang-iso en \
--cleanup-mode \
--replace-modified \
--file ../app/src/main/res/values/strings.xml