lokalise2 \
    --token $LOKALISE_TOKEN \
    --project-id $LOKALISE_ANDROID_PROJECT_ID \
    file download \
    --replace-breaks false \
    --format xml \
    --export-empty-as skip \
