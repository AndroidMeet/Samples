# Useful knowledge for development

## Github

This library is dependent on Github Packages, you will need to configure the environment with credentials that have access
to these packages.

1. Generate a token that has 'read packages' permission here:
   <https://github.com/settings/tokens>
2. Configure either local.properties or environment variable:
`buildSrc/local.properties`
gpr.user=GITHUB_USERNamE
gpr.key=TOKEN

## Mapbox
Add the mapbox download key value from 1Password to the `buildSrc/local.properties`
mapbox_download_token=MAPBOX_DOWNLOAD_TOKEN
## Brand build

* Set build variants for different brand

## Local Properties
If you hvae set ANDROID_HOME as an environment variable, this is not required

* Create a file `local.properites` in the root project directory (This is different from the one in buildSrc).
* Set the sdk.dir variable to the location of the Andeoid SDK

## Format code

* `./gradlew spotlessApply` apply the code format
* `./gradlew spotlessCheck` check the code format

## Code coverage report

* Enable code coverage in the gradle.properties `testCoverageEnabled=true`
* Run from command line `./gradlew clean jacocoDebugTestReport createSaferMeDebugCoverageReport`
* Check the result `build/reports/jacoco/jacocoDebugTestReport/html/index.html`

## Translation

Setup

-----

A couple of things need to be done to setup Lokalise:

1. Install the Lokalise CLI:

```bash
brew tap lokalise/cli-2
brew install lokalise2
```

2. Create a .envrc file in the root directory of the project and add the following to it:

```bash
export LOKALISE_TOKEN=<token>
export LOKALISE_ANDROID_PROJECT_ID=<project-id>
```

These environment variables can be obtained through 1Password.

To pull fresh translations:

```bash
cd scripts
./PullTranslations.sh
```

To push the default language `app/src/main/res/values/strings.xml`

```bash
cd scripts
./PushTranslations.sh
```

## Lintint

Apply lint: `./gradlew spotlessApply`

Check lint: `./gradlew spotlessCheck`


---
<!-- LICENSE -->
## License

As per the LICENSE.

Copyright (c) 2021 SaferMe. All rights reserved.

<!-- CONTACT -->
## Contact

Contact support:
* [Website](https://www.safer.me) - https://www.safer.me/
* [Email](mailto:support@safer.me) - support@safer.me

Project Link: [https://github.com/SaferMe/SaferMeAndroid](https://github.com/SaferMe/SaferMeAndroid)
