package com.thundermaps.saferme.features.main.reportdetails.tasks

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.TaskManager
import com.saferme.obsidian.authentication.SessionsManager
import com.saferme.obsidian.store.resources.ObsidianTeamUser
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.Date
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
@ExcludeFromJacocoGeneratedReport
class TasksTabViewModel @Inject constructor(
    app: SaferMeApplication,
    obsidianApi: ObsidianApi,
    private val taskManager: TaskManager,
    private val sessionsManager: SessionsManager,
    private val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private val _tasks = MediatorLiveData<List<TaskCardData>>()
    val tasks: LiveData<List<TaskCardData>> = _tasks

    private val teamManager = obsidianApi.teamManager

    fun loadTaskOfReport(reportId: String) {
        val userId = sessionsManager.userDetails?.id?.toInt() ?: return
        _tasks.addSource(
            taskManager.readReportTask(userId = userId, reportId = reportId)
        ) { tasks ->
            viewModelScope.launch(dispatcherContext.io) {
                val teamUsers = teamManager.getTeamsUsers()
                val allTask = tasks?.map { task ->
                    val assigneeUser = teamUsers.firstOrNull {
                        it.userId.toInt() == task.assignee_id
                    }
                    val creatorUser = teamUsers.firstOrNull {
                        it.userId.toInt() == task.creator_id
                    }
                    TaskCardData.of(
                        task,
                        assigneeUser?.fullName,
                        creatorUser?.fullName
                    )
                }
                applyFilter(allTask)
            }
        }
    }

    private fun applyFilter(allTask: List<TaskCardData>?) {
        val incompleteTasks = allTask?.filter { it.completedDate == null }
            ?.sortedByDescending { it.createdDate }
        val completedTasks = allTask?.filter { it.completedDate != null }
            ?.sortedByDescending { it.completedDate }
        val newTasks = mutableListOf<TaskCardData>()
        incompleteTasks?.let { newTasks.addAll(it) }
        completedTasks?.let { newTasks.addAll(it) }
        _tasks.postValue(newTasks)
    }

    fun markAsComplete(item: TaskCardData) {
        viewModelScope.launch(dispatcherContext.io) {
            val task = item.copy(completedDate = Date())
            taskManager.update(TaskCardData.toObsidian(task))
            updateTaskItem(task)
        }
    }

    fun updateTaskItem(task: TaskCardData) {
        _tasks.value?.let { taskList ->
            val updatedList: MutableList<TaskCardData> = taskList.toMutableList()
            val index = updatedList.indexOf(task)
            if (index >= 0) {
                updatedList[index] = task
            } else {
                updatedList.add(task)
            }
            applyFilter(updatedList)
        }
    }

    private val ObsidianTeamUser?.fullName: String
        get() = toString()
}
