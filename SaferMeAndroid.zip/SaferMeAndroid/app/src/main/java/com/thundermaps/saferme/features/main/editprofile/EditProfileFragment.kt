package com.thundermaps.saferme.features.main.editprofile

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentEditProfileBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class EditProfileFragment : BaseFragment<FragmentEditProfileBinding, EditProfileViewModel>() {
    override val viewModel: EditProfileViewModel by viewModels()
    override fun provideLayoutId(): Int = R.layout.fragment_edit_profile

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.fetchUserDetails()
        viewModel.saveUserProfile.observe(viewLifecycleOwner) {
            if (it) {
                findNavController().popBackStack()
            }
        }
        binding.emailEdittext.setOnFocusChangeListener { _, hasFocus ->
            viewModel.updateCanDisplayEmailError(!hasFocus)
        }
        binding.contactNumberEdittext.setOnFocusChangeListener { _, hasFocus ->
            viewModel.updateCanDisplayContactError(!hasFocus)
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }
}
