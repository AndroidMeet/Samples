package com.thundermaps.saferme.core.ui.input

import androidx.lifecycle.LiveData

interface InputInterface {
    val title: String
    val error: LiveData<String?>
    val isError: Boolean
    fun showError(error: String?)
    fun clearError()
}
