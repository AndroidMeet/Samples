package com.thundermaps.saferme.features.main.settings.models

data class SettingsItemData(
    val title: String?,
    val drawable: Int?
)
