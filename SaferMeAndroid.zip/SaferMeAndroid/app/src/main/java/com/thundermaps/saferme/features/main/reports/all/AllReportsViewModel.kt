package com.thundermaps.saferme.features.main.reports.all

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.saferme.obsidian.ReportManager
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.features.main.reports.common.BaseReportsViewModel
import com.thundermaps.saferme.features.main.reports.domain.model.CardData
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class AllReportsViewModel @Inject constructor(
    app: SaferMeApplication,
    private val reportManager: ReportManager
) : BaseReportsViewModel(app) {
    override fun getReports(): LiveData<List<CardData>> =
        reportManager.readAll().let { liveData ->
            Transformations.map(liveData) { reports ->
                reports.map { CardData.of(it, anonymous) }.sortedByDescending { it.date }
            }
        }
}
