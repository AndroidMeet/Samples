package com.thundermaps.saferme.features.main.tasks.domain.model

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.saferme.obsidian.Provider
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class CreateTaskData(
    @Expose val uuid: String,
    @Expose val task: TaskCardData?
) : Parcelable {
    @ExcludeFromJacocoGeneratedReport
    fun toJson(): String = Provider.gson.toJson(this)

    companion object {
        @ExcludeFromJacocoGeneratedReport
        fun of(json: String): CreateTaskData = Provider.gson.fromJson(
            json,
            CreateTaskData::class.java
        )
    }
}
