package com.thundermaps.saferme.features.main.reportdetails.details

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.core.view.children
import androidx.fragment.app.viewModels
import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.getFormFields
import com.thundermaps.apilib.android.api.responses.models.FieldType
import com.thundermaps.apilib.android.api.responses.models.FormField
import com.thundermaps.apilib.android.api.responses.models.FormValue
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.extensions.dpToPx
import com.thundermaps.saferme.core.ui.extensions.loadData
import com.thundermaps.saferme.core.ui.extensions.marginTop
import com.thundermaps.saferme.core.ui.extensions.removeFromParent
import com.thundermaps.saferme.core.ui.extensions.setTheme
import com.thundermaps.saferme.databinding.FragmentReportDetailsTabBinding
import com.thundermaps.saferme.databinding.ViewHeaderContainerBinding
import com.thundermaps.saferme.databinding.ViewPhotoBinding
import com.thundermaps.saferme.databinding.ViewWebviewContainerBinding
import com.thundermaps.saferme.features.main.createreport.adapter.PhotoAdapter
import com.thundermaps.saferme.features.main.photoviewer.PhotoViewerData
import com.thundermaps.saferme.features.main.reportdetails.ReportDetailsFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ReportDetailsTabFragment :
    BaseFragment<FragmentReportDetailsTabBinding, ReportDetailsTabViewModel>() {
    override val viewModel: ReportDetailsTabViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_report_details_tab
    private lateinit var inflater: LayoutInflater
    private val container get() = binding.container

    private val wrapContentHeightParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private val viewHeaderContainerBinding get() = ViewHeaderContainerBinding.inflate(inflater)

    private val categoryViewBinding by lazy {
        viewHeaderContainerBinding.also {
            it.header.setText(R.string.field_type_category)
            it.valueText.setLineSpacing(4.dpToPx(), 1.2f)
        }
    }

    private val dateAndTimeViewBinding by lazy {
        viewHeaderContainerBinding.also {
            it.header.setText(R.string.field_date_and_time)
        }
    }

    private val reportIdViewBinding by lazy {
        viewHeaderContainerBinding
    }

    private val viewPhotoBinding by lazy {
        ViewPhotoBinding.inflate(inflater)
    }

    private val viewWebViewContainerBinding by lazy {
        ViewWebviewContainerBinding.inflate(inflater)
    }

    private val photoAdapter by lazy {
        PhotoAdapter(false).also { adapter ->
            adapter.updateInterface(object : ItemInterface {
                override fun <T : Any> onItemSelected(item: T) {
                    (item as? PhotoItem)?.let {
                        val position = viewModel.photoItems.indexOf(it)
                        (parentFragment as? ReportDetailsFragment)?.openPhotoViewer(
                            PhotoViewerData(position, viewModel.photoItems)
                        )
                    }
                }
            })
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        this.inflater = inflater
        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateViews()
    }
    override fun onResume() {
        super.onResume()
        actionController?.hideToolBar()
    }

    fun setReport(report: ObsidianReport) {
        viewModel.setReport(report)
    }

    private fun updateViews() {
        viewModel.report.observe(viewLifecycleOwner) { report ->
            container.removeAllViews()
            viewModel.dateTimeValue?.let {
                container.addViewWithTryCatch(dateAndTimeViewBinding.root)
                dateAndTimeViewBinding.valueText.text = it
            }

            report.getFormFields?.sortedBy { it.formOrder }?.forEach { formField ->
                when (formField.fieldType) {
                    FieldType.Category -> {
                        container.addViewWithTryCatch(categoryViewBinding.root)
                        viewModel.getCategories()?.observe(viewLifecycleOwner) { categories ->
                            (formField.value as? FormValue.ValueInt)?.value?.let { id ->
                                categoryViewBinding.valueText.text =
                                    viewModel.buildCategoryHierarchy(categories, id)
                            }
                        }
                    }
                    FieldType.ShortTextBox, FieldType.LongTextBox -> {
                        configureField(formField, viewHeaderContainerBinding)
                    }
                    FieldType.NumberedList -> {
                        val numberedViewBinding = viewHeaderContainerBinding
                        container.addViewWithTryCatch(numberedViewBinding.root)
                        numberedViewBinding.header.text = formField.label
                        numberedViewBinding.valueText.text = viewModel.getNumberedListValue(formField)
                    }
                    FieldType.BulletedList -> {
                        val bulletedViewBinding = viewHeaderContainerBinding
                        container.addViewWithTryCatch(bulletedViewBinding.root)
                        bulletedViewBinding.header.text = formField.label
                        bulletedViewBinding.valueText.text = viewModel.getBulletedListValue(formField)
                    }
                    FieldType.RadioButton, FieldType.DropDown -> {
                        val radioViewBinding = viewHeaderContainerBinding
                        container.addViewWithTryCatch(radioViewBinding.root)
                        radioViewBinding.header.text = formField.label
                        radioViewBinding.valueText.text = viewModel.getSingleChoiceValue(
                            formField,
                            viewModel.getFormFieldValueString(formField)
                        )
                    }
                    FieldType.Image -> {
                        viewModel.getPhotos(formField, report.uuid)?.let {
                            container.addViewWithTryCatch(viewPhotoBinding.root)
                            viewPhotoBinding.label.text = formField.label
                            viewPhotoBinding.photoRecycleView.adapter = photoAdapter
                            photoAdapter.updateItems(it)
                        }
                    }
                    FieldType.CheckBox, FieldType.InternalAttendees, FieldType.ExternalAttendees -> {
                        val checkboxViewBinding = viewHeaderContainerBinding.also {
                            it.valueText.setLineSpacing(4.dpToPx(), 1.2f)
                        }
                        container.addViewWithTryCatch(checkboxViewBinding.root)
                        checkboxViewBinding.header.text = formField.label
                        checkboxViewBinding.valueText.text =
                            viewModel.getMultipleChoicesValue(formField)
                    }
                    FieldType.FreeText -> {
                        configureFreeTextField(formField)
                    }
                    else -> {}
                }
            }
            addReportId(report.uuid)
        }
    }

    private fun configureFreeTextField(formField: FormField) {
        container.addViewWithTryCatch(viewWebViewContainerBinding.root)
        formField.label?.let {
            viewWebViewContainerBinding.webView.loadData(it)
            viewWebViewContainerBinding.webView.setTheme()
        }
    }

    private fun addReportId(id: String) {
        container.addViewWithTryCatch(reportIdViewBinding.root)
        reportIdViewBinding.header.setText(R.string.report_id)
        reportIdViewBinding.valueText.text = id
    }

    private fun configureField(formField: FormField, binding: ViewHeaderContainerBinding) {
        formField.fieldVisibility
        container.addViewWithTryCatch(binding.root)
        binding.header.text = formField.label
        binding.valueText.text = viewModel.getFormFieldValueString(formField)
    }

    private fun ViewGroup.addViewWithTryCatch(
        view: View,
        params: ViewGroup.LayoutParams = wrapContentHeightParams
    ) {
        if (!children.contains(view)) {
            view.removeFromParent()
            try {
                addView(view, params)
                if (this == container) view.marginTop()
            } catch (exception: Exception) {
            }
        }
    }
}
