package com.thundermaps.saferme.features.main.tasks

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.TaskItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.util.Deeplink
import com.thundermaps.saferme.databinding.FragmentTasksBinding
import com.thundermaps.saferme.features.main.tasks.common.TaskAdapter
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class TasksFragment : BaseFragment<FragmentTasksBinding, TasksViewModel>() {
    @Inject
    lateinit var taskAdapter: TaskAdapter
    override val viewModel: TasksViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_tasks

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        taskAdapter.updateInterface(object : TaskItemInterface {
            override fun onViewReportSelected(item: TaskCardData) {
                item.reportId?.let {
                    val request = Deeplink.createReportDetailsDeeplinkRequest(item.reportId)
                    findNavController().navigate(request)
                }
            }

            override fun markAsComplete(item: TaskCardData) {
                viewModel.markAsComplete(item)
            }

            override fun onViewTaskSelected(item: TaskCardData) {
                findNavController().navigate(TasksFragmentDirections.openTaskDetails(item.toJson()))
            }
        })

        binding.recyclerView.setAdapter(taskAdapter)
        binding.recyclerView.setLayoutManager(LinearLayoutManager(requireContext()))
        binding.recyclerView.addVeiledItems(NUMBER_SHIMMER_ITEMS)
        binding.recyclerView.veil()
        viewModel.taskCards.observe(viewLifecycleOwner) {
            binding.recyclerView.unVeil()
            binding.swiperefresh.isRefreshing = false
            taskAdapter.updateItems(it)
            taskAdapter.notifyDataSetChanged()
            binding.recyclerView.getRecyclerView().scrollToPosition(0)
        }

        binding.swiperefresh.setOnRefreshListener {
            viewModel.syncTasks()
            binding.recyclerView.veil()
        }

        binding.swiperefresh.isRefreshing = false
        viewModel.syncTask.observe(viewLifecycleOwner) {
            binding.swiperefresh.isRefreshing = it.isLoading
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
        viewModel.startObserveIfNeeded()
        actionController?.hideNavigationIcon()
    }

    companion object {
        private const val NUMBER_SHIMMER_ITEMS = 3
    }
}
