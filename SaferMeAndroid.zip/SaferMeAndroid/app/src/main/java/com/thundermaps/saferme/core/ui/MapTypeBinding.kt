package com.thundermaps.saferme.core.ui

import android.widget.TextView
import androidx.databinding.BindingAdapter
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.models.MapType
import com.thundermaps.saferme.core.ui.extensions.fetchAttributeColor

@BindingAdapter("bindRoad")
fun bindMapTypeRoad(textView: TextView, mapType: MapType?) {
    if (mapType == null) return
    if (mapType == MapType.ROAD) {
        textView.setTextColor(textView.context.resources.getColor(R.color.blue_whale, null))
        textView.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_map_selected_road, 0, 0)
    } else {
        textView.setTextColor(textView.context.fetchAttributeColor(R.attr.colorOnSecondary))
        textView.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_map_road, 0, 0)
    }
}

@BindingAdapter("bindSatellite")
fun bindMapTypeSatellite(textView: TextView, mapType: MapType?) {
    if (mapType == null) return
    if (mapType == MapType.SATELLITE) {
        textView.setTextColor(textView.context.resources.getColor(R.color.blue_whale, null))
        textView.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_map_selected_satellite, 0, 0)
    } else {
        textView.setTextColor(textView.context.fetchAttributeColor(R.attr.colorOnSecondary))
        textView.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_map_satellite, 0, 0)
    }
}
