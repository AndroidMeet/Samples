package com.thundermaps.saferme.features.main.createtask

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianTeamUser
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.models.TaskCardType
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import com.thundermaps.saferme.core.util.TimeUtil
import com.thundermaps.saferme.features.main.dropdown.domain.model.SelectionOptionData
import com.thundermaps.saferme.features.main.reports.common.fullName
import com.thundermaps.saferme.features.main.tasks.domain.model.CreateTaskData
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.Date
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class CreateTaskViewModel @Inject constructor(
    val app: SaferMeApplication,
    val obsidianApi: ObsidianApi,
    val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private val teamUserManager = obsidianApi.teamManager
    private val taskManager = obsidianApi.Tasks()

    private val _teamUsers = MutableLiveData<List<ObsidianTeamUser>>()
    val teamUsernames: LiveData<List<SelectionOptionData>> = Transformations.map(_teamUsers) { users ->
            users.map { SelectionOptionData(it.fullName) }
        }

    val taskTitleInput = TextFieldInput(app.getString(R.string.hint_task_title)).apply {
        text.value = ""
    }
    val taskDescriptionInput = TextFieldInput(app.getString(R.string.hint_task_description))
    val assigneeName = TextFieldInput(app.getString(R.string.hint_assign_to))

    private val _createTask = MutableLiveData<Result<TaskCardData>>()
    val createOrUpdateTask: LiveData<Result<TaskCardData>> = _createTask

    lateinit var createTaskData: CreateTaskData
        private set

    val remainTitleLength: LiveData<String> = Transformations.map(taskTitleInput.text) {
        (if (it != null) {
            MAX_LENGTH_TITLE - it.length
        } else {
            MAX_LENGTH_TITLE
        }).toString()
    }

    private var assigneeId: Int? = null
    private val _canCreateTask = MediatorLiveData<Boolean>()
    val canCreateTask: LiveData<Boolean> = _canCreateTask

    init {
        viewModelScope.launch(dispatcherContext.io) {
            _teamUsers.postValue(teamUserManager.getTeamsUsers())
        }

        _canCreateTask.addSource(taskTitleInput.text) {
            updateCanSaveTaskStatus()
        }
        _canCreateTask.addSource(taskDescriptionInput.text) {
            updateCanSaveTaskStatus()
        }
    }

    private fun updateCanSaveTaskStatus() {
        _canCreateTask.value =
            (assigneeId != null && !taskDescriptionInput.text.value.isNullOrEmpty() && !taskTitleInput.text.value.isNullOrEmpty())
    }

    fun createTask() {

        val sessionsManager = obsidianApi.provideSessionsManager()
        sessionsManager.userDetails?.let {

            _createTask.postValue(Result.Loading(null))
            viewModelScope.launch(dispatcherContext.io) {
                val existTask = createTaskData.task
                val newTask = existTask?.copy(
                    assignee = assigneeId,
                    creatorId = it.id.toInt(),
                    description = taskDescriptionInput.text.value,
                    title = taskTitleInput.text.value
                ) ?: TaskCardData(
                    id = UUID.randomUUID().toString(),
                    assignee = assigneeId,
                    creatorId = it.id.toInt(),
                    description = taskDescriptionInput.text.value,
                    title = taskTitleInput.text.value,
                    createdDate = Date(),
                    type = TaskCardType.REPORT,
                    reportId = createTaskData.uuid
                )

                if (existTask == null) {
                    taskManager.create(newTask.toObsidianTask())
                } else {
                    taskManager.update(newTask.toObsidianTask(TimeUtil.getIsoDateInString()))
                }

                _createTask.postValue(
                    Result.Success(newTask)
                )
            }
        }
    }

    fun selectedUser(userName: String) {
        _teamUsers.value?.let { teamUsers ->
            assigneeId = teamUsers.first { it.fullName == userName }.userId.toInt()
            assigneeName.text.postValue(userName)
            updateCanSaveTaskStatus()
        }
    }

    fun selectedUserPosition(userId: Int) {
        _teamUsers.value?.let { teamUsers ->
            val index = teamUsers.indexOfFirst { it.userId.toInt() == userId }
            selectedUser(teamUsers[index].fullName)
            assigneeName.text.postValue(teamUsers[index].fullName)
        }
    }

    private fun updateFields(task: TaskCardData) {
        taskTitleInput.text.postValue(task.title)
        taskDescriptionInput.text.postValue(task.description)
    }

    fun storeCreateTaskData(data: String) {
        createTaskData = CreateTaskData.of(data)
        createTaskData.task?.let {
            updateFields(it)
        }
    }

    companion object {
        private const val MAX_LENGTH_TITLE = 80
    }
}
