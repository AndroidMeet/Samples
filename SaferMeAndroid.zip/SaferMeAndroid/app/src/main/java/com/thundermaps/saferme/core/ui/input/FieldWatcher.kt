package com.thundermaps.saferme.core.ui.input

import android.text.Editable
import android.text.TextWatcher

class FieldWatcher(
    private val beforeCheck: () -> Boolean = { false },
    private val afterCheck: () -> Boolean
) : TextWatcher {
    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        beforeCheck()
        afterCheck()
    }

    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        // don't handle
    }

    override fun afterTextChanged(p0: Editable?) {
        afterCheck()
    }
}
