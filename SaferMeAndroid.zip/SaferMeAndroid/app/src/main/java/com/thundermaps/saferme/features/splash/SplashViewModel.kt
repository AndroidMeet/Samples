package com.thundermaps.saferme.features.splash

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {

    fun isAuthenticated(): LiveData<Result<Boolean>> {
        val isAuthenticated = MutableLiveData<Result<Boolean>>(Result.Loading(null))

        viewModelScope.launch(dispatcherContext.io) {
            val result = obsidianApi.isAuthenticated()
            isAuthenticated.postValue(Result.Success(result))
        }
        return isAuthenticated
    }
}
