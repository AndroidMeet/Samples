package com.thundermaps.saferme.core.util

import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.LineString
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.mapbox.turf.TurfConstants
import com.mapbox.turf.TurfJoins
import com.mapbox.turf.TurfMeasurement
import com.mapbox.turf.TurfMisc
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.saferme.core.domain.models.ClosestFeature
import com.thundermaps.saferme.core.domain.models.ClosestPoint

@ExcludeFromJacocoGeneratedReport
object ClosestHelper {
    fun closestFeature(featureCollection: FeatureCollection?, point: Point): ClosestFeature? {
        var closestFeature: ClosestFeature? = null
        featureCollection?.features()?.forEach { feature ->
            closestPointOnFeature(feature, point)?.let { resultClosestFeature ->
                val saveClosestFeature = closestFeature
                if (saveClosestFeature == null) {
                    closestFeature = ClosestFeature(feature, resultClosestFeature)
                } else {
                    if (resultClosestFeature.distance != null && saveClosestFeature.closestPoint.distance != null && resultClosestFeature.distance < saveClosestFeature.closestPoint.distance) {
                        closestFeature = ClosestFeature(feature, resultClosestFeature)
                    }
                }

                if (closestFeature?.closestPoint?.distance == 0.0) {
                    return closestFeature
                }
            }
        }

        return closestFeature
    }

    private fun closestPointOnFeature(feature: Feature, point: Point): ClosestPoint? {
        return feature.geometry()?.let { geometry ->
            when (geometry) {
                is LineString -> closestPointOnLine(geometry, point)
                is Polygon -> closestPointOnPolygon(geometry, point)
                else -> null
            }
        }
    }

    private fun closestPointOnLine(line: LineString, point: Point): ClosestPoint? {
        val closestPoint = (TurfMisc.nearestPointOnLine(
            point,
            line.coordinates(),
            TurfConstants.UNIT_METERS
        ).geometry() as? Point)

        return closestPoint?.let { ClosestPoint(TurfMeasurement.distance(point, it), it) }
    }

    private fun closestPointOnPolygon(polygon: Polygon, point: Point): ClosestPoint? {
        if (polygon.coordinates().size != 1) return null
        if (isPointOnPolygon(polygon, point)) {
            return ClosestPoint(0.0, point)
        }
        return polygon.coordinates().firstOrNull()?.let {
            closestPointOnLine(LineString.fromLngLats(it), point)
        }
    }

    private fun isPointOnPolygon(polygon: Polygon, point: Point): Boolean {
        return TurfJoins.inside(point, polygon)
    }
}
