package com.thundermaps.saferme.features.main.reports.common

import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.getFormFields
import com.saferme.obsidian.store.resources.ObsidianTeamUser
import com.thundermaps.apilib.android.api.responses.models.FieldType
import com.thundermaps.apilib.android.api.responses.models.FormFieldImage
import com.thundermaps.apilib.android.api.responses.models.ReportState
import com.thundermaps.apilib.android.api.responses.models.RiskLevel
import com.thundermaps.saferme.R

val ReportState?.background: Int
    get() = when (this?.name?.lowercase()) {
        "new", "new report" -> R.drawable.bg_report_new
        "in review" -> R.drawable.bg_report_in_review
        "resolved" -> R.drawable.bg_report_resolved
        else -> R.drawable.bg_report_resolved
    }

val RiskLevel?.background: Int
    get() = when (this?.score) {
        0, 1 -> R.drawable.bg_report_new
        2, 3 -> R.drawable.bg_report_resolved
        else -> R.drawable.bg_report_orange
    }

@Suppress("unused", "UNCHECKED_CAST")
val ObsidianReport.imageField: FormFieldImage?
    get() = (getFormFields?.firstOrNull {
        it.fieldType == FieldType.Image
    }?.value as? List<FormFieldImage>)?.firstOrNull()

val ObsidianTeamUser.fullName: String get() = this.toString()
