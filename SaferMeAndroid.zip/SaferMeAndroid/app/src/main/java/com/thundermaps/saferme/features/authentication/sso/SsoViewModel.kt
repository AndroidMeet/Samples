package com.thundermaps.saferme.features.authentication.sso

import android.app.Application
import android.net.Uri
import androidx.annotation.VisibleForTesting
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.resources.SessionsResource
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.SsoDetails
import com.thundermaps.apilib.android.api.responses.models.SsoSessions
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.AppIdProvider
import com.thundermaps.saferme.core.ui.Screen
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import com.thundermaps.saferme.core.ui.nextScreen
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class SsoViewModel @Inject constructor(
    app: Application,
    private val obsidianApi: ObsidianApi,
    private val sessionsResource: SessionsResource,
    private val dispatcherContext: DispatcherContext,
    private val appIdProvider: AppIdProvider
) : AndroidViewModel(app) {
    val organizationIdInput = TextFieldInput(app.getString(R.string.sso_organization_id))
    private var currentText = ""
    private val errorMessage by lazy { app.getString(R.string.sso_error) }

    private val ssoDetailsResult = MutableLiveData<Result<SsoDetails>>()
    val ssoDetails: LiveData<Result<SsoDetails>> = ssoDetailsResult

    private val _ssoSessionsResult = MutableLiveData<Result<SsoSessions>>()

    private val _progressSsoLogin = MediatorLiveData<Result<Unit>>()
    val progressSsoLogin: LiveData<Result<Unit>> = _progressSsoLogin

    private val _isLoginSsoEnable = MediatorLiveData<Boolean>()
    val isLoginSsoEnabled: LiveData<Boolean> = _isLoginSsoEnable

    @VisibleForTesting
    var nonce: String? = null
        private set

    @VisibleForTesting
    var state: String? = null
        private set

    @ExcludeFromJacocoGeneratedReport
    val signInUrl: LiveData<String?> = Transformations.map(ssoDetailsResult) {
        it.getNullableData()?.let { details ->
            try {
                buildSsoSignInUrl(details)
            } catch (exception: Exception) {
                clearNonceAndState()
                null
            }
        }
    }

    val nextScreen: LiveData<Screen?> = Transformations.map(_ssoSessionsResult) {
        it.getNullableData()?.session?.nextScreen()
    }

    init {
        observerContinueStatus()
        observeLoginStatus()
    }

    private fun observeLoginStatus() {
        _progressSsoLogin.addSource(ssoDetailsResult) {
            _progressSsoLogin.postValue(it.convert {})
        }
        _progressSsoLogin.addSource(_ssoSessionsResult) {
            _progressSsoLogin.postValue(it.convert {})
        }
    }

    private fun observerContinueStatus() {
        fun updateValue() {
            _isLoginSsoEnable.postValue((!organizationIdInput.text.value.isNullOrEmpty() && currentText != organizationIdInput.text.value) || _progressSsoLogin.value?.isError == false)
        }
        _isLoginSsoEnable.addSource(_progressSsoLogin) {
            if (it.isError) {
                organizationIdInput.showError(errorMessage)
            }
            updateValue()
        }
        _isLoginSsoEnable.addSource(organizationIdInput.text) {
            if (!it.isNullOrEmpty() && !it.equals(currentText)) {
                organizationIdInput.clearError()
            }
            updateValue()
        }
    }

    fun loadSsoDetails() {
        viewModelScope.launch(dispatcherContext.io) {
            organizationIdInput.text.value?.let {
                currentText = it
                val loading = Result.Loading(null)
                ssoDetailsResult.postValue(loading)
                try {
                    val result = sessionsResource.getSsoDetails(it, appIdProvider.appId)
                    ssoDetailsResult.postValue(result)
                } catch (e: Exception) {
                    clearNonceAndState()
                    ssoDetailsResult.postValue(Result.Error(null, e))
                }
            }
        }
    }

    fun loadSsoSessions(code: String) {
        ssoDetailsResult.value?.getNullableData()?.let { ssoDetails ->
            _ssoSessionsResult.value = Result.Loading(null)
            viewModelScope.launch(dispatcherContext.io) {
                val result =
                    sessionsResource.getSsoSessions(code, appIdProvider.appId, ssoDetails, nonce)
                result.getNullableData()?.let {
                    obsidianApi.provideSessionsManager()
                        .saveSessions(it.session, appIdProvider.appId)
                }
                _ssoSessionsResult.postValue(result)
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private fun buildSsoSignInUrl(details: SsoDetails): String {
        nonce = UUID.randomUUID().toString()
        state = UUID.randomUUID().toString()
        val uriBuilder = Uri.parse(details.authorizeUri)
            .buildUpon()
            .appendQueryParameter(RESPONSE_MODE_KEY, RESPONSE_MODE_VALUE)
            .appendQueryParameter(STATE_KEY, state)
            .appendQueryParameter(NONCE_KEY, nonce)
            .appendQueryParameter(REDIRECT_URI_KEY, REDIRECT_URI_VALUE)
        return uriBuilder.build().toString()
    }

    @VisibleForTesting
    fun clearNonceAndState() {
        nonce = null
        state = null
    }

    companion object {
        @VisibleForTesting
        const val RESPONSE_MODE_KEY = "response_mode"

        @VisibleForTesting
        const val RESPONSE_MODE_VALUE = "query"

        @VisibleForTesting
        const val STATE_KEY = "state"

        @VisibleForTesting
        const val NONCE_KEY = "nonce"

        @VisibleForTesting
        const val REDIRECT_URI_KEY = "redirect_uri"

        @VisibleForTesting
        const val REDIRECT_URI_VALUE = "msauth.com.thundermaps.saferme://auth"
    }
}
