package com.thundermaps.saferme.core.domain.di

import android.content.Context
import com.google.firebase.iid.FirebaseInstanceId
import com.google.gson.Gson
import com.mapbox.search.MapboxSearchSdk
import com.mapbox.search.ReverseGeocodingSearchEngine
import com.mapbox.search.SearchEngine
import com.saferme.obsidian.Obsidian
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.Provider
import com.thundermaps.saferme.SaferMeApplication
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object SaferMeModule {
    @Singleton
    @Provides
    fun provideObsidian(
        @ApplicationContext context: Context
    ): ObsidianApi = Obsidian.getInstance(context)

    @Singleton
    @Provides
    fun provideApplication(
        @ApplicationContext context: Context
    ): SaferMeApplication = context.applicationContext as SaferMeApplication

    @Singleton
    @Provides
    fun gson(): Gson = Provider.gson

    @Provides
    @Singleton
    fun provideSearchReverseEngine(): ReverseGeocodingSearchEngine =
        MapboxSearchSdk.getReverseGeocodingSearchEngine()

    @Provides
    @Singleton
    fun provideSearchEngine(): SearchEngine = MapboxSearchSdk.getSearchEngine()

    @Provides
    @Singleton
    fun provideFirebaseInstance(): FirebaseInstanceId = FirebaseInstanceId.getInstance()
}
