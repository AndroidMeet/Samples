package com.thundermaps.saferme.core.ui.extensions

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager

internal fun Activity.hideKeyboard() {
    val inputMethodManager: InputMethodManager =
        getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager

    val view = currentFocus ?: View(this)
    inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
}

internal fun Activity?.showKeyboard(view: View) {
    val inputMethodManager: InputMethodManager? =
        this?.getSystemService(Activity.INPUT_METHOD_SERVICE) as? InputMethodManager
    inputMethodManager?.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
}

@Suppress("unused")
internal fun Activity.openUrl(url: String) {
    val uri = Uri.parse(url)
    startActivity(Intent(Intent.ACTION_VIEW, uri))
}

@Suppress("DEPRECATION")
fun Activity.updateStatusColor(color: Int) {
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
    if (color == Color.TRANSPARENT) {
        window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
    } else {
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
    }
    window.statusBarColor = color
}
