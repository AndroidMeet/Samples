package com.thundermaps.saferme.features.main.reportdetails

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.TaskManager
import com.saferme.obsidian.authentication.SessionsManager
import com.saferme.obsidian.store.resources.ObsidianReport
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.features.main.reports.domain.model.CardData
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class ReportDetailsViewModel @Inject constructor(
    val app: SaferMeApplication,
    private val reportManager: ReportManager,
    private val taskManager: TaskManager,
    private val sessionsManager: SessionsManager,
    private val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private val detailsText by lazy { app.getString(R.string.report_details) }
    private val manageText by lazy { app.getString(R.string.report_manage) }

    private val _titles = MediatorLiveData<List<String>>()
    val titles: LiveData<List<String>> = _titles

    var isEditable: Boolean = false
        private set

    private val _report = MutableLiveData<Result<ObsidianReport>>()
    val report: LiveData<Result<ObsidianReport>> = _report
    val cardData: LiveData<CardData?> = Transformations.map(_report) { result ->
        result.getNullableData()?.let {
            CardData.of(it)
        }
    }

    init {
        _titles.postValue(mutableListOf(detailsText, manageText, createTaskTabLabel()))
    }

    fun loadReport(uuid: String) {
        _report.postValue(Result.Loading(null))
        updateLabels(uuid)
        viewModelScope.launch(dispatcherContext.io) {
            _report.postValue(Result.Success(reportManager.readOne(uuid)))
        }
    }

    private fun updateLabels(uuid: String) {
        sessionsManager.getSessions()?.let { sessions ->
            _titles.addSource(
                taskManager.readReportTask(
                    sessions.userId.toInt(),
                    uuid
                )
            ) { items ->
                _titles.value?.let {
                    val titles = it.toMutableList()
                    titles[2] = createTaskTabLabel(items.size)
                    _titles.postValue(titles)
                }
            }
        }
    }

    private fun createTaskTabLabel(size: Int = 0): String = app.getString(
        R.string.report_tasks_placeholder,
        size
    )
}
