package com.thundermaps.saferme.features.main.forms

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class SelectAFormViewModel @Inject constructor(
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    private var numberOfSync = 0
    val canAutoSync get() = numberOfSync == 0
    val channels: LiveData<List<ObsidianChannel>> = liveData(dispatcherContext.io) {
        emitSource(obsidianApi.channelsManager.readAll())
    }

    fun fetchChannels() {
        viewModelScope.launch(dispatcherContext.io) {
            numberOfSync++
            obsidianApi.channelsManager.syncChannels()
        }
    }

    fun resetNumberOfSync() {
        numberOfSync = 0
    }
}
