package com.thundermaps.saferme.core.ui.adapter

import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.domain.models.DiffItem
import com.thundermaps.saferme.core.domain.utils.GenericDiff
import com.thundermaps.saferme.core.domain.utils.ItemInterface

abstract class BaseAdapter<T : DiffItem, H : RecyclerView.ViewHolder> : RecyclerView.Adapter<H>() {
    protected val items = mutableListOf<T>()
    protected var itemInterface: ItemInterface? = null

    open fun updateItems(items: List<T>) {
        val result = DiffUtil.calculateDiff(GenericDiff(this.items, items))
        this.items.clear()
        this.items.addAll(items)
        result.dispatchUpdatesTo(this)
    }

    fun updateInterface(itemInterface: ItemInterface) {
        this.itemInterface = itemInterface
    }

    override fun getItemCount(): Int = items.count()
}
