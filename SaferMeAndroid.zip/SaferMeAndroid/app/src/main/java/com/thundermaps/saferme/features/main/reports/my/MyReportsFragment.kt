package com.thundermaps.saferme.features.main.reports.my

import androidx.fragment.app.viewModels
import com.thundermaps.saferme.features.main.reports.common.BaseReportsFragment
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MyReportsFragment @Inject constructor() : BaseReportsFragment() {
    override val viewModel: MyReportsViewModel by viewModels()
}
