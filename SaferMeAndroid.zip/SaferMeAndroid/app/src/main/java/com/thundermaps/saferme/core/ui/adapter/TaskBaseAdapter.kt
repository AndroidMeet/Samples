package com.thundermaps.saferme.core.ui.adapter

import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.domain.models.DiffItem
import com.thundermaps.saferme.core.domain.utils.TaskItemInterface

abstract class TaskBaseAdapter<T : DiffItem, H : RecyclerView.ViewHolder> : BaseAdapter<T, H>() {
    protected var taskItemInterface: TaskItemInterface? = null
    fun updateInterface(taskItemInterface: TaskItemInterface) {
        this.taskItemInterface = taskItemInterface
    }
}
