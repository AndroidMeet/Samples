package com.thundermaps.saferme

import android.app.Application
import androidx.startup.AppInitializer
import com.google.firebase.FirebaseApp
import com.mapbox.android.core.location.LocationEngineProvider
import com.mapbox.maps.loader.MapboxMapsInitializer
import com.mapbox.search.MapboxSearchSdk
import com.raygun.raygun4android.RaygunClient
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class SaferMeApplication : BaseApplication()

open class BaseApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        initializeRaygun()
        initializeMap()
        initializeFirebaseApp()
    }

    private fun initializeFirebaseApp() {
        FirebaseApp.initializeApp(this)
    }

    private fun initializeRaygun() {
        RaygunClient.init(this)
        RaygunClient.enableCrashReporting()
    }

    private fun initializeMap() {
        AppInitializer.getInstance(this).initializeComponent(MapboxMapsInitializer::class.java)
        try {
            MapboxSearchSdk.initialize(
                application = this,
                accessToken = getString(R.string.mapbox_access_token),
                locationEngine = LocationEngineProvider.getBestLocationEngine(this)
            )
        } catch (exception: Exception) {
            Timber.e(exception)
        }
    }
}
