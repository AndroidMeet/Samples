package com.thundermaps.saferme.features.main.dropdown

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentSelectionOptionBinding
import com.thundermaps.saferme.features.main.dropdown.domain.model.SelectionOptionData
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SelectionOptionFragment :
    BaseFragment<FragmentSelectionOptionBinding, SelectionOptionViewModel>() {
    private val args: SelectionOptionFragmentArgs by navArgs()
    override fun provideLayoutId(): Int = R.layout.fragment_selection_option
    override val viewModel: SelectionOptionViewModel by viewModels()

    @Inject
    lateinit var selectionOptionAdapter: SelectionOptionAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        actionController?.updateTitle(args.details.title)
        viewModel.setOptionsData(args.details.list)
        selectionOptionAdapter.updateInterface(object : ItemInterface {
            override fun <T : Any> onItemSelected(item: T) {
                super.onItemSelected(item)
                findNavController().previousBackStackEntry?.savedStateHandle?.set(
                    args.details.key,
                    (item as SelectionOptionData).title
                )
                findNavController().popBackStack()
            }
        })
        binding.recyclerView.adapter = selectionOptionAdapter
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            )
        )
        viewModel.options.observe(viewLifecycleOwner) {
            selectionOptionAdapter.updateItems(it)
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
        actionController?.showNavigationIcon()
    }
}
