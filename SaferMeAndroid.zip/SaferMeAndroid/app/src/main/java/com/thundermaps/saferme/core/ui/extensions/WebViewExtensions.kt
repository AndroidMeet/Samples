package com.thundermaps.saferme.core.ui.extensions

import android.content.res.Configuration
import android.graphics.Color
import android.util.Base64
import android.webkit.WebView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

private const val MIME_TYPE = "text/html"
private const val ENCODING = "base64"
private const val PAGE_STYLE_PREFIX =
    "<html><head><style type=\"text/css\">a{color:#017DAB; text-decoration:none; font-weight:bold;} </style></head><body>"
private const val PAGE_STYLE_SUFFIX = "</body></html>"

fun WebView.loadData(data: String) {
    loadData(
        Base64.encodeToString(
            "$PAGE_STYLE_PREFIX$data$PAGE_STYLE_SUFFIX".toByteArray(),
            Base64.DEFAULT
        ), MIME_TYPE, ENCODING
    )
}

fun WebView.setTheme() {
    setBackgroundColor(Color.TRANSPARENT)
    if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
        when (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
            Configuration.UI_MODE_NIGHT_YES -> {
                WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_ON)
            }
            Configuration.UI_MODE_NIGHT_NO, Configuration.UI_MODE_NIGHT_UNDEFINED -> {
                WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_OFF)
            }
            else -> {}
        }
    }
}
