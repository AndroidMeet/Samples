package com.thundermaps.saferme.features.main.search

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.models.SmSearchSuggestion
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.extensions.handleTouch
import com.thundermaps.saferme.core.ui.extensions.hideKeyboard
import com.thundermaps.saferme.core.ui.extensions.showKeyboard
import com.thundermaps.saferme.databinding.FragmentSearchBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SearchFragment : BaseFragment<FragmentSearchBinding, SearchViewModel>(), ItemInterface {
    @Inject
    lateinit var searchAdapter: SearchAdapter
    override val viewModel: SearchViewModel by viewModels()
    override fun provideLayoutId(): Int = R.layout.fragment_search

    override fun onResume() {
        super.onResume()
        actionController?.hideToolBar()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        configAdapter()
        binding.searchEditText.requestFocus()
        viewModel.startSearch()
        activity?.showKeyboard(binding.searchEditText)
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s.isNullOrEmpty()) {
                    viewModel.startSearch()
                } else {
                    viewModel.searchText(s.toString())
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
        binding.searchViewLayout.setStartIconOnClickListener {
            findNavController().popBackStack()
            bottomNavigationController?.showBottomNavigation()
        }
        binding.root.handleTouch {
            requireActivity().hideKeyboard()
            if (it) binding.searchEditText.clearFocus()
        }
    }

    private fun configAdapter() {
        viewModel.suggestions.observe(viewLifecycleOwner) {
            searchAdapter.updateSaferMeSuggestions(it)
        }
        searchAdapter.updateInterface(this)
        DividerItemDecoration(requireContext(), LinearLayoutManager.VERTICAL).run {
            binding.searchRecycleView.addItemDecoration(this)
        }
        binding.searchRecycleView.adapter = searchAdapter
    }

    override fun <T : Any> onItemSelected(item: T) {
        (item as? SmSearchSuggestion)?.let {
            findNavController().popBackStack()
            viewModel.didSearchSelected(it)
        }
    }
}
