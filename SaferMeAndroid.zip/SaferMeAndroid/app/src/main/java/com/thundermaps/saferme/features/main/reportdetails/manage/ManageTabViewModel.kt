package com.thundermaps.saferme.features.main.reportdetails.manage

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.assigneeObject
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.reportStateObject
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.ui.extensions.getDueDateTime
import com.thundermaps.saferme.core.util.TimeUtil
import com.thundermaps.saferme.features.main.reportdetails.manage.models.AssigneeData
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
@ExcludeFromJacocoGeneratedReport
class ManageTabViewModel @Inject constructor(
    private val saferMeApplication: SaferMeApplication
) : AndroidViewModel(saferMeApplication) {
    private val _report = MutableLiveData<ObsidianReport>()
    val report: LiveData<ObsidianReport> = _report

    private val _assigneeData = MutableLiveData<AssigneeData>()
    val assigneeData: LiveData<AssigneeData> = _assigneeData

    private val unassigned: String by lazy {
        saferMeApplication.getString(R.string.unassigned)
    }

    fun storeReport(report: ObsidianReport) {
        _report.value = report
    }

    fun updateAssigneeData(report: ObsidianReport) {
        _assigneeData.postValue(AssigneeData(
            report.assigneeObject?.let { saferMeApplication.getString(R.string.assign_to_placeholder, "${it.firstName} ${it.lastName}") } ?: unassigned,
            dueString = report.assignmentDueAt?.let { dateInString ->
                TimeUtil.convertIsoDateStringToDate(dateInString)?.time?.let { time ->
                    saferMeApplication.getDueDateTime(
                        time
                    )
                }
            },
            state = report.reportStateObject?.name
        ))
    }
}
