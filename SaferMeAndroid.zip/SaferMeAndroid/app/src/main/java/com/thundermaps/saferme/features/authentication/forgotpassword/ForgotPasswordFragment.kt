package com.thundermaps.saferme.features.authentication.forgotpassword

import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.extensions.hideKeyboard
import com.thundermaps.saferme.core.ui.input.FieldWatcher
import com.thundermaps.saferme.databinding.FragmentForgotPasswordBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ForgotPasswordFragment : BaseFragment<FragmentForgotPasswordBinding, ForgotPasswordViewModel>() {
    private val navigationController get() = findNavController()
    override val viewModel: ForgotPasswordViewModel by viewModels()
    override fun provideLayoutId(): Int = R.layout.fragment_forgot_password

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.emailEdittext.setOnEditorActionListener { _, actionId, _ ->
            when (actionId) {
                EditorInfo.IME_ACTION_DONE -> {
                    requireActivity().hideKeyboard()
                    if (viewModel.checkEmail()) {
                        viewModel.requestChangePassword()
                        true
                    } else false
                }
                else -> false
            }
        }

        binding.emailEdittext.addTextChangedListener(FieldWatcher(afterCheck = { viewModel.checkEmail() }))

        viewModel.requestStatus.observe(viewLifecycleOwner, {
            if (it.isSuccess) {
                it.getNullableData()?.let { email ->
                    navigationController.navigate(ForgotPasswordFragmentDirections.openForgotPasswordSentScreen(email))
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }
}
