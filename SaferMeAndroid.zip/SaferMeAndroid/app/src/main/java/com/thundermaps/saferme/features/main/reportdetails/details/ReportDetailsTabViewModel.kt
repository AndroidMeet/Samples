package com.thundermaps.saferme.features.main.reportdetails.details

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianCategory
import com.saferme.obsidian.store.resources.ObsidianReport
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.responses.models.DataValue
import com.thundermaps.apilib.android.api.responses.models.FormField
import com.thundermaps.apilib.android.api.responses.models.FormValue
import com.thundermaps.apilib.android.api.responses.models.OptionHolder
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.ui.extensions.getPhotos
import com.thundermaps.saferme.core.util.TimeUtil
import com.thundermaps.saferme.core.util.TimeUtil.toMediumDateInString
import com.thundermaps.saferme.core.util.TimeUtil.toShortTimeInString
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
@ExcludeFromJacocoGeneratedReport
class ReportDetailsTabViewModel @Inject constructor(
    app: SaferMeApplication,
    private val obsidianApi: ObsidianApi,
    private val gson: Gson
) : AndroidViewModel(app) {
    private lateinit var savedReport: ObsidianReport
    private val noAnswerText by lazy {
        app.getString(R.string.no_answer)
    }
    val dateTimeValue
        get() = if (::savedReport.isInitialized) {
            savedReport.isoCreatedAt?.let {
                val date = TimeUtil.convertIsoDateStringToDate(it)
                "${date.toMediumDateInString()} - ${date.toShortTimeInString()?.lowercase()}"
            }
        } else null

    private val _report = MutableLiveData<ObsidianReport>()
    val report: LiveData<ObsidianReport> = _report

    fun setReport(report: ObsidianReport) {
        if (!::savedReport.isInitialized || savedReport != report) {
            savedReport = report
            _report.postValue(report)
        }
    }

    var photoItems = emptyList<PhotoItem>()
        private set

    fun getCategories() =
        savedReport.accountId?.let { obsidianApi.categoryManager.getCategories(it) }

    @ExcludeFromJacocoGeneratedReport
    fun buildCategoryHierarchy(categories: List<ObsidianCategory>, id: Int): String? {
        return categories.firstOrNull { it.id == id }?.let { currentCategory ->
            when (currentCategory.depth) {
                FIRST_LEVEL -> {
                    currentCategory.name
                }
                SECOND_LEVEL -> {
                    categories.firstOrNull { it.id == currentCategory.parentId }?.let { parent ->
                        "${parent.name}$NEW_LINE$SPACE${currentCategory.name}"
                    } ?: currentCategory.name
                }
                else -> {
                    categories.firstOrNull { it.id == currentCategory.parentId }?.let { parent ->
                        categories.firstOrNull { it.id == parent.parentId }?.let { grandParent ->
                            "${grandParent.name}$NEW_LINE$SPACE${parent.name}$NEW_LINE$SPACE$SPACE${currentCategory.name}"
                        } ?: "${parent.name}$NEW_LINE$SPACE${currentCategory.name}"
                    } ?: currentCategory.name
                }
            }
        }
    }

    fun getFormFieldValueString(formField: FormField): String {
        return (formField.value as? FormValue.ValueString)?.value ?: noAnswerText
    }

    fun getSingleChoiceValue(formField: FormField, value: String): String? {
        return (formField.data as? DataValue.DataJsonObject)?.value?.let { jsonObject ->
            val optionHolder = gson.fromJson(jsonObject, OptionHolder::class.java)
            optionHolder.options.firstOrNull { option -> option.value == value }?.label
        }
    }

    fun getNumberedListValue(formField: FormField): String? {
        return (formField.value as? FormValue.ValueJsonArray)?.value?.map {
            it.asString
        }?.mapIndexed { index, s ->
            "$SPACE${index + 1}.   $s"
        }?.joinToString(NEW_LINE)
    }

    fun getBulletedListValue(formField: FormField): String? {
        return (formField.value as? FormValue.ValueJsonArray)?.value?.map {
            it.asString
        }?.joinToString(NEW_LINE) { s ->
            "$BULLET$s"
        }
    }

    fun getMultipleChoicesValue(formField: FormField): String? {
        return try {
            (formField.value as? FormValue.ValueJsonArray)?.value?.map {
                it.asString
            }?.let { values ->
                (formField.data as? DataValue.DataJsonObject)?.value?.let { jsonObject ->
                    val optionHolder = gson.fromJson(jsonObject, OptionHolder::class.java)
                    optionHolder.options.filter { values.contains(it.value) }
                        .joinToString(NEW_LINE) {
                            "$BULLET${it.label}"
                        }
                }
            }
        } catch (exception: Exception) {
            null
        }
    }

    fun getPhotos(formField: FormField, reportUuid: String) =
        formField.getPhotos(reportUuid)?.also { photoItems = it }

    companion object {
        private const val BULLET = "    •    "
        private const val SPACE = "    "
        private const val NEW_LINE = "\n"
        private const val FIRST_LEVEL = 1
        private const val SECOND_LEVEL = 2
    }
}
