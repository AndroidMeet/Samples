package com.thundermaps.saferme.core.domain.models

import androidx.annotation.VisibleForTesting
import com.thundermaps.apilib.android.api.responses.models.ResponseError

@VisibleForTesting
const val ACCOUNT_LOCKED_CODE = "account_locked"

fun ResponseError.isAccountLocked() = ACCOUNT_LOCKED_CODE == errorCodes?.base?.firstOrNull()?.error
