package com.thundermaps.saferme.features.main.createreport.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.databinding.ItemNumberBinding
import com.thundermaps.saferme.features.main.createreport.models.DynamicItem

class DynamicAdapter(
    private val updateItem: UpdateItem?
) : BaseAdapter<DynamicItem, DynamicAdapter.Companion.DynamicItemHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DynamicItemHolder =
        DynamicItemHolder(
            ItemNumberBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            ),
            updateItem
        )

    override fun onBindViewHolder(holder: DynamicItemHolder, position: Int) {
        holder.bind(items.getOrNull(position), position, itemInterface)
    }

    companion object {
        class DynamicItemHolder(
            private val binding: ItemNumberBinding,
            private val updateItem: UpdateItem? = null
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: DynamicItem?, position: Int, listener: ItemInterface?) {
                binding.order = (position + 1)
                binding.item = item
                binding.executePendingBindings()
                binding.itemEditText.setOnEditorActionListener { view, actionId, _ ->
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        when (item) {
                            is DynamicItem.NumberItem -> item.copy(text = view.text?.toString())
                            is DynamicItem.BulletItem -> item.copy(text = view.text?.toString())
                            else -> null
                        }?.run {
                            updateItem?.onUpdateItem(this)
                        }
                    }
                    false
                }
                binding.inputLayout.setEndIconOnClickListener {
                    item?.let { listener?.onItemSelected(item) }
                }
            }
        }
    }
}

interface UpdateItem {
    fun onUpdateItem(item: DynamicItem)
}
