package com.thundermaps.saferme.features.main.settings.domain

import android.content.Context
import android.os.Build
import com.thundermaps.saferme.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

interface DeviceDetailsRepository {
    fun getDeviceDetails(): DeviceDetails
}

class DeviceDetailsRepositoryImpl @Inject constructor(
    @ApplicationContext val context: Context
) : DeviceDetailsRepository {

    override fun getDeviceDetails(): DeviceDetails {

        val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)

        return DeviceDetails(
            packageInfo.versionName,
            packageInfo.versionCode.toString(),
            "${Build.MANUFACTURER} ${Build.MODEL}",
            "${context.getString(R.string.android)} ${Build.VERSION.RELEASE}"
        )
    }
}
