package com.thundermaps.saferme.features.main.changeorganization

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.data.repo.TeamRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class ChangeOrganizationViewModel @Inject constructor(
    private val teamsRepository: TeamRepository,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {

    val teams: LiveData<List<ObsidianTeam>> = teamsRepository.teams

    private val _selectedTeamName = MutableStateFlow("")
    val selectedTeamName: StateFlow<String> = _selectedTeamName

    fun syncTeams(team: String) {
        _selectedTeamName.value = team
        viewModelScope.launch(dispatcherContext.io) {
            teamsRepository.syncTeam()
        }
    }

    fun selectTeam(obsidianTeam: ObsidianTeam) {
        _selectedTeamName.value = obsidianTeam.name
        viewModelScope.launch(dispatcherContext.io) {
            teamsRepository.selectTeam(obsidianTeam.id)
        }
    }
}
