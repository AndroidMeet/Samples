package com.thundermaps.saferme.features.authentication.organization.domain

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.data.repo.TeamRepository
import com.thundermaps.saferme.core.ui.Screen
import com.thundermaps.saferme.core.ui.nextScreen
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class TeamsViewModel @Inject constructor(
    private val teamsRepository: TeamRepository,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    private val _updatedSessions = MutableLiveData<Sessions?>()
    val nextScreen: LiveData<Screen?> = Transformations.map(_updatedSessions) {
        it?.nextScreen()
    }

    val teams: LiveData<List<ObsidianTeam>> = teamsRepository.teams

    fun syncTeams() {
        viewModelScope.launch(dispatcherContext.io) {
            teamsRepository.syncTeam()
        }
    }

    fun selectTeam(teamId: Long?) {
        teamId?.let {
            viewModelScope.launch(dispatcherContext.io) {
                _updatedSessions.postValue(teamsRepository.selectTeam(teamId))
            }
        }
    }
}
