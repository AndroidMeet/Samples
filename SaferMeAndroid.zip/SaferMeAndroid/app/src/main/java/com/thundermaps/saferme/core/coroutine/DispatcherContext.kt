package com.thundermaps.saferme.core.coroutine

import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.Dispatchers

@Singleton
@ExcludeFromJacocoGeneratedReport
open class DispatcherContext @Inject constructor() {
    @ExcludeFromJacocoGeneratedReport
    open val io: CoroutineContext = Dispatchers.IO
    @ExcludeFromJacocoGeneratedReport
    open val main: CoroutineContext = Dispatchers.Main
    @ExcludeFromJacocoGeneratedReport
    open val default: CoroutineContext = Dispatchers.Default
}

fun <T> LiveData<T>.observeForTesting(block: () -> Unit) {
    val observer = Observer<T> {}
    try {
        observeForever(observer)
        block()
    } finally {
        removeObserver(observer)
    }
}
