package com.thundermaps.saferme.core.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.media.ExifInterface
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.ui.extensions.rotate
import java.net.SocketException

private val circleCropTransform = RequestOptions.circleCropTransform()

@BindingAdapter("profileUrl")
fun loadUrl(imageView: ImageView, url: String?) {
    if (url != null && url.startsWith("http")) {
        Glide.with(imageView.context)
            .load(url)
            .placeholder(R.drawable.ic_outline_account_circle_24)
            .apply(circleCropTransform)
            .into(imageView)
    } else {
        imageView.setImageResource(R.drawable.ic_outline_account_circle_24)
    }
}

@BindingAdapter("img")
fun updateImage(imageView: ImageView, source: Any?) {
    when (source) {
        is Drawable -> imageView.setImageDrawable(source)
        is Int -> imageView.setImageResource(source)
        is String -> {
            if (source.startsWith("http")) {
                Glide.with(imageView.context)
                    .load(source)
                    .into(imageView)
            }
        }
        is Bitmap -> imageView.setImageBitmap(source)
        else -> imageView.setImageDrawable(null)
    }
}

@BindingAdapter("background")
fun updateImage(view: View, source: Any?) {
    when (source) {
        is Drawable -> view.background = source
        is Int -> view.setBackgroundResource(source)
        else -> view.background = null
    }
}

@Suppress("unused")
@BindingAdapter("endIcon")
fun bindEndImage(textView: TextView, @DrawableRes source: Int?) {
    source?.let {
        textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, it, 0)
    } ?: textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
}

private const val ORIENTATION_90_DEGREE_VALUE = 6
private const val ORIENTATION_180_DEGREE_VALUE = 3
private const val ORIENTATION_270_DEGREE_VALUE = 8

@BindingAdapter("photo")
fun bindPhoto(imageView: ImageView, photo: PhotoItem?) {
    photo?.let { photoItem ->
        when {
            photoItem.path != null -> {
                imageView.setPicture(photoItem.path)
            }
            else -> {
                try {
                    updateImage(imageView, photoItem.url)
                } catch (exception: SocketException) {
                    photoItem.path?.let { imageView.setPicture(photoItem.path) }
                }
            }
        }
    }
}

private fun ImageView.setPicture(picturePath: String) {
    val bitmapOptions = BitmapFactory.Options().apply {
        inJustDecodeBounds = false
        inSampleSize = 2
    }
    getImageBitmap(picturePath, bitmapOptions)?.let {
        setImageBitmap(it)
    }
}

private fun getImageBitmap(picturePath: String, options: BitmapFactory.Options): Bitmap? {
    val bitmap = BitmapFactory.decodeFile(picturePath, options)
    return when (getOrientation(picturePath)) {
        ORIENTATION_90_DEGREE_VALUE -> bitmap.rotate(90f)
        ORIENTATION_180_DEGREE_VALUE -> bitmap.rotate(180f)
        ORIENTATION_270_DEGREE_VALUE -> bitmap.rotate(270f)
        else -> bitmap
    }
}

fun getOrientation(path: String) = ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
