package com.thundermaps.saferme.features.main.reports.my

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.features.main.reports.common.BaseReportsViewModel
import com.thundermaps.saferme.features.main.reports.domain.model.CardData
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@HiltViewModel
class MyReportsViewModel @Inject constructor(
    app: SaferMeApplication,
    private val reportManager: ReportManager,
    private val sessionsManager: SessionsManager,
    private val dispatcherContext: DispatcherContext
) : BaseReportsViewModel(app) {
    override fun getReports(): LiveData<List<CardData>> {
        val result = MutableLiveData<List<CardData>>()
        viewModelScope.launch(dispatcherContext.io) {
            sessionsManager.userDetails?.let { details ->
                val data = reportManager.readUserReports(details.id.toInt())
                withContext(dispatcherContext.main) {
                    data.observeForever { reports ->
                        result.value = reports?.map {
                            CardData.of(it, anonymous)
                        }?.sortedByDescending { it.date }
                    }
                }
            }
        }
        return result
    }
}
