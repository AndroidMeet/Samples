package com.thundermaps.saferme.core.usecase

import android.content.Context
import androidx.annotation.VisibleForTesting
import androidx.core.content.edit
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.preference.PreferenceManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.search.QueryType
import com.mapbox.search.ResponseInfo
import com.mapbox.search.ReverseGeoOptions
import com.mapbox.search.ReverseGeocodingSearchEngine
import com.mapbox.search.SearchCallback
import com.mapbox.search.SearchEngine
import com.mapbox.search.SearchMultipleSelectionCallback
import com.mapbox.search.SearchOptions
import com.mapbox.search.SearchRequestTask
import com.mapbox.search.SearchSuggestionsCallback
import com.mapbox.search.result.SearchAddress
import com.mapbox.search.result.SearchResult
import com.mapbox.search.result.SearchSuggestion
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.saferme.core.domain.models.CustomSearchResult
import com.thundermaps.saferme.core.domain.models.SmSearchSuggestion
import com.thundermaps.saferme.core.util.ClosestHelper
import com.thundermaps.saferme.core.util.formatString
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.CopyOnWriteArrayList
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.JsonPrimitive
import timber.log.Timber

@Suppress("RedundantSuspendModifier")
@Singleton
class SearchAddressUseCase @Inject constructor(
    @ApplicationContext private val context: Context,
    private val searchEngine: SearchEngine,
    private val searchReverseEngine: ReverseGeocodingSearchEngine,
    private val obsidianApi: ObsidianApi,
    private val gson: Gson
) {
    private var searchRequestTask: SearchRequestTask? = null
    private var searchingPoint: Point? = null
    private val reverseSearch = MutableLiveData<CustomSearchResult?>(null)
    private val recentSuggestions = mutableListOf<SmSearchSuggestion>()
    private val _saferMeSearchSuggestions = MutableLiveData<List<SmSearchSuggestion>>()
    val saferMeSearchSuggestions: LiveData<List<SmSearchSuggestion>> = _saferMeSearchSuggestions
    private val recentSearchToken by lazy { object : TypeToken<List<SmSearchSuggestion>>() {}.type }
    var currentSearchSuggestion: SmSearchSuggestion? = null
        private set
    val addressSearchResult: LiveData<CustomSearchResult?> = reverseSearch
    private val sharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(context)
    }
    private val _address = MediatorLiveData<String?>()
    val address: LiveData<String?> get() = _address
    private var originalFeatures =
        CopyOnWriteArrayList<io.github.dellisd.spatialk.geojson.Feature>()
    private val _shapeData = MediatorLiveData<ShapeData>()

    @ExcludeFromJacocoGeneratedReport
    val shapeData: LiveData<ShapeData> = _shapeData

    init {
        _address.addSource(reverseSearch) { result ->
            _address.postValue(result?.address ?: getLocationInString())
        }

        _shapeData.addSource(obsidianApi.shapesManager.featureCollection) { collection ->
            originalFeatures.clear()
            originalFeatures.addAll(collection.features.filter {
                it.properties[IS_SELECTABLE] != JsonPrimitive(
                    DEFAULT_SELECTION_VALUE
                )
            })
            if (searchingPoint == null) {
                _shapeData.postValue(
                    ShapeData(
                        null,
                        io.github.dellisd.spatialk.geojson.FeatureCollection(originalFeatures)
                    )
                )
            } else {
                searchingPoint?.let { point ->
                    updateClosestPolygon(point)
                }
            }
        }
    }

    @VisibleForTesting
    fun getLocationInString(): String? = searchingPoint?.toLocationInString()

    @ExcludeFromJacocoGeneratedReport
    private val reverseSearchCallback: SearchCallback = object : SearchCallback {
        @ExcludeFromJacocoGeneratedReport
        override fun onError(e: Exception) {
            Timber.e(e)
        }

        @ExcludeFromJacocoGeneratedReport
        override fun onResults(results: List<SearchResult>, responseInfo: ResponseInfo) {
            reverseSearch.postValue(results.firstOrNull()?.let {
                it.coordinate?.let { coordinate ->
                    CustomSearchResult(
                        it.address?.toAddress(),
                        Point.fromLngLat(coordinate.longitude(), coordinate.latitude())
                    )
                } ?: CustomSearchResult(it.address?.toAddress(), Point.fromLngLat(0.0, 0.0))
            })
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private val searchCallback: SearchSuggestionsCallback = object : SearchSuggestionsCallback {
        @ExcludeFromJacocoGeneratedReport
        override fun onError(e: Exception) {
            Timber.e(e)
        }

        @ExcludeFromJacocoGeneratedReport
        override fun onSuggestions(
            suggestions: List<SearchSuggestion>,
            responseInfo: ResponseInfo
        ) {
            if (suggestions.isNotEmpty()) {
                searchEngine.select(suggestions, selectSearchSuggestionCallBack)
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private val selectSearchSuggestionCallBack = object : SearchMultipleSelectionCallback {
        @ExcludeFromJacocoGeneratedReport
        override fun onError(e: Exception) {
            Timber.e(e)
        }

        @ExcludeFromJacocoGeneratedReport
        override fun onResult(
            suggestions: List<SearchSuggestion>,
            results: List<SearchResult>,
            responseInfo: ResponseInfo
        ) {
            _saferMeSearchSuggestions.postValue(suggestions.mapIndexed { index, item ->
                SmSearchSuggestion(
                    item.address?.toAddress(),
                    results.getOrNull(index)?.coordinate
                )
            })
        }
    }

    suspend fun didSearch(point: Point) {
        clearSearch()
        searchRequestTask?.cancel()
        searchingPoint = point
        val options = ReverseGeoOptions.Builder(point).limit(REVERSE_SEARCH_LIMIT).build()
        searchRequestTask = searchReverseEngine.search(options, reverseSearchCallback)
        updateClosestPolygon(point)
    }

    suspend fun startSearch() {
        clearSearchSuggestion()
        _address.postValue(null)
        if (recentSuggestions.isEmpty()) {
            sharedPreferences.getString(getRecentSearchSuggestionKey(), null)?.let {
                try {
                    val suggestions = gson.fromJson<List<SmSearchSuggestion>>(
                        it,
                        recentSearchToken
                    )
                    recentSuggestions.addAll(suggestions)
                } catch (exception: Exception) {
                    Timber.e(exception)
                }
            }
        }

        _saferMeSearchSuggestions.postValue(recentSuggestions.filterNot { it.address == null }
            .map { it.copy(isRecent = true) })
    }

    private fun updateClosestPolygon(point: Point) {
        if (originalFeatures.isEmpty()) return
        val featureCollection =
            io.github.dellisd.spatialk.geojson.FeatureCollection(originalFeatures)
        ClosestHelper.closestFeature(FeatureCollection.fromFeatures(originalFeatures.map {
            Feature.fromJson(
                it.json()
            )
        }), point)?.let { closestFeature ->
            val address = closestFeature.feature.toAddress()
            if (address.isNotEmpty()) {
                searchRequestTask?.cancel()
                updateShapeData(
                    closestFeature.feature,
                    featureCollection,
                    closestFeature.closestPoint.closestPoint
                )
                reverseSearch.postValue(
                    CustomSearchResult(
                        address,
                        Point.fromLngLat(
                            closestFeature.closestPoint.closestPoint.longitude(),
                            closestFeature.closestPoint.closestPoint.latitude()
                        )
                    )
                )
                _address.postValue(address)
            } else {
                clearShapeSelection()
            }
        }
    }

    fun didSearch(text: String) {
        clearSearchSuggestion()
        _address.postValue(null)
        searchRequestTask?.cancel()
        val options = SearchOptions(limit = TEXT_SEARCH_LIMIT, types = listOf(QueryType.ADDRESS))
        searchRequestTask = searchEngine.search(text, options, searchCallback)
    }

    fun didSelectSearchSuggestion(smSearchSuggestion: SmSearchSuggestion) {
        currentSearchSuggestion = smSearchSuggestion
        _address.postValue(smSearchSuggestion.address)
        recentSuggestions.firstOrNull { it.address == smSearchSuggestion.address }
            ?.let { recentSuggestions.remove(it) }

        recentSuggestions.add(0, smSearchSuggestion)
        sharedPreferences.edit {
            val stringToSave = gson.toJson(recentSuggestions, recentSearchToken)
            putString(
                getRecentSearchSuggestionKey(),
                stringToSave
            )
        }
    }

    @Suppress("RedundantSuspendModifier")
    private fun updateShapeData(
        feature: Feature,
        featureCollection: io.github.dellisd.spatialk.geojson.FeatureCollection,
        closestPoint: Point?
    ) {
        _shapeData.postValue(
            ShapeData(
                feature,
                featureCollection,
                closestPoint
            )
        )
    }

    fun clearSearchSuggestion() {
        currentSearchSuggestion = null
    }

    fun clearSearchPoint() {
        searchingPoint = null
        clearShapeSelection()
    }

    private fun clearShapeSelection() {
        _shapeData.postValue(_shapeData.value?.copy(selectedShape = null, closestPoint = null))
    }

    fun clearSearch() {
        clearSearchPoint()
        clearSearchSuggestion()
    }

    private fun getRecentSearchSuggestionKey(): String {
        val sessions = obsidianApi.provideSessionsManager().getSessions()
        return RECENT_SEARCH_SUGGESTION_KEY + sessions?.userId
    }

    fun clear() {
        searchRequestTask?.cancel()
    }

    companion object {
        val DEFAULT_POINT: Point = Point.fromLngLat(174.7772114, -41.2887953)
        val POINT_NEAR_POLYGON: Point = Point.fromLngLat(-3.174068974614414, 50.65206381078267)
        val POINT_ON_THE_LINE: Point = Point.fromLngLat(-3.1814925397344775, 50.65077121869993)
        val POINT_NEAR_THE_LINE: Point = Point.fromLngLat(-3.1825402117961517, 50.65111695049481)
        private const val TEXT_SEARCH_LIMIT = 10
        private const val REVERSE_SEARCH_LIMIT = 1
        private const val IS_SELECTABLE = "is_selectable"
        private const val DEFAULT_SELECTION_VALUE = "false"

        @VisibleForTesting
        const val RECENT_SEARCH_SUGGESTION_KEY = "recent_search_suggestion_key"
    }
}

@ExcludeFromJacocoGeneratedReport
data class ShapeData(
    val selectedShape: Feature?,
    val shapes: io.github.dellisd.spatialk.geojson.FeatureCollection?,
    val closestPoint: Point? = null
)

fun SearchAddress.toAddress(): String? = formattedAddress(SearchAddress.FormatStyle.Full)

fun Feature.toAddress(): String {
    return try {
        "${getStringProperty("farm")}\n" +
                "${
                    listOfNotNull(
                        getStringProperty("lease"),
                        getStringProperty("subsection")
                    ).joinToString(" ")
                }: ${
                    listOfNotNull(
                        getStringProperty("method"),
                        getStringProperty("item")
                    ).joinToString(" ")
                }"
    } catch (exception: UnsupportedOperationException) {
        ""
    }
}

private const val DECIMAL_NUMBER = 6
fun Point?.toLocationInString(): String = "${
    this?.latitude()?.formatString(
        DECIMAL_NUMBER
    )
}, ${
    this?.longitude()?.formatString(DECIMAL_NUMBER)
}"
