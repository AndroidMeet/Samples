package com.thundermaps.saferme.features.main.reports.common

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentReportsBinding
import javax.inject.Inject

abstract class BaseReportsFragment : BaseFragment<FragmentReportsBinding, BaseReportsViewModel>() {
    abstract override val viewModel: BaseReportsViewModel

    @Inject
    lateinit var reportAdapter: ReportAdapter

    override fun provideLayoutId(): Int = R.layout.fragment_reports

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (parentFragment as? ItemInterface)?.let {
            reportAdapter.updateInterface(it)
        }
        binding.recyclerView.setAdapter(reportAdapter)

        binding.recyclerView.setLayoutManager(LinearLayoutManager(requireContext()))
        binding.recyclerView.addVeiledItems(NUMBER_SHIMMER_ITEMS)
        binding.recyclerView.veil()
        viewModel.getReports()?.observe(viewLifecycleOwner) {
            binding.recyclerView.unVeil()
            reportAdapter.updateItems(it)
        }
    }

    companion object {
        private const val NUMBER_SHIMMER_ITEMS = 3
    }
}
