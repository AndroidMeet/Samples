package com.thundermaps.saferme.features.main.createreport

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.thundermaps.saferme.core.domain.models.PhotoType
import com.thundermaps.saferme.databinding.FragmentAddPhotosBinding

class SelectPhotoBottomModal : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentAddPhotosBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentAddPhotosBinding.inflate(inflater, container, false).apply {
        binding = this
    }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setOnSelectPhotoClicked {
            val navigation = findNavController()
            navigation.previousBackStackEntry?.savedStateHandle?.set(PHOTO_TYPE, PhotoType.LIBRARY)
            navigation.popBackStack()
        }
        binding.setOnTakePhotoClicked {
            val navigation = findNavController()
            navigation.previousBackStackEntry?.savedStateHandle?.set(PHOTO_TYPE, PhotoType.CAMERA)
            navigation.popBackStack()
        }
        binding.closeButton.setOnClickListener {
            dialog?.dismiss()
        }
    }

    companion object {
        const val PHOTO_TYPE = "photo_type"
    }
}
