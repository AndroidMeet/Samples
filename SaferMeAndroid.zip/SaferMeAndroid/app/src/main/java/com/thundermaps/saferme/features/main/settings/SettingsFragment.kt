package com.thundermaps.saferme.features.main.settings

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.viewModels
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentSettingsBinding
import com.thundermaps.saferme.features.authentication.AuthenticationActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SettingsFragment : BaseFragment<FragmentSettingsBinding, SettingsViewModel>() {
    override val viewModel: SettingsViewModel by viewModels()
    override fun provideLayoutId(): Int = R.layout.fragment_settings

    private val logoutDialog by lazy {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.logout)
            .setMessage(R.string.logout_message)
            .setPositiveButton(R.string.logout) { dialog, _ ->
                dialog.dismiss()
                viewModel.logoutOperation.observe(viewLifecycleOwner) {
                    it?.let {
                        startActivity(Intent(requireActivity(), AuthenticationActivity::class.java))
                        requireActivity().finishAffinity()
                    }
                }
                viewModel.logout()
            }
            .setNegativeButton(R.string.btn_cancel) { dialog, _ ->
                dialog.dismiss()
            }
            .create()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.loadDeviceDetails()

        binding.setLocationClicked {
            Toast.makeText(requireContext(), "Location", Toast.LENGTH_LONG).show()
        }

        binding.setBluetoothClicked {
            Toast.makeText(requireContext(), "Bluetooth", Toast.LENGTH_LONG).show()
        }

        binding.setPushNotificationClicked {
            Toast.makeText(requireContext(), "Push notification", Toast.LENGTH_LONG).show()
        }

        binding.setPasswordClicked {
            Toast.makeText(requireContext(), "Password", Toast.LENGTH_LONG).show()
        }

        binding.setMapSettingsClicked {
            Toast.makeText(requireContext(), "Map settings", Toast.LENGTH_LONG).show()
        }

        binding.setEmailNotificationClicked {
            viewModel.onEmailNotificationClicked()
        }

        binding.setLogoutClicked {
            logoutDialog.show()
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }
}
