package com.thundermaps.saferme.features.main.dropdown.domain.model

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.domain.models.DiffItem
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class SelectionOptionData(
    @Expose val title: String
) : Parcelable, DiffItem {

    override val uniqueId: Any get() = title
}
