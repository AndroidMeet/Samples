package com.thundermaps.saferme.features.authentication.updatepassword.domain

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.viewModelScope
import com.thundermaps.apilib.android.api.requests.models.UpdatePasswordBody
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class UpdatePasswordViewModel @Inject constructor(
    private val app: Application,
    private val passwordCalculator: PasswordCalculator,
    private val repository: UpdatePasswordRepository,
    private val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private lateinit var oldPassword: String
    private val _updatePasswordResult = MutableLiveData<Result<Sessions>>()
    private val duplicateErrorString by lazy { app.getString(R.string.update_password_error_duplicate) }

    val updatePasswordResult: LiveData<Result<Sessions>> = _updatePasswordResult
    val passwordInput = TextFieldInput(app.getString(R.string.new_password))
    val passwordStrengthLevel: LiveData<PasswordStrengthLevel> =
        Transformations.map(passwordInput.text) {
            checkDuplication(it)
            passwordCalculator.measurePassword(it)
        }

    val isReadyToUpdate: LiveData<Boolean> = Transformations.map(passwordStrengthLevel) {
        it == PasswordStrengthLevel.STRONG && !passwordInput.isError
    }

    private fun checkDuplication(newPassword: String) {
        if (oldPassword == newPassword) {
            passwordInput.showError(duplicateErrorString)
        } else {
            passwordInput.clearError()
        }
    }

    fun setOldPassword(password: String) {
        oldPassword = password
    }

    fun updatePassword() {
        passwordInput.text.value?.let { newPassword ->
            _updatePasswordResult.value = Result.Loading(null)
            viewModelScope.launch(dispatcherContext.io) {
                val result = repository.updatePassword(
                    UpdatePasswordBody(
                        currentPassword = oldPassword,
                        newPassword = newPassword
                    )
                )
                _updatePasswordResult.postValue(result)
            }
        }
    }
}
