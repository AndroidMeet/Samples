package com.thundermaps.saferme.core.domain.models

import android.os.Parcelable
import com.saferme.obsidian.Provider.gson
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.SafermePendingChange
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.resources.Location
import java.util.UUID
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
open class ReportData : Parcelable {
    @Parcelize
    class Create(
        val searchResult: CustomSearchResult,
        val channel: ObsidianChannel
    ) : ReportData(), Parcelable

    @Parcelize
    class Edit(val uuid: String) : ReportData(), Parcelable
}

@ExcludeFromJacocoGeneratedReport
fun ReportData.Create.toObsidianReport(): ObsidianReport = ObsidianReport(
    uuid = UUID.randomUUID().toString(),
    address = searchResult.address,
    location = gson.toJsonTree(
        Location(
            searchResult.location.latitude(),
            searchResult.location.longitude()
        )
    ).asJsonObject,
    requestedAction = SafermePendingChange.NONE.toString(),
    localChangesPending = true,
    accountId = channel.id.toInt()
)
