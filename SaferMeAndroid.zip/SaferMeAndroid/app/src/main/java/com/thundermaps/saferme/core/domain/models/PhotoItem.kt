package com.thundermaps.saferme.core.domain.models

import android.os.Parcelable
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.domain.models.DiffItem
import java.util.UUID
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class PhotoItem(
    val id: String = UUID.randomUUID().toString(),
    val reportUuid: String,
    val path: String? = null,
    val url: String? = null,
    val attachmentId: Int? = null,
    val isDeletable: Boolean = false
) : DiffItem, Parcelable {
    override val uniqueId: Any
        get() = id
    val isAddItem get() = listOfNotNull(path, url).isEmpty()
}
