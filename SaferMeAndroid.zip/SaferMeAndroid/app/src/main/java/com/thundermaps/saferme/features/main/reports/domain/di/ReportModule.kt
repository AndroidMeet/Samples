package com.thundermaps.saferme.features.main.reports.domain.di

import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.authentication.SessionsManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object ReportModule {
    @Provides
    fun provideReportManager(
        obsidianApi: ObsidianApi
    ): ReportManager = obsidianApi.reportManager

    @Provides
    fun provideSessionsManager(
        obsidianApi: ObsidianApi
    ): SessionsManager = obsidianApi.provideSessionsManager()
}
