package com.thundermaps.saferme.features.main.reports

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ReportManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class ReportsTabViewModel @Inject constructor(
    app: SaferMeApplication,
    private val reportManager: ReportManager,
    private val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    val titles: List<String> by lazy { app.resources.getStringArray(R.array.report_tabs).toList() }
    fun syncReport() {
        viewModelScope.launch(dispatcherContext.io) {
            reportManager.reportSync.synchronize()
        }
    }
}
