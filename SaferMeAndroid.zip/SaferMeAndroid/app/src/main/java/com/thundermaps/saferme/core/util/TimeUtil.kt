package com.thundermaps.saferme.core.util

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TimeUtil {
    private const val ISO_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZZZZ"
    private const val ISO_DATE_FORMAT_WITH_MS = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZ"
    private const val ISO_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
    private const val TIME_SHORT_FORMAT = "hh:mma"

    private val dateMediumFormat by lazy {
        DateFormat.getDateInstance(DateFormat.MEDIUM)
    }

    private val timeShortFormat by lazy {
        SimpleDateFormat(TIME_SHORT_FORMAT, Locale.getDefault())
    }

    private val isoDateFormat by lazy {
        SimpleDateFormat(ISO_DATE_FORMAT, Locale.getDefault())
    }
    private val isoTimeFormat by lazy {
        SimpleDateFormat(ISO_TIME_FORMAT, Locale.getDefault())
    }

    private val isoDateFormatWithMS by lazy {
        SimpleDateFormat(ISO_DATE_FORMAT_WITH_MS, Locale.getDefault())
    }

    fun convertIsoDateStringToDate(dateInString: String): Date? = try {
        isoDateFormat.parse(dateInString)
    } catch (exception: Exception) {
        null
    }

    fun Date?.toMediumDateInString(): String? = this?.let { dateMediumFormat.format(it) }

    fun Date?.toShortTimeInString(): String? = this?.let { timeShortFormat.format(it) }

    fun getIsoDateInString(): String = isoTimeFormat.format(Date())

    fun convertIsoDateToString(it: Date): String {
        return isoTimeFormat.format(it.time)
    }

    fun convertIsoDateStringToDateWithMS(dateInString: String): Date? = try {
        isoDateFormatWithMS.parse(dateInString)
    } catch (exception: Exception) {
        null
    }
}
