package com.thundermaps.saferme.features.main.reportdetails.tasks

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.TaskItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.util.Deeplink
import com.thundermaps.saferme.databinding.FragmentTasksTabBinding
import com.thundermaps.saferme.features.main.createtask.CreateTaskFragment
import com.thundermaps.saferme.features.main.tasks.domain.model.CreateTaskData
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class TasksTabFragment :
    BaseFragment<FragmentTasksTabBinding, TasksTabViewModel>() {
    @Inject
    lateinit var taskAdapter: TasksTabAdapter
    override val viewModel: TasksTabViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_tasks_tab
    private val navController get() = findNavController()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.getString(UUID)?.let { reportId ->
            binding.setOnCreateTaskClicked {
                val request = Deeplink.createEditTaskDeeplinkRequest(
                    CreateTaskData(
                        reportId, null
                    )
                )
                navController.navigate(request)
            }

            taskAdapter.updateInterface(object : TaskItemInterface {
                override fun markAsComplete(item: TaskCardData) {
                    viewModel.markAsComplete(item)
                }

                override fun <T : Any> onItemSelected(item: T) {
                    (item as? TaskCardData)?.let {
                        val request = Deeplink.createTaskDetailsDeeplinkRequest(it)
                        navController.navigate(request)
                    }
                }
            })

            binding.recyclerView.adapter = taskAdapter
            binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())

            viewModel.loadTaskOfReport(reportId)
            viewModel.tasks.observe(viewLifecycleOwner) {
                taskAdapter.updateItems(it)
                taskAdapter.notifyDataSetChanged()
            }
            observerTaskUpdate()
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.hideToolBar()
    }

    private fun observerTaskUpdate() {
        navController.currentBackStackEntry?.savedStateHandle?.getLiveData<String>(
            CreateTaskFragment.TASK_KEY
        )?.observe(viewLifecycleOwner) {
            viewModel.updateTaskItem(TaskCardData.of(it))
        }
    }

    companion object {
        const val UUID = " uuid"
    }
}
