package com.thundermaps.saferme.features.main.reports.common

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.features.main.reports.domain.model.CardData

abstract class BaseReportsViewModel constructor(
    application: SaferMeApplication
) : AndroidViewModel(application) {
    internal val anonymous by lazy { application.getString(R.string.anonymous) }
    abstract fun getReports(): LiveData<List<CardData>>?
}
