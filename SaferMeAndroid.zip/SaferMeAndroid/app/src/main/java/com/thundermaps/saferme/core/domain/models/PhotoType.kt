package com.thundermaps.saferme.core.domain.models

import android.os.Parcelable
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import kotlinx.parcelize.Parcelize

@Parcelize
@ExcludeFromJacocoGeneratedReport
enum class PhotoType(val value: String) : Parcelable {
    CAMERA("camera"), LIBRARY("library")
}
