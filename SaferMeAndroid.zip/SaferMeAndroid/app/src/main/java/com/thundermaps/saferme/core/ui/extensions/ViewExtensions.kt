package com.thundermaps.saferme.core.ui.extensions

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.EditText
import androidx.core.view.children
import androidx.core.view.updateMargins

private const val EXTRA_LARGE_MARGIN_IN_DP = 32

private interface AnimationEndListener : Animation.AnimationListener {
    override fun onAnimationStart(animation: Animation?) {
    }

    override fun onAnimationRepeat(animation: Animation?) {
    }
}

fun View.translateAnimationUpVisible(callback: () -> Unit = {}) {
    val animate = createAnimateY(height.toFloat(), 0.0f, callback)
    startAnimation(animate)
    visibility = View.VISIBLE
}

fun View.translateAnimationUpGone(callback: () -> Unit = {}) {
    val animate = createAnimateY(0.0f, -top.toFloat() - height, callback)
    startAnimation(animate)
    visibility = View.GONE
}

fun View.translateAnimationDownGone(callback: () -> Unit = {}) {
    val animate = createAnimateY(0.0f, height.toFloat(), callback)
    startAnimation(animate)
    visibility = View.GONE
}

fun View.translateAnimationDownVisible(callback: () -> Unit = {}) {
    val animate = createAnimateY(-top.toFloat(), 0.0f, callback)
    startAnimation(animate)
    visibility = View.VISIBLE
}

private fun createAnimateY(
    fromYDelta: Float,
    toYDelta: Float,
    callback: () -> Unit = {}
): TranslateAnimation {
    val animate = TranslateAnimation(0.0f, 0.0f, fromYDelta, toYDelta)
    animate.duration = 300
    animate.fillAfter = true
    animate.setAnimationListener(object : AnimationEndListener {
        override fun onAnimationEnd(animation: Animation?) {
            callback()
        }
    })
    return animate
}

fun View.removeFromParent() {
    (parent as? ViewGroup)?.removeView(this)
}

fun View.marginTop(valueInDp: Int = EXTRA_LARGE_MARGIN_IN_DP) {
    (layoutParams as? ViewGroup.MarginLayoutParams)?.updateMargins(top = valueInDp)
}

@SuppressLint("ClickableViewAccessibility")
fun View.handleTouch(hideKeyboard: (callback: Boolean) -> Unit) {
    if (this !is EditText) {
        setOnTouchListener { _, _ ->
            hideKeyboard(true)
            false
        }
    }

    if (this is ViewGroup) {
        children.forEach {
            it.handleTouch(hideKeyboard)
        }
    }
}
