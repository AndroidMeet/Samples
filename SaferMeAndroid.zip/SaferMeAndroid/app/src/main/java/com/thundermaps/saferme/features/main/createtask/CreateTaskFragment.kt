package com.thundermaps.saferme.features.main.createtask

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentCreateTaskBinding
import com.thundermaps.saferme.features.main.dropdown.domain.model.SelectionOptionList
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CreateTaskFragment :
    BaseFragment<FragmentCreateTaskBinding, CreateTaskViewModel>() {
    private val args: CreateTaskFragmentArgs by navArgs()
    override fun provideLayoutId(): Int = R.layout.fragment_create_task
    override val viewModel: CreateTaskViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.storeCreateTaskData(args.data)
        viewModel.teamUsernames.observe(viewLifecycleOwner) { names ->
            names?.let {
                viewModel.createTaskData.task?.let {
                    it.assignee?.let { assignee -> viewModel.selectedUserPosition(assignee) }
                }
            }
        }

        binding.setAssignToClickListener {
            viewModel.teamUsernames.value?.let { list ->
                findNavController().navigate(
                    CreateTaskFragmentDirections.selectionOptionFragment(
                        SelectionOptionList(
                            list,
                            R.string.hint_assign_to,
                            SELECTION_OPTION
                        )
                    )
                )
            }
        }

        viewModel.createOrUpdateTask.observe(viewLifecycleOwner) { result ->
            if (result.isSuccess) {
                val navController = findNavController()
                val task = result.getNullableData()?.toJson()
                navController.previousBackStackEntry?.savedStateHandle?.set(TASK_KEY, task)
                navController.popBackStack()
            }
        }

        findNavController().currentBackStackEntry?.savedStateHandle?.getLiveData<String>(
            SELECTION_OPTION
        )?.observe(viewLifecycleOwner) { result ->
            viewModel.selectedUser(result)
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }

    companion object {
        internal const val TASK_KEY = "task"
        internal const val SELECTION_OPTION = "selection_option"
    }
}
