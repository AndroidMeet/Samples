package com.thundermaps.saferme.features.authentication.updatepassword

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.Screen
import com.thundermaps.saferme.core.ui.extensions.hideKeyboard
import com.thundermaps.saferme.core.ui.nextScreen
import com.thundermaps.saferme.databinding.FragmentUpdatePasswordBinding
import com.thundermaps.saferme.features.authentication.updatepassword.domain.UpdatePasswordViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class UpdatePasswordFragment : BaseFragment<FragmentUpdatePasswordBinding, UpdatePasswordViewModel>() {
    private val navigationController get() = findNavController()
    override val viewModel: UpdatePasswordViewModel by viewModels()
    private val args by navArgs<UpdatePasswordFragmentArgs>()

    override fun provideLayoutId(): Int = R.layout.fragment_update_password

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.setOldPassword(args.oldPassword)
        viewModel.updatePasswordResult.observe(viewLifecycleOwner) {
            if (it is Result.Loading) {
                requireActivity().hideKeyboard()
            } else if (it is Result.Success) {
                val data = it.data
                if (data.nextScreen() == Screen.SELECT_TEAM) {
                    navigationController.navigate(com.thundermaps.saferme.features.authentication.login.LoginFragmentDirections.openTeamsScreen())
                } else {
                    navigationController.navigate(UpdatePasswordFragmentDirections.openMainScreen())
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
        actionController?.hideNavigationIcon()
    }
}
