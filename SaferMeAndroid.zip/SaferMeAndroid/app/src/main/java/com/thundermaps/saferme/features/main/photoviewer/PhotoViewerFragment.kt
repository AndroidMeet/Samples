package com.thundermaps.saferme.features.main.photoviewer

import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.navigation.fragment.navArgs
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.ui.BottomNavigation
import com.thundermaps.saferme.core.util.formatString
import com.thundermaps.saferme.databinding.FragmentPhotoViewerBinding
import kotlinx.parcelize.Parcelize

class PhotoViewerFragment : Fragment() {
    private lateinit var binding: FragmentPhotoViewerBinding
    private val args: PhotoViewerFragmentArgs by navArgs()
    private val bottomNavigationController: BottomNavigation? get() = activity as? BottomNavigation
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentPhotoViewerBinding.inflate(inflater, container, false).also {
        binding = it
    }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.let {
            val data = args.data
            val adapter = PhotoViewAdapter(it, data.photos)
            binding.photoViewPager.adapter = adapter
            binding.photoViewPager.setCurrentItem(data.selectedPosition, false)
        }
    }

    override fun onResume() {
        super.onResume()
        bottomNavigationController?.makeBottomNavigationGone()
    }

    override fun onDestroy() {
        bottomNavigationController?.showBottomNavigation()
        super.onDestroy()
    }

    private inner class PhotoViewAdapter(
        activity: FragmentActivity,
        private val items: List<PhotoItem>
    ) : FragmentStateAdapter(activity) {
        override fun getItemCount(): Int = items.size
        override fun createFragment(position: Int): Fragment {
            return PhotoViewItemFragment(
                PhotoItemData(
                    (position + 1).formatString(),
                    items[position],
                    itemCount.formatString()
                )
            )
        }
    }
}

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class PhotoViewerData(
    val selectedPosition: Int,
    val photos: List<PhotoItem>
) : Parcelable
