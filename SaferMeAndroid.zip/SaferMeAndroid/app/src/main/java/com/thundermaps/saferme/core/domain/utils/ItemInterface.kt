package com.thundermaps.saferme.core.domain.utils

interface ItemInterface {
    fun <T : Any> onItemSelected(item: T) {}
    fun <T : Any> onItemDelete(item: T) {}
}
