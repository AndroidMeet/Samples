package com.thundermaps.saferme.core.domain.models

enum class MapType(val value: Int) {
    ROAD(0), SATELLITE(1)
}
