package com.thundermaps.saferme.features.main.createreport.models

import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.domain.models.DiffItem
import java.util.UUID

@ExcludeFromJacocoGeneratedReport
sealed class DynamicItem(
    val id: String = UUID.randomUUID().toString(),
    val value: String? = null,
    val isNumber: Boolean
) : DiffItem {
    @ExcludeFromJacocoGeneratedReport
    data class NumberItem(
        val numberId: String = UUID.randomUUID().toString(),
        val text: String? = null
    ) : DynamicItem(id = numberId, value = text, isNumber = true)
    @ExcludeFromJacocoGeneratedReport
    data class BulletItem(
        val bulletId: String = UUID.randomUUID().toString(),
        val text: String? = null
    ) : DynamicItem(id = bulletId, value = text, isNumber = false)

    override val uniqueId: Any
        get() = id
}
