package com.thundermaps.saferme.core.ui.input

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.thundermaps.domain.models.DiffItem

class CheckBoxInput(private val id: Long, val title: String, val pinEnabled: Boolean) : DiffItem {
    private val _isChecked = MutableLiveData(pinEnabled)
    val isChecked: LiveData<Boolean> = _isChecked

    override val uniqueId: Long
        get() = id

    fun updateCheck(value: Boolean) {
        _isChecked.postValue(value)
    }
}
