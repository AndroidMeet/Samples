package com.thundermaps.saferme.core.util

import androidx.core.net.toUri
import androidx.navigation.NavDeepLinkRequest
import com.mapbox.geojson.Point
import com.thundermaps.saferme.features.main.tasks.domain.model.CreateTaskData
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData

object Deeplink {
    private const val MAP = "saferme://map/"
    private const val REPORT_DETAILS = "saferme://reportdetails/"
    private const val TASK_DETAILS = "saferme://taskdetails/"
    private const val EDIT_TASK = "saferme://edittask/"

    fun createMapDeeplinkRequest(point: Point) = createDeeplinkRequest("$MAP${point.toJson()}")

    fun createReportDetailsDeeplinkRequest(uuid: String) = createDeeplinkRequest(
        "$REPORT_DETAILS$uuid"
    )

    fun createTaskDetailsDeeplinkRequest(task: TaskCardData) = createDeeplinkRequest(
        "$TASK_DETAILS${task.toJson()}"
    )

    fun createEditTaskDeeplinkRequest(data: CreateTaskData) = createDeeplinkRequest(
        "$EDIT_TASK${data.toJson()}"
    )

    private fun createDeeplinkRequest(uri: String) = NavDeepLinkRequest.Builder
        .fromUri(uri.toUri())
        .build()
}
