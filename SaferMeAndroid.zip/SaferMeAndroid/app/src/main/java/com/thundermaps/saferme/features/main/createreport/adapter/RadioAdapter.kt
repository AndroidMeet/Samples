package com.thundermaps.saferme.features.main.createreport.adapter

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.RadioButton
import androidx.annotation.LayoutRes
import com.thundermaps.apilib.android.api.responses.models.Option

class RadioAdapter(
    context: Context,
    @LayoutRes res: Int,
    val items: List<Option>,
    val itemSelect: (option: Option) -> Unit
) : ArrayAdapter<Option>(context, res, items) {
    private var selectedOption: Option? = null
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent)
        (view as? RadioButton)?.let {
            items.getOrNull(position)?.let { option ->
                it.text = option.label
                it.isChecked = selectedOption == option
                it.setOnClickListener {
                    itemSelect(option)
                }
            }
        }
        return view
    }

    fun updateSelectedItem(option: Option) {
        selectedOption = option
    }
}
