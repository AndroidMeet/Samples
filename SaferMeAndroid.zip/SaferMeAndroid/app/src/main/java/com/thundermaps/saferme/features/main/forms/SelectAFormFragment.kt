package com.thundermaps.saferme.features.main.forms

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.models.ReportData
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentSelectAFormBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SelectAFormFragment : BaseFragment<FragmentSelectAFormBinding, SelectAFormViewModel>(),
    ItemInterface {
    @Inject
    lateinit var adapter: SelectAFormAdapter
    override val viewModel: SelectAFormViewModel by viewModels()
    override fun provideLayoutId(): Int = R.layout.fragment_select_a_form
    private val args: SelectAFormFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        configAdapter()
        viewModel.resetNumberOfSync()
        binding.swipeRefresh.setOnRefreshListener {
            refresh()
        }
    }

    private fun refresh() {
        viewModel.fetchChannels()
        binding.channelRecyclerview.veil()
    }

    private fun configAdapter() {
        adapter.updateInterface(this)
        DividerItemDecoration(requireContext(), LinearLayoutManager.VERTICAL).run {
            binding.channelRecyclerview.getRecyclerView().addItemDecoration(this)
        }
        binding.channelRecyclerview.addVeiledItems(NUMBER_SHIMMER_ITEMS)
        binding.channelRecyclerview.setLayoutManager(LinearLayoutManager(requireContext()))
        viewModel.channels.observe(viewLifecycleOwner) {
            binding.swipeRefresh.isRefreshing = false
            if (it == null) {
                binding.channelRecyclerview.veil()
            } else {
                binding.channelRecyclerview.unVeil()
                adapter.updateItems(it)

                if (it.isEmpty() && viewModel.canAutoSync) {
                    refresh()
                }
            }
        }
        binding.channelRecyclerview.setAdapter(adapter)
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }

    override fun <T : Any> onItemSelected(item: T) {
        (item as? ObsidianChannel)?.let { channel ->
            args.searchResult?.let { searchResult ->
                val reportData = ReportData.Create(
                    searchResult,
                    channel
                )
                findNavController().navigate(
                    SelectAFormFragmentDirections.openCreateReport(
                        reportData
                    )
                )
            }
        }
    }

    companion object {
        private const val NUMBER_SHIMMER_ITEMS = 10
    }
}
