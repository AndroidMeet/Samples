package com.thundermaps.saferme.core.domain.models

import android.os.Parcelable
import com.mapbox.geojson.Point
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class CustomSearchResult(
    val address: String?,
    val location: Point
) : Parcelable
