package com.thundermaps.saferme.features.main.map.di

import com.saferme.obsidian.BrandManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.ShapesManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
class MapModule {
    @Provides
    fun provideBrandManager(
        obsidianApi: ObsidianApi
    ): BrandManager = obsidianApi.brandManager

    @Provides
    fun provideMapboxFeatureManager(
        obsidianApi: ObsidianApi
    ): ShapesManager = obsidianApi.shapesManager
}
