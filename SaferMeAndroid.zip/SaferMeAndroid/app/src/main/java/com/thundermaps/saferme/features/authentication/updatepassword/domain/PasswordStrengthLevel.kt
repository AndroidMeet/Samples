package com.thundermaps.saferme.features.authentication.updatepassword.domain

import androidx.annotation.ColorRes
import androidx.annotation.StringRes
import com.thundermaps.saferme.R

enum class PasswordStrengthLevel(@StringRes val text: Int, @ColorRes val colorRes: Int? = null) {
    TOO_WEAK(R.string.password_status_too_weak),
    WEAK(R.string.password_status_weak, R.color.password_weak),
    MEDIUM(R.string.password_status_medium, R.color.password_medium),
    STRONG(R.string.password_status_strong, R.color.password_strong);
    val percentageWidth: Float get() = ordinal.toFloat() / (values().size - 1).toFloat()
    companion object {
        val minLevel = TOO_WEAK
        fun ofLevel(level: Int) = if (level >= 0 && level < values().size) {
            values()[level]
        } else if (level < 0) {
            minLevel
        } else {
            STRONG
        }
    }
}
