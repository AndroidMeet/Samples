package com.thundermaps.saferme.features.main.profile.domain.di

import com.thundermaps.saferme.features.main.profile.domain.ProfileRepository
import com.thundermaps.saferme.features.main.profile.domain.ProfileRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
abstract class ProfileModule {
    @Binds
    abstract fun bindProfileRepository(
        profileRepository: ProfileRepositoryImpl
    ): ProfileRepository
}
