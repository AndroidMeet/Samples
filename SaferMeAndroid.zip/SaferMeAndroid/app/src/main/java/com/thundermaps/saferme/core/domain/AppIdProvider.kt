package com.thundermaps.saferme.core.domain

import com.thundermaps.saferme.BuildConfig
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppIdProvider @Inject constructor() {
    val appId = if (BuildConfig.DEBUG) BuildConfig.APPLICATION_ID.replace(
        ".debug",
        ""
    ) else BuildConfig.APPLICATION_ID
}
