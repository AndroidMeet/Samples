package com.thundermaps.saferme.core.domain.models

import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport

@ExcludeFromJacocoGeneratedReport
data class SelectAFormData(
    val searchResult: CustomSearchResult?,
    val willCreateReport: Boolean = false
)
