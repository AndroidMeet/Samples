package com.thundermaps.saferme.features.main.taskdetails

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentTaskDetailsBinding
import com.thundermaps.saferme.features.main.createtask.CreateTaskFragment
import com.thundermaps.saferme.features.main.tasks.domain.model.CreateTaskData
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TaskDetailsFragment :
    BaseFragment<FragmentTaskDetailsBinding, TaskDetailsViewModel>() {
    private val args: TaskDetailsFragmentArgs by navArgs()
    override fun provideLayoutId(): Int = R.layout.fragment_task_details
    override val viewModel: TaskDetailsViewModel by viewModels()

    private val deleteTaskDialog by lazy {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.delete_task_title)
            .setMessage(R.string.delete_task_description)
            .setPositiveButton(R.string.btn_delete_task) { dialog, _ ->
                dialog.dismiss()
                viewModel.deleteTask()
                navController.popBackStack()
            }
            .setNegativeButton(R.string.btn_cancel) { dialog, _ ->
                dialog.dismiss()
            }
            .create()
    }
    private val navController get() = findNavController()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.veilLayout.veil()
        viewModel.setTaskData(TaskCardData.of(args.task))

        setHasOptionsMenu(true)
        observerTaskUpdate()

        viewModel.taskData.observe(viewLifecycleOwner) {
            navController.previousBackStackEntry?.savedStateHandle?.set(
                CreateTaskFragment.TASK_KEY,
                it.toJson()
            )
        }
        viewModel.reportData.observe(viewLifecycleOwner) {
            if (it != null) {
                binding.veilLayout.unVeil()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.menu_task_details, menu)
        viewModel.taskData.observe(viewLifecycleOwner) {
            menu.findItem(R.id.action_edit)?.isVisible = it.completedDate == null
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)
        return when (item.itemId) {
            R.id.action_edit -> {
                viewModel.taskData.value?.let { task ->
                    navController.navigate(
                        TaskDetailsFragmentDirections.openCreateTask(
                            CreateTaskData(
                                uuid = task.reportId ?: "",
                                task = task
                            ).toJson()
                        )
                    )
                }
                true
            }
            R.id.action_delete -> {
                deleteTaskDialog.show()
                true
            }
            else -> false
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
        actionController?.showNavigationIcon()
    }

    private fun observerTaskUpdate() {
        navController.currentBackStackEntry?.savedStateHandle?.getLiveData<String>(
            CreateTaskFragment.TASK_KEY
        )?.observe(viewLifecycleOwner) {
            binding.veilLayout.veil()
            viewModel.setTaskData(TaskCardData.of(it))
        }
    }
}
