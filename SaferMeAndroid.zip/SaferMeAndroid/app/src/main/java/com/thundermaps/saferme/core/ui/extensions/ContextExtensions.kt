package com.thundermaps.saferme.core.ui.extensions

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.TypedArray
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.TypedValue
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.thundermaps.saferme.BuildConfig
import com.thundermaps.saferme.R
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.concurrent.TimeUnit
import timber.log.Timber

fun Context.fetchAttributeColor(colorId: Int): Int {
    val typedValue = TypedValue()
    val typedArray: TypedArray = obtainStyledAttributes(typedValue.data, intArrayOf(colorId))
    val color = typedArray.getColor(0, 0)
    typedArray.recycle()
    return color
}

@SuppressLint("SimpleDateFormat")
fun Context.createImageFile(): File? {
    val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
    return getExternalFilesDir(Environment.DIRECTORY_PICTURES)?.let { storageDir ->
        try {
            File.createTempFile(
                "JPEG_${timeStamp}_",
                ".jpg",
                storageDir
            )
        } catch (ioException: IOException) {
            null
        }
    }
}

@SuppressLint("Range")
@Suppress("DEPRECATION")
fun Context.getImagePathOfSelectImage(uri: Uri): String? {
    val filePathColumn = arrayOf(MediaStore.Images.Media.DATA, MediaStore.Images.Media._ID)
    return contentResolver.query(
        uri,
        filePathColumn,
        null,
        null,
        null
    )?.let { cursor ->
        cursor.moveToFirst()
        val columnIndex = cursor.getColumnIndex(filePathColumn[0])
        Timber.e("data: ${cursor.getString(cursor.getColumnIndex(filePathColumn[0]))}")
        Timber.e("id: ${cursor.getString(cursor.getColumnIndex(filePathColumn[1]))}")
        cursor.getString(columnIndex).also { cursor.close() }
    }
}

fun Context.getImageUriForFile(file: File): Uri? {
    return FileProvider.getUriForFile(
        this,
        "${BuildConfig.APPLICATION_ID}.fileprovider",
        file
    )
}

fun Context.loadImageAsBitmap(url: String, callback: (bitmap: Bitmap) -> Unit) {
    try {
        Glide.with(this)
            .asBitmap()
            .load(url)
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(bitmap: Bitmap, transition: Transition<in Bitmap>?) {
                    callback(bitmap)
                }

                override fun onLoadCleared(drawable: Drawable?) {
                }
            })
    } catch (exception: Exception) {
    }
}

fun Context.getDueDateTime(time: Long): String {
    val diffInMilliseconds: Long = time - System.currentTimeMillis()

    val diffInDays: Long = TimeUnit.MILLISECONDS.toDays(diffInMilliseconds)

    return if (diffInDays > 0) {
        getString(R.string.due_in_days, diffInDays)
    } else {
        val diffInHours: Long = TimeUnit.MILLISECONDS.toHours(diffInMilliseconds)
        if (diffInHours > 0) {
            getString(R.string.due_in_hours, diffInHours)
        } else {
            val diffInMin: Long = TimeUnit.MILLISECONDS.toMinutes(diffInMilliseconds)
            val diffInSec: Long = TimeUnit.MILLISECONDS.toSeconds(diffInMilliseconds)
            getString(R.string.due_in_minutes, diffInMin, diffInSec)
        }
    }
}
