package com.thundermaps.saferme.features.main.changeorganization

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentChangeOrganizationBinding
import com.thundermaps.saferme.features.authentication.organization.domain.TeamAdapter
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ChangeOrganizationFragment :
    BaseFragment<FragmentChangeOrganizationBinding, ChangeOrganizationViewModel>(), ItemInterface {
    override val viewModel: ChangeOrganizationViewModel by viewModels()
    private val args: ChangeOrganizationFragmentArgs by navArgs()

    @Inject
    lateinit var adapter: TeamAdapter

    override fun provideLayoutId(): Int = R.layout.fragment_change_organization

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.syncTeams(args.team)
        binding.executePendingBindings()
        configAdapter()
    }

    private fun configAdapter() {
        binding.teamRecyclerView.setAdapter(adapter)
        adapter.updateInterface(this)
        DividerItemDecoration(requireContext(), LinearLayoutManager.VERTICAL).run {
            binding.teamRecyclerView.getRecyclerView().addItemDecoration(this)
        }
        binding.teamRecyclerView.setLayoutManager(LinearLayoutManager(requireContext()))
        binding.teamRecyclerView.addVeiledItems(NUMBER_SHIMMER_ITEMS)
        binding.teamRecyclerView.veil()
        viewModel.teams.observe(viewLifecycleOwner) { results ->
            adapter.updateItems(results)
            binding.teamRecyclerView.unVeil()
        }
    }

    override fun <T : Any> onItemSelected(item: T) {
        (item as? ObsidianTeam)?.let {
            viewModel.selectTeam(it)
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }

    companion object {
        private const val NUMBER_SHIMMER_ITEMS = 5
    }
}
