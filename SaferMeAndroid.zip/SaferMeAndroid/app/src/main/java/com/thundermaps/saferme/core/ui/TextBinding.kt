package com.thundermaps.saferme.core.ui

import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.databinding.BindingAdapter
import com.thundermaps.saferme.R

@BindingAdapter("bold")
fun TextView.bindBold(bold: Boolean?) {
    bold?.let {
        if (it) {
            setTypeface(typeface, Typeface.BOLD)
        } else {
            setTypeface(typeface, Typeface.NORMAL)
        }
    }
}

@BindingAdapter("iconStartWithNext")
fun TextView.iconStartWithNext(@DrawableRes icon: Int?) {
    icon?.let {
        setCompoundDrawablesWithIntrinsicBounds(it, 0, R.drawable.ic_next_settings, 0)
    }
}

@BindingAdapter("iconStart")
fun TextView.iconStart(@DrawableRes icon: Int?) {
    icon?.let {
        setCompoundDrawablesWithIntrinsicBounds(it, 0, 0, 0)
    }
}

fun TextView.drawableStart(icon: Drawable?) {
    icon?.let {
        setCompoundDrawablesWithIntrinsicBounds(it, null, null, null)
    }
}
