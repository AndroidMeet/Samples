package com.thundermaps.saferme.features.main.settings.domain.di

import com.thundermaps.saferme.features.main.settings.domain.DeviceDetailsRepository
import com.thundermaps.saferme.features.main.settings.domain.DeviceDetailsRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
abstract class DeviceDetailsModule {
    @Binds
    abstract fun bindDeviceDetailsRepository(
        deviceDetailsRepository: DeviceDetailsRepositoryImpl
    ): DeviceDetailsRepository
}
