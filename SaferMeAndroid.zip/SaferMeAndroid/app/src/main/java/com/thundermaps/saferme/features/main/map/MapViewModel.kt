package com.thundermaps.saferme.features.main.map

import androidx.annotation.VisibleForTesting
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.CameraState
import com.mapbox.maps.dsl.cameraOptions
import com.mapbox.turf.TurfConstants
import com.mapbox.turf.TurfJoins
import com.mapbox.turf.TurfTransformation
import com.saferme.obsidian.BrandManager
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.ShapesManager
import com.saferme.obsidian.store.resources.ObsidianReport
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.models.MapType
import com.thundermaps.saferme.core.domain.models.SelectAFormData
import com.thundermaps.saferme.core.domain.models.SmSearchSuggestion
import com.thundermaps.saferme.core.ui.extensions.toFeature
import com.thundermaps.saferme.core.usecase.MapOptionsUseCase
import com.thundermaps.saferme.core.usecase.ReportUseCase
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase.Companion.DEFAULT_POINT
import com.thundermaps.saferme.core.util.toPoint
import com.thundermaps.saferme.features.main.map.MapViewModel.Companion.startCameraOptions
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class MapViewModel @Inject constructor(
    val app: SaferMeApplication,
    private val reportUseCase: ReportUseCase,
    private val searchUseCase: SearchAddressUseCase,
    private val mapOptionsUseCase: MapOptionsUseCase,
    private val brandManager: BrandManager,
    private val shapesManager: ShapesManager,
    private val reportManager: ReportManager,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    val reporting: LiveData<Boolean> = reportUseCase.showingReport
    val isOpeningMapOptions: LiveData<Boolean> = mapOptionsUseCase.isOpeningMapOption

    val searchSuggestion: SmSearchSuggestion? get() = searchUseCase.currentSearchSuggestion
    val address = searchUseCase.address
    private val _isGpsVisible = MutableLiveData(false)

    val isGpsVisible: LiveData<Boolean> = _isGpsVisible
    private val _cameraOptions = MutableLiveData(CameraOptionStorage.value)

    val cameraOptions: LiveData<CameraOptions> = _cameraOptions
    private val obsidianBrand get() = brandManager.getBrandAsync()

    private val _createReportEvent = MediatorLiveData<SelectAFormData?>()
    val createReportEvent: LiveData<SelectAFormData?> = _createReportEvent

    private val _bubblePolygon = MutableLiveData<Polygon>()
    val bubblePolygon: LiveData<Polygon> = _bubblePolygon

    val shapeData = searchUseCase.shapeData
    private var lastRenderedShapes: FeatureCollection? = null

    private val _pins = MediatorLiveData<Map<String, List<Feature>>>()
    val pins: LiveData<Map<String, List<Feature>>> = _pins

    val selectedChannels = mapOptionsUseCase.selectedChannels

    private val mapboxStreetsStyle by lazy { app.getString(R.string.mapbox_streets) }
    private val satelliteStreetsStyle by lazy { app.getString(R.string.satellite_streets) }

    var canLocateToCurrentPosition = true
        private set

    var firstPinLayerId: String? = null

    val mapZoomLevel: Double
        get() = _cameraOptions.value?.zoom ?: obsidianBrand.value?.defaultZoom?.toDouble()
        ?: DEFAULT_MAP_ZOOM_LEVEL

    val isOpeningBottomView get() = reporting.value == true || isOpeningMapOptions.value == true

    val mapStyle: LiveData<String> = Transformations.map(mapOptionsUseCase.mapType) {
        if (it == MapType.SATELLITE) {
            satelliteStreetsStyle
        } else {
            mapboxStreetsStyle
        }
    }
    private val reports = mutableListOf<ObsidianReport>()

    init {
        if (CameraOptionStorage.value != startCameraOptions) {
            disableMoveToCurrentLocation()
        }
        obsidianBrand.value?.let {
            cameraOptions {
                zoom(it.defaultZoom.toDouble())
                center(it.location?.let { Point.fromLngLat(it.longitude, it.latitude) }
                    ?: DEFAULT_POINT)
            }
        } ?: startCameraOptions
        _createReportEvent.addSource(reportUseCase.creatingReport) {
            _createReportEvent.postValue(
                SelectAFormData(
                    searchResult = searchUseCase.addressSearchResult.value,
                    willCreateReport = it
                )
            )
        }
        viewModelScope.launch(dispatcherContext.io) {
            _pins.addSource(reportManager.readAllReportsByTeam()) { reports ->
                addReports(reports)
            }
        }
    }

    private fun addReports(newReports: List<ObsidianReport>) {
        this.reports.clear()
        this.reports.addAll(newReports)
        updatePins(this.reports, bubblePolygon.value)
    }

    private fun updatePins(reports: List<ObsidianReport>, bubble: Polygon?) {
        val mapData = mutableMapOf<String, List<Feature>>()
        reports.filterNot { it.appearance == NONE_APPEARANCE }.forEach { report ->
            report.appearance?.let { appearance ->
                report.location?.toPoint()?.let { point ->
                    val newAppearance = if (bubble != null && TurfJoins.inside(point, bubble)) {
                        "$appearance$ATTENTION_SUFFIX"
                    } else {
                        appearance
                    }
                    if (mapData.containsKey(newAppearance)) {
                        val appearancePins = mapData[newAppearance]?.toMutableList()
                        appearancePins?.add(report.toFeature(newAppearance))
                        appearancePins?.let { list ->
                            mapData[newAppearance] = list
                        }
                    } else {
                        mapData[newAppearance] = listOf(report.toFeature(newAppearance))
                    }
                }
            }
            _pins.postValue(mapData)
        }
    }

    fun showGpsButton() {
        _isGpsVisible.value = true
    }

    fun hideGpsButton() {
        canLocateToCurrentPosition = false
        _isGpsVisible.value = false
    }

    fun openMapOptions() {
        if (reporting.value == true) {
            reportUseCase.deactivateReport()
            searchUseCase.clearSearchPoint()
        }

        if (isOpeningMapOptions.value == false) {
            mapOptionsUseCase.openMapOptions()
        }
    }

    fun storeCameraOptions(cameraState: CameraState) {
        if (cameraState.center != _cameraOptions.value?.center) {
            _cameraOptions.value = cameraOptions {
                zoom(cameraState.zoom)
                center(cameraState.center)
                bearing(cameraState.bearing)
                pitch(cameraState.pitch)
                padding(cameraState.padding)
            }.also { CameraOptionStorage.value = it }
        }
    }

    fun updateCameraOption(point: Point) {
        if (point != _cameraOptions.value?.center) {
            val currentOption = _cameraOptions.value
            _cameraOptions.value = cameraOptions {
                center(point)
                zoom(if (mapZoomLevel > 0.0) mapZoomLevel else DEFAULT_MAP_ZOOM_LEVEL)
                padding(currentOption?.padding)
                pitch(currentOption?.pitch)
            }.also { CameraOptionStorage.value = it }
        }
    }

    fun closeBottomViews() {
        if (reporting.value == true) {
            reportUseCase.deactivateReport()
            searchUseCase.clearSearchPoint()
        }

        if (isOpeningMapOptions.value == true) {
            mapOptionsUseCase.closeMapOptions()
        }
    }

    fun searchAddress(point: Point) {
        searchUseCase.clearSearchSuggestion()
        viewModelScope.launch(dispatcherContext.io) {
            searchUseCase.didSearch(point)
        }
    }

    fun updateIndicatorLocationChange(point: Point) {
        if (searchSuggestion == null && point != _cameraOptions.value?.center && canLocateToCurrentPosition) {
            updateCameraOption(point)
            hideGpsButton()
        }
        updateBubblePolygon(point)
    }

    private fun updateBubblePolygon(point: Point) {
        mapOptionsUseCase.clients?.radius?.let { radius ->
            val polygon = if (radius == 0f) {
                null
            } else {
                TurfTransformation.circle(
                    point,
                    (radius / 1000).toDouble(),
                    TurfConstants.UNIT_DEFAULT
                )
            }
            if (reports.isNotEmpty()) {
                updatePins(reports, polygon)
            }
            polygon?.let {
                _bubblePolygon.postValue(it)
            }
        }
    }

    fun closeBottomViewsIfNeeded() {
        if (isOpeningBottomView) {
            closeBottomViews()
            searchUseCase.clearSearch()
        }
    }

    fun gpsButtonClicked(cameraState: CameraState) {
        storeCameraOptions(cameraState)
        enableMoveToCurrentLocation()
        searchUseCase.clearSearch()
    }

    fun resetCreatingReport() {
        reportUseCase.resetCreatingReport()
    }

    fun activeReport() {
        reportUseCase.activateReport()
    }

    fun resetReportData() {
        _createReportEvent.value = null
    }

    fun searchAddressByPointIfNeeded(point: Point) {
        if (reporting.value == true && searchSuggestion == null) {
            searchAddress(point)
        }
    }

    override fun onCleared() {
        searchUseCase.clear()
        super.onCleared()
    }

    fun syncFeatureCollection() {
        viewModelScope.launch(dispatcherContext.io) {
            shapesManager.sync()
        }
    }

    @VisibleForTesting
    fun invokeOnClear() {
        onCleared()
    }

    private fun enableMoveToCurrentLocation() {
        canLocateToCurrentPosition = true
    }

    fun disableMoveToCurrentLocation() {
        canLocateToCurrentPosition = false
    }

    fun canRender(shapes: FeatureCollection): Boolean =
        (shapes != lastRenderedShapes).also { lastRenderedShapes = shapes }

    fun selectedChannels(channelList: List<Long>) {
        viewModelScope.launch(dispatcherContext.io) {
            addReports(reportManager.readReportByChannels(channelList))
        }
    }

    companion object {
        @VisibleForTesting
        const val DEFAULT_MAP_ZOOM_LEVEL = 16.0

        internal val startCameraOptions: CameraOptions = cameraOptions {
            zoom(DEFAULT_MAP_ZOOM_LEVEL)
            center(DEFAULT_POINT)
        }

        @VisibleForTesting
        const val DEFAULT_SAFETY_RADIUS_IN_KM = 0.15

        private const val NONE_APPEARANCE = "none"
        private const val ATTENTION_SUFFIX = "_attention"
    }
}

@ExcludeFromJacocoGeneratedReport
object CameraOptionStorage {
    var value = startCameraOptions
}
