package com.thundermaps.saferme.features.main.tasks.common

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.utils.TaskItemInterface
import com.thundermaps.saferme.core.ui.adapter.TaskBaseAdapter
import com.thundermaps.saferme.databinding.ItemTaskBinding
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import javax.inject.Inject

class TaskAdapter @Inject constructor() :
    TaskBaseAdapter<TaskCardData, TaskAdapter.Companion.TaskHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskHolder =
        TaskHolder(
            ItemTaskBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: TaskHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, taskItemInterface)
        }
    }

    companion object {
        class TaskHolder(
            private val binding: ItemTaskBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: TaskCardData, taskItemInterface: TaskItemInterface?) {
                binding.taskCardData = item

                binding.setOnMarkAsCompleteClicked {
                    taskItemInterface?.markAsComplete(item)
                }

                binding.setOnViewReportClicked {
                    taskItemInterface?.onViewReportSelected(item)
                }

                binding.setOnViewTaskClicked {
                    taskItemInterface?.onViewTaskSelected(item)
                }
            }
        }
    }
}
