package com.thundermaps.saferme.core.ui.extensions

import android.content.res.Resources

fun Int.dpToPx(): Float {
    val density = Resources.getSystem().displayMetrics.density
    return this * density
}
