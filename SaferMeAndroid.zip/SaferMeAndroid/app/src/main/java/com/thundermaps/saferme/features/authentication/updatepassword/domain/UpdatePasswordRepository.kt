package com.thundermaps.saferme.features.authentication.updatepassword.domain

import android.content.res.Resources
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.requests.models.UpdatePasswordBody
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.core.domain.AppIdProvider
import javax.inject.Inject

interface UpdatePasswordRepository {
    suspend fun updatePassword(passwordBody: UpdatePasswordBody): Result<Sessions>
}

class UpdatePasswordRepositoryImpl @Inject constructor(
    private val obsidianApi: ObsidianApi,
    private val appIdProvider: AppIdProvider
) : UpdatePasswordRepository {
    override suspend fun updatePassword(passwordBody: UpdatePasswordBody): Result<Sessions> {
        val result = obsidianApi.meManager.updatePassword(passwordBody)
        return if (result.isSuccess) {
            val sessions = updateCredential()
            if (sessions != null) {
                Result.Success(sessions)
            } else {
                Result.Error<Sessions>(null, Resources.NotFoundException())
            }
        } else {
            Result.Error(null, (result as Result.Error).exception)
        }
    }

    private suspend fun updateCredential(): Sessions? {
        val sessionsManager = obsidianApi.provideSessionsManager()
        return sessionsManager.getSessions()?.copy(passwordUpdatePending = false)?.also {
            sessionsManager.saveSessions(it, appIdProvider.appId)
        }
    }
}
