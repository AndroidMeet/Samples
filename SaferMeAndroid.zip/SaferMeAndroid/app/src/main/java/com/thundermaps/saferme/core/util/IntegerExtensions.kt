package com.thundermaps.saferme.core.util

fun Int.formatString(numberDigit: Int = 2) = String.format("%0${numberDigit}d", this)
