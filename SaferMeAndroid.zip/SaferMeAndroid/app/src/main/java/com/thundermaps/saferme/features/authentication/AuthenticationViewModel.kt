package com.thundermaps.saferme.features.authentication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class AuthenticationViewModel @Inject constructor(
    private val repo: AuthenticationRepository,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    fun getUserDetails() {
        viewModelScope.launch(dispatcherContext.io) {
            repo.getUserDetails()
        }
    }
}
