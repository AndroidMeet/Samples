package com.thundermaps.saferme.features.main.reports

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.tabs.TabLayoutMediator
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.adapter.CollectionAdapter
import com.thundermaps.saferme.databinding.FragmentReportsTabBinding
import com.thundermaps.saferme.features.main.reports.all.AllReportsFragment
import com.thundermaps.saferme.features.main.reports.domain.model.CardData
import com.thundermaps.saferme.features.main.reports.my.MyReportsFragment
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ReportsTabFragment : BaseFragment<FragmentReportsTabBinding, ReportsTabViewModel>(),
    ItemInterface {
    override val viewModel: ReportsTabViewModel by viewModels()
    override fun provideLayoutId(): Int = R.layout.fragment_reports_tab

    @Inject
    lateinit var myReportsFragment: MyReportsFragment

    @Inject
    lateinit var allReportsFragment: AllReportsFragment

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.syncReport()

        binding.pager.adapter = CollectionAdapter(
            this,
            listOf(allReportsFragment, myReportsFragment)
        )
        TabLayoutMediator(binding.tabLayout, binding.pager) { tab, position ->
            tab.text = viewModel.titles[position]
        }.attach()
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
        actionController?.hideNavigationIcon()
    }

    override fun <T : Any> onItemSelected(item: T) {
        (item as? CardData)?.let {
            findNavController().navigate(ReportsTabFragmentDirections.openReportDetails(it.id))
        }
    }
}
