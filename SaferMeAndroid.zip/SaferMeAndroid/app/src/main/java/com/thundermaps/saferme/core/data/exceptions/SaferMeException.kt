package com.thundermaps.saferme.core.data.exceptions

import com.thundermaps.apilib.android.api.responses.models.ResponseError
import java.io.IOException

class SaferMeException(val responseError: ResponseError?) : IOException(responseError?.errors?.firstOrNull())
