package com.thundermaps.saferme.core.util

fun Double.formatString(decimals: Int) = "%.${decimals}f".format(this)
