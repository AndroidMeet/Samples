package com.thundermaps.saferme.features.authentication

import com.raygun.raygun4android.RaygunClient
import com.raygun.raygun4android.messages.shared.RaygunUserInfo
import com.saferme.obsidian.ObsidianApi
import javax.inject.Inject

class AuthenticationRepository @Inject constructor(
    private val obsidianApi: ObsidianApi
) {
    private val sessionsManager = obsidianApi.provideSessionsManager()
    suspend fun getUserDetailsIfNeeded() {
        val userDetails = sessionsManager.userDetails
        if (userDetails == null) {
            getUserDetails()
        }
    }

    suspend fun getClientsIfNeeded() {
        val clients = sessionsManager.clients
        if (clients == null) {
            getClients()
        }
    }

    suspend fun getUserDetails() {
        obsidianApi.meManager.getUserDetails().getNullableData()?.let { userDetails ->
            val info = RaygunUserInfo(
                userDetails.id.toString(),
                userDetails.firstName,
                "${userDetails.firstName} ${userDetails.lastName}",
                userDetails.email
            )
            RaygunClient.setUser(info)
            sessionsManager.updateUserDetails(userDetails)
            switchTeam()
        }
    }

    private suspend fun switchTeam() {
        sessionsManager.getSessions()?.teamId?.let {
            obsidianApi.stateManager.switchTeamAndSyncStates(it.toInt())
        }
    }

    suspend fun getClients() {
        obsidianApi.meManager.getClients().getNullableData()?.let {
            sessionsManager.updateClients(it)
        }
    }
}
