package com.thundermaps.saferme.core.data.repo

import androidx.lifecycle.LiveData
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.core.domain.AppIdProvider
import javax.inject.Inject

interface TeamRepository {
    val teams: LiveData<List<ObsidianTeam>>
    suspend fun syncTeam()
    suspend fun selectTeam(teamId: Long): Sessions?
}

class TeamRepositoryImpl @Inject constructor(
    private val obsidianApi: ObsidianApi,
    private val appIdProvider: AppIdProvider
) : TeamRepository {
    override val teams: LiveData<List<ObsidianTeam>> = obsidianApi.teamManager.teams

    override suspend fun syncTeam() {
        obsidianApi.teamManager.syncTeam()
    }

    override suspend fun selectTeam(teamId: Long): Sessions? {
        val sessionsManager = obsidianApi.provideSessionsManager()
        val stateManager = obsidianApi.stateManager
        stateManager.switchTeamAndSyncStates(teamId.toInt())
        val sessions = sessionsManager.getSessions()?.copy(teamId = teamId)
        sessions?.let {
            sessionsManager.saveSessions(it, appIdProvider.appId)
        }
        return sessions
    }
}
