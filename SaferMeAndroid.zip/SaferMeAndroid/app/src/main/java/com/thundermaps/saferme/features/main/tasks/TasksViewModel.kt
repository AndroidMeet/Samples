package com.thundermaps.saferme.features.main.tasks

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.TaskManager
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.models.TaskCardType
import com.thundermaps.saferme.core.ui.extensions.replace
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.Date
import javax.inject.Inject
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

@HiltViewModel
class TasksViewModel @Inject constructor(
    app: SaferMeApplication,
    private val taskManager: TaskManager,
    private val reportManager: ReportManager,
    private val sessionsManager: SessionsManager,
    private val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private val mutableCards = mutableListOf<TaskCardData>()
    private val _taskCards = MediatorLiveData<List<TaskCardData>>()
    val taskCards: LiveData<List<TaskCardData>> = _taskCards

    private val _syncTask = MutableLiveData<Result<Unit>>()
    val syncTask: LiveData<Result<Unit>> = _syncTask

    private var activeObserve = false

    private val anonymous by lazy {
        app.getString(R.string.anonymous)
    }

    init {
        syncTasks()
        startObserveIfNeeded()
    }

    fun startObserveIfNeeded() {
        if (activeObserve) return
        sessionsManager.userDetails?.let { userDetails ->
            val userId = userDetails.id.toInt()
            activeObserve = true
            _taskCards.addSource(reportManager.readAssignedReports(userId)) { reports ->
                reports?.map { report ->
                    TaskCardData.of(report)
                }?.let { taskCards ->
                    updateTaskCards(taskCards, TaskCardType.REPORT)
                }
            }

            _taskCards.addSource(taskManager.readUserTask(userId)) { tasks ->
                val taskCards = tasks.map { TaskCardData.of(it, anonymous, anonymous) }
                updateTaskCards(taskCards, TaskCardType.TASK)
                updateReportTitles(taskCards)
            }
        }
    }

    private fun updateTaskCards(taskCards: List<TaskCardData>, type: TaskCardType) {
        val currentCards =
            mutableListOf<TaskCardData>().apply {
                addAll(mutableCards.filter { it.type != type })
                addAll(taskCards)
            }
        mutableCards.clear()
        mutableCards.addAll(currentCards)
        _taskCards.postValue(currentCards.sortedByDescending { it.createdDate })
    }

    private fun updateReportTitles(taskCards: List<TaskCardData>) {
        viewModelScope.launch(dispatcherContext.io) {
            val mutableTasks = taskCards.toMutableList()
            var needUpdate = false
            taskCards.map { task ->
                task.reportId?.let {
                    async { reportManager.getReportTitle(it) }
                }
            }.mapIndexed { index, deferred ->
                deferred?.await()?.let { title ->
                    needUpdate = true
                    val existTask = mutableTasks[index]
                    mutableTasks.replace(existTask, existTask.copy(reportTitle = title))
                }
            }

            if (needUpdate) {
                updateTaskCards(mutableTasks, TaskCardType.TASK)
            }
        }
    }

    fun syncTasks() {
        _syncTask.value = Result.Loading(Unit)
        viewModelScope.launch(dispatcherContext.io) {
            val job = launch { taskManager.TaskSync().synchronize() }
            job.join()
            _syncTask.postValue(Result.Success(Unit))
        }
    }

    fun markAsComplete(item: TaskCardData) {
        viewModelScope.launch(dispatcherContext.io) {
            taskManager.update(TaskCardData.toObsidian(item.copy(completedDate = Date())))
        }
    }
}
