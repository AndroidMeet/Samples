package com.thundermaps.saferme.core.domain.utils

import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData

interface TaskItemInterface : ItemInterface {
    fun onViewTaskSelected(item: TaskCardData) {}
    fun onViewReportSelected(item: TaskCardData) {}
    fun markAsComplete(item: TaskCardData)
}
