package com.thundermaps.saferme.features.authentication.forgotpassword

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.viewModelScope
import com.thundermaps.apilib.android.api.requests.models.EmailBody
import com.thundermaps.apilib.android.api.resources.SessionsResource
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.AppIdProvider
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import com.thundermaps.saferme.core.ui.input.verifyEmail
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class ForgotPasswordViewModel @Inject constructor(
    private val app: Application,
    private val sessionsResource: SessionsResource,
    private val dispatcherContext: DispatcherContext,
    private val appIdProvider: AppIdProvider
) : AndroidViewModel(app) {
    val emailInput = TextFieldInput(app.getString(R.string.login_email))
    val isResetPasswordEnabled: LiveData<Boolean> = Transformations.map(emailInput.error) {
        it.isNullOrEmpty()
    }

    private val _requestStatus: MutableLiveData<Result<String>> = MutableLiveData(Result.Initial)
    val requestStatus: LiveData<Result<String>> = _requestStatus

    private val emailEmptyError by lazy { app.getString(R.string.login_email_empty_error) }
    private val emailInvalid by lazy { app.getString(R.string.login_email_invalid) }

    fun checkEmail() = emailInput.verifyEmail(emailEmptyError, emailInvalid)

    fun requestChangePassword() {
        viewModelScope.launch(dispatcherContext.io) {
            emailInput.text.value?.let {
                _requestStatus.postValue(Result.Loading(null))
                val result = sessionsResource.requestPassword(EmailBody(it), appIdProvider.appId)
                _requestStatus.postValue(result)
            }
        }
    }
}
