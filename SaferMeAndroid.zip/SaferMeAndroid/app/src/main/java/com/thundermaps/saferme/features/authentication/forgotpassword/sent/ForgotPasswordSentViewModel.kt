package com.thundermaps.saferme.features.authentication.forgotpassword.sent

import android.app.Application
import android.text.Html
import android.text.Spanned
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.thundermaps.saferme.R
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ForgotPasswordSentViewModel @Inject constructor(
    private val app: Application
) : AndroidViewModel(app) {
    private val emailLiveData = MutableLiveData("")
    val sentSpannedMessage: LiveData<Spanned> = Transformations.map(emailLiveData) {
        val sentMessage = app.getString(R.string.forgot_password_send_message_placeholder, "<b>$it</b>")
        sentMessage.toSpannedText()
    }

    fun updateEmail(email: String) {
        emailLiveData.postValue(email)
    }
}

internal fun String.toSpannedText() = Html.fromHtml(this, Html.FROM_HTML_MODE_COMPACT)
