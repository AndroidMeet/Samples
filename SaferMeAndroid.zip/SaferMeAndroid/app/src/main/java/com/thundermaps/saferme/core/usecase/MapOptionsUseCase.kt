package com.thundermaps.saferme.core.usecase

import android.content.Context
import androidx.annotation.VisibleForTesting
import androidx.core.content.edit
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.preference.PreferenceManager
import com.saferme.obsidian.ChannelManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.apilib.android.api.responses.models.Clients
import com.thundermaps.saferme.core.domain.models.MapType
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MapOptionsUseCase @Inject constructor(
    @ApplicationContext private val context: Context,
    private val obsidianApi: ObsidianApi
) {
    private val channelManager: ChannelManager = obsidianApi.channelsManager

    private val _isOpeningMapOption = MutableLiveData(false)
    val isOpeningMapOption: LiveData<Boolean> = _isOpeningMapOption

    private val _mapType = MutableLiveData<MapType>()
    val mapType: LiveData<MapType> = _mapType

    private var _selectedChannels = MediatorLiveData<List<ObsidianChannel>>()
    val selectedChannels: LiveData<List<ObsidianChannel>> = _selectedChannels

    val clients: Clients? get() = obsidianApi.provideSessionsManager().clients

    private val sharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(context)
    }

    init {
        _mapType.postValue(
            MapType.values().firstOrNull {
                it.value == sharedPreferences.getInt(
                    MAP_TYPE_KEY,
                    MapType.ROAD.value
                )
            })
    }

    fun loadEnabledChannels() {
        _selectedChannels.addSource(channelManager.enabledChannels) {
            _selectedChannels.postValue(it)
        }
    }

    suspend fun loadChannels(): List<ObsidianChannel> = channelManager.syncChannels()

    suspend fun updateChannel(channel: ObsidianChannel) {
        channelManager.updateChannel(channel)
    }

    fun updateMapType(mapType: MapType) {
        _mapType.postValue(mapType)
        sharedPreferences.edit {
            putInt(MAP_TYPE_KEY, mapType.value)
        }
    }

    fun openMapOptions() {
        _isOpeningMapOption.value = true
    }

    fun closeMapOptions() {
        _isOpeningMapOption.value = false
    }

    companion object {
        @VisibleForTesting
        const val MAP_TYPE_KEY = "MapTypeKey"
    }
}
