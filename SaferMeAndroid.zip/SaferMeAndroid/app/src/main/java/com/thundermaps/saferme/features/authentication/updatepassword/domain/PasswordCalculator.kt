package com.thundermaps.saferme.features.authentication.updatepassword.domain

import com.nulabinc.zxcvbn.Zxcvbn
import javax.inject.Inject

interface PasswordCalculator {
    fun measurePassword(password: String): PasswordStrengthLevel
}

class PasswordCalculatorImpl @Inject constructor(
    private val zxcvbn: Zxcvbn
) : PasswordCalculator {
    override fun measurePassword(password: String): PasswordStrengthLevel {
        return PasswordStrengthLevel.ofLevel(zxcvbn.measure(password).score)
    }
}
