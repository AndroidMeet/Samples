package com.thundermaps.saferme.features.main.search

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.models.SmSearchSuggestion
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.databinding.ItemSearchBinding
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchAdapter @Inject constructor() :
    RecyclerView.Adapter<SearchAdapter.Companion.SearchSuggestionHolder>() {
    private val saferMeSearchSuggestions = mutableListOf<SmSearchSuggestion>()
    private var itemInterface: ItemInterface? = null
    fun updateInterface(itemInterface: ItemInterface) {
        this.itemInterface = itemInterface
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateSaferMeSuggestions(suggestions: List<SmSearchSuggestion>) {
        saferMeSearchSuggestions.clear()
        saferMeSearchSuggestions.addAll(suggestions)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchSuggestionHolder =
        SearchSuggestionHolder(
            ItemSearchBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: SearchSuggestionHolder, position: Int) {
        saferMeSearchSuggestions.getOrNull(position)
            ?.let { item -> holder.bind(item, itemInterface) }
    }

    override fun getItemCount(): Int = saferMeSearchSuggestions.size

    companion object {
        class SearchSuggestionHolder(
            private val binding: ItemSearchBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(saferMeSearchSuggestion: SmSearchSuggestion, listener: ItemInterface?) {
                val onClick = View.OnClickListener {
                    listener?.onItemSelected(saferMeSearchSuggestion)
                }
                binding.searchSuggestion = saferMeSearchSuggestion
                binding.onSuggestionClick = onClick
            }
        }
    }
}
