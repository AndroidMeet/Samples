package com.thundermaps.saferme.features.main.dropdown

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.features.main.dropdown.domain.model.SelectionOptionData
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class SelectionOptionViewModel @Inject constructor(
    val app: SaferMeApplication,
    val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private val _options = MutableLiveData<List<SelectionOptionData>>()
    val options: LiveData<List<SelectionOptionData>> = _options

    fun setOptionsData(options: List<SelectionOptionData>) {
        _options.postValue(options)
    }
}
