package com.thundermaps.saferme.features.main.createreport.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.databinding.ItemAddPhotoBinding
import com.thundermaps.saferme.databinding.ItemPhotoBinding

class PhotoAdapter(private val hasAddItem: Boolean = true) : BaseAdapter<PhotoItem, RecyclerView.ViewHolder>() {
    override fun getItemViewType(position: Int): Int {
        return if (hasAddItem && position == itemCount - 1) {
            ADD_ITEM_TYPE
        } else {
            PHOTO_ITEM_TYPE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return if (viewType == PHOTO_ITEM_TYPE) {
            PhotoItemHolder(
                ItemPhotoBinding.inflate(
                    layoutInflater,
                    parent,
                    false
                )
            )
        } else {
            AddItemHolder(
                ItemAddPhotoBinding.inflate(
                    layoutInflater,
                    parent,
                    false
                )
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is PhotoItemHolder -> holder.bind(items[position], itemInterface)
            is AddItemHolder -> holder.bind(items[position], itemInterface)
            else -> {}
        }
    }

    companion object {
        private const val ADD_ITEM_TYPE = 0
        private const val PHOTO_ITEM_TYPE = 1

        class PhotoItemHolder(
            private val binding: ItemPhotoBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: PhotoItem, listener: ItemInterface?) {
                binding.setOnDeleteButtonClicked {
                    listener?.onItemDelete(item)
                }
                binding.setOnItemClicked {
                    listener?.onItemSelected(item)
                }
                binding.photo = item
            }
        }

        class AddItemHolder(
            private val binding: ItemAddPhotoBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: PhotoItem, listener: ItemInterface?) {
                binding.setOnAddButtonClicked {
                    listener?.onItemSelected(item)
                }
            }
        }
    }
}
