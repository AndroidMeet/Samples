package com.thundermaps.saferme.features.authentication.login.domain

import android.content.Context
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

@Suppress("RedundantSuspendModifier")
class AccountLocker @Inject constructor(@ApplicationContext context: Context) {
    private val lockedSetForStart = mutableSetOf<String>()

    private val sharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(context)
    }

    suspend fun isLocked(email: String) =
        sharedPreferences.getInt(
            email,
            DEFAULT_FAILURE_TIMES
        ) > MAX_FAILURE_TIMES && lockedSetForStart.contains(email)

    suspend fun lockAccount(email: String) {
        lockedSetForStart.add(email)
        sharedPreferences.edit(true) {
            putInt(email, MAX_FAILURE_TIMES + 1)
        }
    }

    suspend fun resetLockedAccount(email: String) {
        sharedPreferences.edit(true) {
            lockedSetForStart.remove(email)
            remove(email)
        }
    }

    suspend fun increaseFailureTimes(email: String) {
        increaseFailureTimes(email, 1)
    }

    private suspend fun increaseFailureTimes(email: String, times: Int) {
        lockedSetForStart.add(email)
        val currentTimes = sharedPreferences.getInt(email, DEFAULT_FAILURE_TIMES)
        sharedPreferences.edit(true) {
            putInt(email, currentTimes + times)
        }
    }

    companion object {
        private const val MAX_FAILURE_TIMES = 5
        const val DEFAULT_FAILURE_TIMES = 0
    }
}
