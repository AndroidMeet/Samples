package com.thundermaps.saferme.features.authentication.organization

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentTeamsBinding
import com.thundermaps.saferme.features.authentication.organization.domain.TeamAdapter
import com.thundermaps.saferme.features.authentication.organization.domain.TeamsViewModel
import com.thundermaps.saferme.features.authentication.updatepassword.UpdatePasswordFragmentDirections
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class TeamsFragment : BaseFragment<FragmentTeamsBinding, TeamsViewModel>(), ItemInterface {
    override val viewModel: TeamsViewModel by viewModels()

    @Inject
    lateinit var adapter: TeamAdapter

    override fun provideLayoutId(): Int = R.layout.fragment_teams

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.nextScreen.observe(viewLifecycleOwner) {
            findNavController().navigate(UpdatePasswordFragmentDirections.openMainScreen())
        }
        viewModel.syncTeams()
        configAdapter()
    }

    private fun configAdapter() {
        binding.teamRecyclerView.setAdapter(adapter)
        adapter.updateInterface(this)
        DividerItemDecoration(requireContext(), LinearLayoutManager.VERTICAL).run {
            binding.teamRecyclerView.getRecyclerView().addItemDecoration(this)
        }
        binding.teamRecyclerView.setLayoutManager(LinearLayoutManager(requireContext()))
        binding.teamRecyclerView.addVeiledItems(NUMBER_SHIMMER_ITEMS)
        binding.teamRecyclerView.veil()
        viewModel.teams.observe(viewLifecycleOwner) { results ->
            adapter.updateItems(results)
            binding.teamRecyclerView.unVeil()
        }
    }

    override fun <T : Any> onItemSelected(item: T) {
        (item as? ObsidianTeam)?.let {
            viewModel.selectTeam(it.id)
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
        actionController?.hideNavigationIcon()
    }

    companion object {
        private const val NUMBER_SHIMMER_ITEMS = 5
    }
}
