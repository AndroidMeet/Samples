package com.thundermaps.saferme.core.ui.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import androidx.annotation.RawRes
import com.thundermaps.saferme.databinding.DialogLoaderBinding

class LoaderDialog(
    context: Context,
    private val isCancel: Boolean,
    @RawRes private val fileRes: Int
) : Dialog(context) {
    private lateinit var binding: DialogLoaderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.requestFeature(Window.FEATURE_NO_TITLE)

        super.onCreate(savedInstanceState)

        binding = DialogLoaderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setCancelable(isCancel)
        binding.lottieAnimationView.setAnimation(fileRes)
    }
}
