package com.thundermaps.saferme.features.authentication.di

import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.resources.SessionsResource
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object AuthenticationModule {
    @Provides
    fun provideSessionsResource(obsidian: ObsidianApi): SessionsResource = obsidian.loginService
}
