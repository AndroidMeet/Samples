package com.thundermaps.saferme.core.domain.models

enum class TaskCardType(val value: Int) {
    TASK(0), REPORT(1)
}
