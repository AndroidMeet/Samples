package com.thundermaps.saferme.core.domain.models

import com.mapbox.geojson.Feature
import com.mapbox.geojson.Point
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport

@ExcludeFromJacocoGeneratedReport
data class ClosestFeature(
    val feature: Feature,
    val closestPoint: ClosestPoint
)

@ExcludeFromJacocoGeneratedReport
data class ClosestPoint(
    val distance: Double? = null,
    val closestPoint: Point
)
