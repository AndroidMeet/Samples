package com.thundermaps.saferme.core.ui.extensions

import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

const val REQUEST_MULTIPLE_PERMISSIONS = 1000

fun Fragment.checkAndRequestPermissions(permissions: List<String> = emptyList()): Boolean {
    if (permissions.isEmpty()) return true

    return context?.let { notNullContext ->
        val notGrantedPermissions = permissions.map {
            Pair(
                ContextCompat.checkSelfPermission(
                    notNullContext,
                    it
                ),
                it
            )
        }.filterNot { it.first == PackageManager.PERMISSION_GRANTED }.map { it.second }

        if (notGrantedPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                notGrantedPermissions.toTypedArray(),
                REQUEST_MULTIPLE_PERMISSIONS
            )
        }
        notGrantedPermissions.isEmpty()
    } ?: false
}
