package com.thundermaps.saferme.features.main.reports.common

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.databinding.CardReportBinding
import com.thundermaps.saferme.features.main.reports.domain.model.CardData
import javax.inject.Inject

class ReportAdapter @Inject constructor() : BaseAdapter<CardData, ReportAdapter.Companion.ReportHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReportHolder =
        ReportHolder(
            CardReportBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ReportHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, itemInterface)
        }
    }

    companion object {
        class ReportHolder(
            private val binding: CardReportBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: CardData, itemInterface: ItemInterface?) {
                binding.cardData = item
                binding.setOnCardClicked {
                    itemInterface?.onItemSelected(item)
                }
            }
        }
    }
}
