package com.thundermaps.saferme.core.ui.input

import androidx.databinding.BindingAdapter
import com.google.android.material.textfield.TextInputLayout

@BindingAdapter("app:errorMessage")
fun setErrorMessage(view: TextInputLayout, errorMessage: String?) {
    if (errorMessage.isNullOrEmpty()) {
        view.isErrorEnabled = false
        view.error = ""
    } else {
        view.error = errorMessage
        view.isErrorEnabled = true
    }
}
