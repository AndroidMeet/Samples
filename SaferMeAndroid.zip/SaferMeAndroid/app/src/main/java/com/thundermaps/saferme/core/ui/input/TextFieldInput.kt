package com.thundermaps.saferme.core.ui.input

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData

class TextFieldInput(override val title: String) : InputInterface {
    val text = MediatorLiveData<String>()
    override val isError: Boolean
        get() = mutableError.value?.isNotEmpty() == true
    private val mutableError = MutableLiveData<String?>()

    override fun showError(error: String?) {
        mutableError.value = error
    }

    override fun clearError() {
        mutableError.value = null
    }

    override val error: LiveData<String?> = mutableError
}
