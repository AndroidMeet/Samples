package com.thundermaps.saferme.features.main

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.onNavDestinationSelected
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeFirebaseMessagingService
import com.thundermaps.saferme.core.domain.models.TaskCardType
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.ActionBarInterface
import com.thundermaps.saferme.core.ui.BottomNavigation
import com.thundermaps.saferme.core.ui.extensions.translateAnimationDownGone
import com.thundermaps.saferme.core.ui.extensions.translateAnimationDownVisible
import com.thundermaps.saferme.core.ui.extensions.translateAnimationUpGone
import com.thundermaps.saferme.core.ui.extensions.translateAnimationUpVisible
import com.thundermaps.saferme.core.ui.input.CheckBoxInput
import com.thundermaps.saferme.core.util.Deeplink
import com.thundermaps.saferme.databinding.ActivityMainBinding
import com.thundermaps.saferme.features.main.adapter.ChannelFilterAdapter
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity(), ActionBarInterface, BottomNavigation {
    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private val viewModel: MainViewModel by viewModels()

    @Inject
    lateinit var adapter: ChannelFilterAdapter
    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        setSupportActionBar(binding.toolBar)
        setContentView(binding.root)
        navController =
            (supportFragmentManager.findFragmentById(R.id.navigationHostFragment) as NavHostFragment).navController
        if (::navController.isInitialized) {
            setupNavigationController()
        }

        binding.addReport.setOnClickListener {
            viewModel.openReportBottomView()
            selectMapTab()
        }

        viewModel.reporting.observe(this) {
            if (it) {
                makeBottomNavigationInvisible {
                    binding.reportBottomView.reportContent.translateAnimationUpVisible()
                    binding.pinImage.translateAnimationDownVisible()
                }
            } else {
                if (binding.pinImage.visibility == View.VISIBLE) {
                    binding.reportBottomView.reportContent.translateAnimationDownGone {
                        if (viewModel.isNotShowingBottomView) showBottomNavigation()
                    }
                    binding.pinImage.translateAnimationUpGone()
                }
            }
        }

        viewModel.openingMapOptions.observe(this) {
            if (it) {
                viewModel.loadChannel()

                makeBottomNavigationInvisible {
                    binding.mapOptionsBottomView.optionsContent.translateAnimationUpVisible()
                }
            } else {
                binding.mapOptionsBottomView.optionsContent.translateAnimationDownGone {
                    if (viewModel.isNotShowingBottomView) showBottomNavigation()
                }
            }
        }

        handleChannelFilter()
        viewModel.syncData()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleExtras(it) }
    }

    private fun handleExtras(intent: Intent) {
        intent.extras?.let { bundle ->
            if (bundle.containsKey(SaferMeFirebaseMessagingService.notificationType)) {
                when (bundle.getString(SaferMeFirebaseMessagingService.notificationType)) {
                    SaferMeFirebaseMessagingService.notificationTypeTask -> {
                        bundle.getString(SaferMeFirebaseMessagingService.keyTaskId)?.let { id ->

                            viewModel.checkTaskAvailable(id)
                            viewModel.taskId.observe(this) {
                                val request = Deeplink.createTaskDetailsDeeplinkRequest(
                                    TaskCardData(
                                        id = it,
                                        type = TaskCardType.TASK
                                    )
                                )
                                navController.navigate(request)
                            }
                        }
                    }
                    SaferMeFirebaseMessagingService.notificationTypeReport,
                    SaferMeFirebaseMessagingService.notificationTypeRefreshReport -> {
                        bundle.getString(SaferMeFirebaseMessagingService.keyReportUUID)?.let { id ->
                            viewModel.checkReportAvailable(id)
                            viewModel.reportId.observe(this) {
                                val request = Deeplink.createReportDetailsDeeplinkRequest(it)
                                navController.navigate(request)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun handleChannelFilter() {
        val channelCheckInterface = object : ItemInterface {
            override fun <T : Any> onItemSelected(item: T) {
                (item as? CheckBoxInput)?.let { inputItem ->
                    viewModel.updateChannel(
                        inputItem.uniqueId,
                        !(inputItem.isChecked.value ?: true)
                    )?.let {
                        adapter.notifyItemChanged(it)
                    }
                }
            }
        }

        val veilRecyclerView = binding.mapOptionsBottomView.mapChannelView.channelRecyclerview
        veilRecyclerView.setLayoutManager(LinearLayoutManager(this))
        adapter.updateInterface(channelCheckInterface)
        DividerItemDecoration(this, LinearLayoutManager.VERTICAL).run {
            veilRecyclerView.getRecyclerView().addItemDecoration(this)
        }
        viewModel.channelInputs.observe(this) { inputs ->
            adapter.updateItems(inputs)
        }

        veilRecyclerView.setAdapter(adapter)
        veilRecyclerView.addVeiledItems(NUMBER_SHIMMER_CHANNEL_ITEMS)
        viewModel.isLoadingChannel.observe(this) {
            if (it) veilRecyclerView.veil() else veilRecyclerView.unVeil()
        }
    }

    private fun selectMapTab() {
        binding.bottomNavigationView.selectedItemId = R.id.map
    }

    private fun setupNavigationController() {
        appBarConfiguration = AppBarConfiguration(navController.graph)
        binding.toolBar.setupWithNavController(navController, appBarConfiguration)
        binding.bottomNavigationView.setupWithNavController(navController)
    }

    override fun onResume() {
        super.onResume()
        viewModel.getUserDetailsIfNeeded()
        viewModel.getClientsIfNeeded()
        handleExtras(intent)
    }

    override fun hideToolBar() {
        binding.toolBarVisibility = View.GONE
    }

    override fun showToolBar() {
        binding.toolBarVisibility = View.VISIBLE
    }

    override fun showNavigationIcon() {
        binding.toolBar.setNavigationIcon(R.drawable.ic_baseline_arrow_back_24)
    }

    override fun hideNavigationIcon() {
        binding.toolBar.navigationIcon = null
    }

    override fun showBottomNavigation() {
        binding.visibility = View.VISIBLE
    }

    override fun makeBottomNavigationInvisible(onFinish: () -> Unit) {
        binding.visibility = View.INVISIBLE
        onFinish()
    }

    override fun makeBottomNavigationGone() {
        binding.visibility = View.GONE
    }

    override fun updateTitle(titleId: Int) {
        binding.toolBar.setTitle(titleId)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return item.onNavDestinationSelected(navController) || super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        if (!navController.popBackStack()) super.onBackPressed()
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration)
    }

    companion object {
        private const val NUMBER_SHIMMER_CHANNEL_ITEMS = 4
    }
}
