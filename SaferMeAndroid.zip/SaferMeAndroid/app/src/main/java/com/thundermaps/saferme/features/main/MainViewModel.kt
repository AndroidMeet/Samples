package com.thundermaps.saferme.features.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.common.util.VisibleForTesting
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.requests.models.FirebaseTokenBody
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.models.MapType
import com.thundermaps.saferme.core.ui.input.CheckBoxInput
import com.thundermaps.saferme.core.usecase.MapOptionsUseCase
import com.thundermaps.saferme.core.usecase.ReportUseCase
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase
import com.thundermaps.saferme.features.authentication.AuthenticationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch

@HiltViewModel
class MainViewModel @Inject constructor(
    private val authorizedRepo: AuthenticationRepository,
    private val reportUseCase: ReportUseCase,
    private val searchAddressUseCase: SearchAddressUseCase,
    private val mapOptionsUseCase: MapOptionsUseCase,
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext,
    private val firebaseInstance: FirebaseInstanceId
) : ViewModel() {
    val reporting: LiveData<Boolean> = reportUseCase.showingReport
    val openingMapOptions: LiveData<Boolean> = mapOptionsUseCase.isOpeningMapOption
    val address = searchAddressUseCase.address
    val mapType: LiveData<MapType> = mapOptionsUseCase.mapType
    private val channels = mutableListOf<ObsidianChannel>()
    private val _channelInputs = MutableLiveData<List<CheckBoxInput>>(emptyList())
    val channelInputs: LiveData<List<CheckBoxInput>> = _channelInputs

    private val _isLoadingChannel = MutableLiveData(false)
    val isLoadingChannel: LiveData<Boolean> = _isLoadingChannel

    val isNotShowingBottomView get() = !(reporting.value == true || openingMapOptions.value == true)
    private val _taskId = MutableLiveData<String>()
    val taskId = _taskId

    private val _reportId = MutableLiveData<String>()
    val reportId = _reportId

    init {
        viewModelScope.launch(dispatcherContext.io) {
            mapOptionsUseCase.loadEnabledChannels()
        }
    }

    fun loadChannel() {
        viewModelScope.launch(dispatcherContext.io) {
            channels.clear()
            _isLoadingChannel.postValue(channelInputs.value.isNullOrEmpty())
            channels.addAll(mapOptionsUseCase.loadChannels())
            _channelInputs.postValue(channels.map { channel ->
                CheckBoxInput(id = channel.id, title = channel.name, channel.pinEnable)
            })
            _isLoadingChannel.postValue(false)
        }
    }

    fun updateChannel(id: Long, checked: Boolean): Int? {
        channels.firstOrNull { id == it.id }?.let {
            updateChannel(it.copy(pinEnable = checked))
            _channelInputs.value?.firstOrNull { channelInput -> id == channelInput.uniqueId }
                ?.updateCheck(checked)
            return channels.indexOf(it)
        }
        return null
    }

    private fun updateChannel(channel: ObsidianChannel) {
        viewModelScope.launch(dispatcherContext.io) {
            mapOptionsUseCase.updateChannel(channel)
        }
    }

    fun openReportBottomView() {
        if (openingMapOptions.value == true) {
            mapOptionsUseCase.closeMapOptions()
        }
        searchAddressUseCase.clearSearchSuggestion()
        reportUseCase.activateReport()
    }

    fun closeReportView() {
        reportUseCase.deactivateReport()
    }

    fun closeMapOptions() {
        mapOptionsUseCase.closeMapOptions()
    }

    fun selectMapRoad() {
        mapOptionsUseCase.updateMapType(MapType.ROAD)
    }

    fun selectMapSatellite() {
        mapOptionsUseCase.updateMapType(MapType.SATELLITE)
    }

    fun getUserDetailsIfNeeded() {
        viewModelScope.launch(dispatcherContext.io) {
            authorizedRepo.getUserDetailsIfNeeded()
        }
    }

    fun getClientsIfNeeded() {
        viewModelScope.launch(dispatcherContext.io) {
            authorizedRepo.getClientsIfNeeded()
        }
    }

    fun createReport() {
        reportUseCase.createReportButtonClicked()
    }

    @ExcludeFromJacocoGeneratedReport
    fun syncData() {
        registerFcmToken()
        syncReports()
        syncTasks()
        syncChannelsAndCategories()
        syncTeamUsers()
        syncStates()
    }

    @VisibleForTesting
    fun syncChannelsAndCategories() {
        viewModelScope.launch(dispatcherContext.io) {
            val categoryManger = obsidianApi.categoryManager
            obsidianApi.channelsManager.syncChannels().map {
                async { categoryManger.syncCategory(it.id.toInt()) }
            }.awaitAll()
        }
    }

    @VisibleForTesting
    fun syncTeamUsers() {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.teamManager.syncTeamUsers()
        }
    }

    @VisibleForTesting
    fun syncReports() {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.reportManager.reportSync.synchronize()
        }
    }

    @VisibleForTesting
    fun syncTasks() {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.Tasks().TaskSync().synchronize()
        }
    }

    @VisibleForTesting
    fun syncStates() {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.stateManager.syncStates()
        }
    }

    private fun registerFcmToken() {
        firebaseInstance.instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    return@OnCompleteListener
                }
                task.result?.token?.let { token ->
                    viewModelScope.launch(dispatcherContext.io) {
                        obsidianApi.meManager.updateFirebaseToken(FirebaseTokenBody(token))
                    }
                }
            })
    }

    fun checkTaskAvailable(id: String) {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.Tasks().readOne(id).let {
                _taskId.postValue(id)
            }
        }
    }

    fun checkReportAvailable(id: String) {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.reportManager.readOne(id).let {
                _reportId.postValue(id)
            }
        }
    }
}
