package com.thundermaps.saferme.core.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import com.thundermaps.saferme.BR
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.dialog.LoaderDialog
import com.thundermaps.saferme.core.ui.extensions.removeFromParent

abstract class BaseFragment<T : ViewDataBinding, V : ViewModel> : Fragment() {
    val actionController: ActionBarInterface? get() = activity as? ActionBarInterface
    protected abstract val viewModel: V
    protected var isPersistenceView: Boolean = false
    protected val binding: T get() = _binding!!
    protected val bottomNavigationController: BottomNavigation? get() = requireActivity() as? BottomNavigation

    private var _binding: T? = null

    private val loaderDialog: LoaderDialog by lazy {
        LoaderDialog(
            context = requireContext(),
            isCancel = false,
            fileRes = R.raw.lottie_loader
        )
    }

    @LayoutRes
    abstract fun provideLayoutId(): Int

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        if (!isPersistenceView || _binding == null) {
            _binding = DataBindingUtil.inflate(inflater, provideLayoutId(), container, false)
            binding.lifecycleOwner = viewLifecycleOwner
            binding.setVariable(
                BR.viewModel,
                viewModel
            )
        } else {
            binding.root.removeFromParent()
        }

        return binding.root
    }

    override fun onDestroy() {
        _binding = null
        super.onDestroy()
    }

    fun showLoader() {
        loaderDialog.show()
    }

    fun hideLoader() {
        loaderDialog.dismiss()
    }
}
