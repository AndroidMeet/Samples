package com.thundermaps.saferme.features.main.reportdetails.tasks

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.utils.TaskItemInterface
import com.thundermaps.saferme.core.ui.adapter.TaskBaseAdapter
import com.thundermaps.saferme.databinding.ItemTaskTabBinding
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import javax.inject.Inject

class TasksTabAdapter @Inject constructor() :
    TaskBaseAdapter<TaskCardData, TasksTabAdapter.Companion.TaskHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskHolder =
        TaskHolder(
            ItemTaskTabBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: TaskHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, taskItemInterface)
        }
    }

    companion object {
        class TaskHolder(
            private val binding: ItemTaskTabBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: TaskCardData, taskItemInterface: TaskItemInterface?) {
                binding.taskCardData = item
                binding.setOnCardClicked {
                    taskItemInterface?.onItemSelected(item)
                }

                binding.setMarkAsRead {
                    taskItemInterface?.markAsComplete(item)
                }
            }
        }
    }
}
