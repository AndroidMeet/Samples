package com.thundermaps.saferme.features.main.reports.all

import androidx.fragment.app.viewModels
import com.thundermaps.saferme.features.main.reports.common.BaseReportsFragment
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class AllReportsFragment @Inject constructor() : BaseReportsFragment() {
    override val viewModel: AllReportsViewModel by viewModels()
}
