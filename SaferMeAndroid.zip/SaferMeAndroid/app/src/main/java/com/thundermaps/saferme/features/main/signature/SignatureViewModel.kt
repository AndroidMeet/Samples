package com.thundermaps.saferme.features.main.signature

import android.app.Application
import android.graphics.Bitmap
import androidx.annotation.VisibleForTesting
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.responses.models.FormFieldSignature
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.models.Signature
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import javax.inject.Inject
import kotlinx.coroutines.launch
import kotlinx.io.errors.IOException
import timber.log.Timber

@HiltViewModel
class SignatureViewModel @Inject constructor(
    private val app: Application,
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    val nameInput = TextFieldInput(app.getString(R.string.hint_name))

    @VisibleForTesting
    var sign: Bitmap? = null
    private var originalSignature: Signature? = null
    private val _signature = MutableLiveData<Result<Signature>>()
    val signature: LiveData<Result<Signature>> = _signature
    private val _isReadyToSave = MediatorLiveData<Boolean>()
    val isReadyToSave: LiveData<Boolean> = _isReadyToSave

    private lateinit var filePath: String
    val isReadyToPopBack: Boolean get() = originalSignature != _signature.value?.getNullableData()

    init {
        _isReadyToSave.addSource(nameInput.text) {
            _isReadyToSave.postValue(it.isNotEmpty() && sign != null)
        }
    }

    fun updateSignature(signature: Signature) {
        originalSignature = signature
        nameInput.text.value = signature.formFieldSignature?.signeeName ?: ""
        _signature.postValue(Result.Success(signature))
    }

    fun updateSign(sign: Bitmap?) {
        this.sign = sign
        sign?.let {
            viewModelScope.launch(dispatcherContext.io) {
                saveSignatureToLocal(it)
                _isReadyToSave.postValue(!nameInput.text.value.isNullOrEmpty())
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private fun saveSignatureToLocal(bitmap: Bitmap) {
        try {
            val file = File(app.cacheDir, "sign.png")
            filePath = file.absolutePath
            val fileOutputStream = FileOutputStream(file)
            bitmap.compress(
                Bitmap.CompressFormat.PNG,
                100,
                fileOutputStream
            )
            fileOutputStream.flush()
            fileOutputStream.close()
        } catch (fileNotFoundException: FileNotFoundException) {
            Timber.e(fileNotFoundException)
        } catch (ioException: IOException) {
            Timber.e(ioException)
        }
    }

    fun submitSignature() {
        if (::filePath.isInitialized) {
            val previousSignature = _signature.value?.getNullableData()
            _signature.postValue(Result.Loading(null))
            viewModelScope.launch(dispatcherContext.io) {
                obsidianApi.fileAttachmentManager.uploadPhoto(filePath)?.let { fileAttachment ->
                    previousSignature?.let {
                        val signature = it.copy(
                            formFieldSignature = FormFieldSignature(
                                fileAttachment.id,
                                fileAttachment.fileName ?: "",
                                fileAttachment.originalUrl,
                                nameInput.text.value ?: ""
                            )
                        )
                        _signature.postValue(Result.Success(signature))
                    }
                } ?: previousSignature?.let { _signature.postValue(Result.Success(it)) }
            }
        }
    }
}
