package com.thundermaps.saferme.features.main.taskdetails

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.store.resources.SafermePendingChange
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.features.main.reports.common.fullName
import com.thundermaps.saferme.features.main.reports.domain.model.CardData
import com.thundermaps.saferme.features.main.tasks.domain.model.TaskCardData
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.Date
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class TaskDetailsViewModel @Inject constructor(
    app: SaferMeApplication,
    val obsidianApi: ObsidianApi,
    val reportManager: ReportManager,
    val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private val taskManager = obsidianApi.Tasks()
    val anonymous by lazy { app.getString(R.string.anonymous) }
    private val _taskData = MutableLiveData<TaskCardData>()
    var taskData: LiveData<TaskCardData> = _taskData

    private val _reportData = MutableLiveData<CardData>()
    var reportData: LiveData<CardData> = _reportData

    private var currentTask: TaskCardData? = null

    fun setTaskData(task: TaskCardData) {
        viewModelScope.launch(dispatcherContext.io) {

            val obsidianTask = obsidianApi.Tasks().readOne(task.id)
            val taskCardData = TaskCardData.of(obsidianTask, anonymous, anonymous)

            val teamUsers = obsidianApi.teamManager.getTeamsUsers()
            currentTask = taskCardData.copy(
                assigneeName = teamUsers.firstOrNull {
                    it.userId.toInt() == taskCardData.assignee
                }?.fullName,
                creatorName = teamUsers.firstOrNull {
                    it.userId.toInt() == taskCardData.creatorId
                }?.fullName
            )
            currentTask?.let {
                _taskData.postValue(it)
            }
            taskCardData.reportId?.let { getReport(it) }
        }
    }

    fun onTaskStateChanged() {
        taskData.value?.let { task ->
            val newTask = if (task.completedDate == null) {
                task.copy(completedDate = Date())
            } else {
                task.copy(completedDate = null)
            }

            val taskCardData = if (newTask.completedDate == null) {
                TaskCardData.toObsidian(newTask).copy(
                    requested_action = SafermePendingChange.MARK_INCOMPLETE.toString()
                )
            } else {
                TaskCardData.toObsidian(newTask)
            }
            viewModelScope.launch(dispatcherContext.io) {
                taskManager.update(taskCardData)
                _taskData.postValue(newTask)
            }
        }
    }

    fun deleteTask() {
        taskData.value?.let { task ->
            viewModelScope.launch(dispatcherContext.io) {
                taskManager.delete(TaskCardData.toObsidian(task))
            }
        }
    }

    private fun getReport(reportId: String) {
        viewModelScope.launch(dispatcherContext.io) {
            _reportData.postValue(
                CardData.of(reportManager.readOne(reportId), anonymous)
            )
        }
    }
}
