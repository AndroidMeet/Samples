package com.thundermaps.saferme.features.main.photoviewer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.databinding.FragmentPhotoViewerItemBinding

class PhotoViewItemFragment(private val photoItemData: PhotoItemData) : Fragment() {
    private lateinit var binding: FragmentPhotoViewerItemBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentPhotoViewerItemBinding.inflate(inflater, container, false).also {
        binding = it
    }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.data = photoItemData
    }
}

@ExcludeFromJacocoGeneratedReport
data class PhotoItemData(
    val position: String,
    val photo: PhotoItem,
    val total: String
)
