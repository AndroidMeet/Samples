package com.thundermaps.saferme.features.main.map

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import androidx.annotation.ColorInt
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.mapbox.android.core.permissions.PermissionsListener
import com.mapbox.android.core.permissions.PermissionsManager
import com.mapbox.android.gestures.MoveGestureDetector
import com.mapbox.bindgen.Expected
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.MapView
import com.mapbox.maps.MapboxExperimental
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.QueriedFeature
import com.mapbox.maps.RenderedQueryGeometry
import com.mapbox.maps.RenderedQueryOptions
import com.mapbox.maps.ScreenCoordinate
import com.mapbox.maps.Style
import com.mapbox.maps.extension.style.expressions.dsl.generated.interpolate
import com.mapbox.maps.extension.style.layers.addLayer
import com.mapbox.maps.extension.style.layers.addLayerAbove
import com.mapbox.maps.extension.style.layers.addLayerBelow
import com.mapbox.maps.extension.style.layers.generated.CircleLayer
import com.mapbox.maps.extension.style.layers.generated.FillLayer
import com.mapbox.maps.extension.style.layers.generated.LineLayer
import com.mapbox.maps.extension.style.layers.generated.SymbolLayer
import com.mapbox.maps.extension.style.layers.getLayer
import com.mapbox.maps.extension.style.layers.properties.generated.IconAnchor
import com.mapbox.maps.extension.style.layers.properties.generated.Visibility
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.GeoJsonSource
import com.mapbox.maps.extension.style.sources.getSource
import com.mapbox.maps.extension.style.sources.getSourceAs
import com.mapbox.maps.plugin.LocationPuck2D
import com.mapbox.maps.plugin.animation.MapAnimationOptions.Companion.mapAnimationOptions
import com.mapbox.maps.plugin.animation.flyTo
import com.mapbox.maps.plugin.attribution.attribution
import com.mapbox.maps.plugin.compass.compass
import com.mapbox.maps.plugin.gestures.OnMapClickListener
import com.mapbox.maps.plugin.gestures.OnMoveListener
import com.mapbox.maps.plugin.gestures.gestures
import com.mapbox.maps.plugin.locationcomponent.OnIndicatorPositionChangedListener
import com.mapbox.maps.plugin.locationcomponent.location
import com.mapbox.maps.plugin.scalebar.scalebar
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.extensions.dpToPx
import com.thundermaps.saferme.core.ui.extensions.fetchAttributeColor
import com.thundermaps.saferme.core.ui.extensions.updateStatusColor
import com.thundermaps.saferme.core.util.Deeplink
import com.thundermaps.saferme.databinding.FragmentMapBinding
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

@MapboxExperimental
@AndroidEntryPoint
class MapFragment : BaseFragment<FragmentMapBinding, MapViewModel>(), PermissionsListener {
    private val permissionsManager: PermissionsManager by lazy { PermissionsManager(this) }
    private lateinit var mapboxMap: MapboxMap
    private lateinit var mapView: MapView
    private val args: MapFragmentArgs by navArgs()
    override val viewModel: MapViewModel by viewModels()

    private val onIndicatorPositionChangedListener = OnIndicatorPositionChangedListener {
        viewModel.updateIndicatorLocationChange(it)
    }

    private val onMoveListener = object : OnMoveListener {
        override fun onMoveBegin(detector: MoveGestureDetector) {
            onCameraTrackingDismissed()
            viewModel.disableMoveToCurrentLocation()
        }

        override fun onMove(detector: MoveGestureDetector): Boolean {
            viewModel.searchAddress(mapboxMap.cameraState.center)
            return false
        }

        override fun onMoveEnd(detector: MoveGestureDetector) {
            viewModel.searchAddress(mapboxMap.cameraState.center)
        }
    }

    private val onMapClickListener = OnMapClickListener { point ->
        viewModel.closeBottomViewsIfNeeded()
        onCameraTrackingDismissed()
        viewModel.disableMoveToCurrentLocation()
        val pins = viewModel.pins.value
        if (pins != null) {
            mapboxMap.queryRenderedFeatures(
                RenderedQueryGeometry(mapboxMap.pixelForCoordinate(point)),
                RenderedQueryOptions(pins.keys.map { "$it$PIN_LAYER_SUFFIX" }, null)
            ) {
                onFeatureClicked(it) { feature ->
                    feature.id()?.let { id ->
                        val request = Deeplink.createReportDetailsDeeplinkRequest(id)
                        findNavController().navigate(request)
                    }
                }
            }
            true
        } else {
            false
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        args.point?.let {
            viewModel.disableMoveToCurrentLocation()
            viewModel.updateCameraOption(Point.fromJson(it))
        }
        mapView = binding.mapView
        mapboxMap = mapView.getMapboxMap()
        configMap()
        viewModel.syncFeatureCollection()
        viewModel.mapStyle.value?.let { loadMap(it) }
        mapView.gestures.addOnMapClickListener(onMapClickListener)
        binding.searchButton.setOnClickListener {
            viewModel.closeBottomViews()
            findNavController().navigate(MapFragmentDirections.openSearchFragment())
        }

        binding.gpsButton.setOnClickListener {
            viewModel.gpsButtonClicked(mapboxMap.cameraState)
            addPositionChangeListener()
        }

        viewModel.reporting.observe(viewLifecycleOwner) {
            handleMapClick()
        }

        viewModel.isOpeningMapOptions.observe(viewLifecycleOwner) {
            handleMapClick()
        }

        viewModel.mapStyle.observe(viewLifecycleOwner) {
            viewModel.storeCameraOptions(mapboxMap.cameraState)
            loadMap(it)
        }

        viewModel.address.observe(viewLifecycleOwner) {
            viewModel.searchSuggestion?.point?.let {
                viewModel.updateCameraOption(point = it)
            }
        }

        viewModel.cameraOptions.observe(viewLifecycleOwner) {
            flyToPoint(it)
        }

        viewModel.createReportEvent.observe(viewLifecycleOwner) {
            if (it != null && it.willCreateReport) {
                findNavController().navigate(MapFragmentDirections.openSelectAForm(it.searchResult))
                viewModel.resetReportData()
            }
        }

        viewModel.bubblePolygon.observe(viewLifecycleOwner) { polygon ->
            mapboxMap.getStyle()?.let { updateSafetyHalo(polygon, it) }
        }

        viewModel.selectedChannels.observe(viewLifecycleOwner) { channels ->
            viewModel.selectedChannels(channels.map { it.id })
        }

        viewModel.shapeData.observe(viewLifecycleOwner) { shapeData ->
            if (shapeData != null) {
                addOrUpdateShapes(shapeData.shapes?.json())
                addOrUpdateSelectedShape(shapeData.selectedShape?.toJson())
                addOrUpdateNearestPoint(shapeData.closestPoint?.toJson())
            }
        }

        viewModel.pins.observe(viewLifecycleOwner) { dataMap ->
            mapboxMap.getStyle { style ->
                val oldStyleLayerIds =
                    style.styleLayers.filter { it.id.contains(PIN_LAYER_SUFFIX) }.map { it.id }
                        .toMutableList()

                dataMap.forEach { (appearance, pins) ->
                    if (pins.isNotEmpty()) {
                        val updateAppearance = fallBackToDefaultImageIfNotExist(style, appearance)
                        val sourceId = "$updateAppearance$SOURCE_SUFFIX"
                        addAppearanceLayerIfNotExist(style, updateAppearance, sourceId)
                        oldStyleLayerIds.remove("$updateAppearance$PIN_LAYER_SUFFIX")
                        val collection = FeatureCollection.fromFeatures(pins)
                        addOrUpdateSource(style, sourceId, collection)
                    }
                }

                oldStyleLayerIds.forEach { id ->
                    style.getLayer(id)?.visibility(Visibility.NONE)
                }
            }
        }
    }

    private fun fallBackToDefaultImageIfNotExist(style: Style, appearance: String): String {
        return if (style.getStyleImage(appearance) == null) {
            DEFAULT_PIN_KEY
        } else {
            appearance
        }
    }

    private fun addAppearanceLayerIfNotExist(style: Style, appearance: String, sourceId: String) {
        val layerId = "$appearance$PIN_LAYER_SUFFIX"
        val layer = style.getLayer(layerId)
        layer?.visibility(Visibility.VISIBLE)
        if (layer == null) {
            val firstPinLayerId = viewModel.firstPinLayerId
            if (firstPinLayerId == null || style.getLayer(firstPinLayerId) == null) {
                viewModel.firstPinLayerId = layerId
            }
            val newLayer = SymbolLayer(layerId, sourceId).apply {
                iconImage(appearance)
                iconAnchor(IconAnchor.BOTTOM)
            }
            if (style.getLayer(HIGHLIGHT_POLYGON_FEATURES_LAYER) != null) {
                style.addLayerAbove(newLayer, HIGHLIGHT_POLYGON_FEATURES_LAYER)
            } else if (style.getLayer(ALL_FEATURES_LAYER) != null) {
                style.addLayerAbove(newLayer, ALL_FEATURES_LAYER)
            } else {
                style.addLayer(newLayer)
            }
        }
    }

    private fun addOrUpdateSource(style: Style, sourceId: String, features: FeatureCollection) {
        val existSource = style.getSource(sourceId)
        if (existSource == null) {
            val source = GeoJsonSource.Builder(sourceId)
                .featureCollection(features)
                .build()
            style.addSource(source)
        } else {
            replaceSource(features.toJson(), sourceId)
        }
    }

    private fun onFeatureClicked(
        expected: Expected<String, List<QueriedFeature>>,
        onFeatureClicked: (Feature) -> Unit
    ) {
        val value = expected.value ?: return
        if (expected.isValue && value.isNotEmpty()) {
            value[0].feature.let { feature ->
                onFeatureClicked.invoke(feature)
            }
        }
    }

    private fun flyToPoint(cameraOptions: CameraOptions) {
        mapboxMap.flyTo(
            cameraOptions,
            mapAnimationOptions {
                duration(POSITION_ANIMATION_IN_MILLIS)
            })
    }

    private fun addOrUpdateShapes(json: String?) {
        addOreUpdateLineFeatures(ALL_FEATURES_LAYER, ALL_FEATURES_SOURCE, Color.BLACK, json)
    }

    private fun addOrUpdateSelectedShape(json: String?) {
        addOreUpdateLineFeatures(
            HIGHLIGHT_POLYGON_FEATURES_LAYER,
            HIGHLIGHT_POLYGON_FEATURES_SOURCE,
            ContextCompat.getColor(requireContext(), R.color.red_pin),
            json
        )
    }

    private fun addOreUpdateLineFeatures(
        layerId: String,
        sourceId: String,
        @ColorInt color: Int,
        json: String?
    ) {
        mapboxMap.getStyle()?.let { style ->
            if (json == null) {
                style.getLayer(layerId)?.visibility(Visibility.NONE)
            } else {
                if (style.getLayer(layerId) == null) {
                    val lineLayer = LineLayer(
                        layerId,
                        sourceId
                    ).apply {
                        lineColor(color)
                        lineWidth(FEATURE_LINE_WIDTH)
                    }
                    val source = GeoJsonSource.Builder(sourceId)
                        .data(json)
                        .build()
                    style.addSource(source)
                    if (style.getLayer(ALL_FEATURES_LAYER) != null) {
                        style.addLayerAbove(lineLayer, ALL_FEATURES_LAYER)
                    } else {
                        val firstPinLayerId = viewModel.firstPinLayerId
                        if (firstPinLayerId == null || style.getLayer(firstPinLayerId) == null) {
                            style.addLayer(lineLayer)
                        } else {
                            style.addLayerBelow(lineLayer, firstPinLayerId)
                        }
                    }
                } else {
                    style.getLayer(layerId)?.visibility(Visibility.VISIBLE)
                    replaceSource(json, sourceId)
                }
            }
        }
    }

    private fun addOrUpdateNearestPoint(json: String?) {
        mapboxMap.getStyle()?.let { style ->
            if (json == null) {
                style.getLayer(CLOSEST_POINT_LAYER)?.visibility(Visibility.NONE)
            } else {
                if (style.getLayer(CLOSEST_POINT_LAYER) == null) {
                    style.addSource(
                        GeoJsonSource.Builder(CLOSEST_POINT_SOURCE).data(json).build()
                    )
                    style.addLayer(
                        CircleLayer(
                            CLOSEST_POINT_LAYER,
                            CLOSEST_POINT_SOURCE
                        ).apply {
                            circleColor(ContextCompat.getColor(requireContext(), R.color.red_pin))
                            circleRadius(FEATURE_CIRCLE_RADIUS)
                        }
                    )
                } else {
                    style.getLayer(CLOSEST_POINT_LAYER)?.visibility(Visibility.VISIBLE)
                    replaceSource(json, CLOSEST_POINT_SOURCE)
                }
            }
        }
    }

    private fun handleMapClick() {
        if (viewModel.isOpeningBottomView) {
            mapView.gestures.addOnMoveListener(onMoveListener)
            viewModel.searchAddressByPointIfNeeded(mapboxMap.cameraState.center)
        } else {
            if (viewModel.isGpsVisible.value == true) {
                mapView.gestures.removeOnMoveListener(onMoveListener)
            }
        }
    }

    private fun loadMap(urlString: String) {
        mapboxMap.loadStyleUri(urlString) { style ->
            mapView.location.apply {
                enabled = true
            }
            viewModel.searchAddressByPointIfNeeded(mapboxMap.cameraState.center)
            viewModel.bubblePolygon.value?.let { updateSafetyHalo(it, style) }
        }
    }

    override fun provideLayoutId(): Int = R.layout.fragment_map

    private fun onCameraTrackingDismissed() {
        viewModel.showGpsButton()
        removeMapViewListeners()
    }

    private fun configMap() {
        mapView.scalebar.enabled = false
        mapView.attribution.position = Gravity.BOTTOM or Gravity.END
        mapView.post {
            mapView.gestures.updateSettings {
                focalPoint = ScreenCoordinate(mapView.width / 2.0, mapView.height / 2.0)
            }
        }
        configCompassView()
        customLocationImage()
        viewModel.cameraOptions.value?.let { mapboxMap.setCamera(it) }
        if (viewModel.searchSuggestion == null && args.point == null) {
            addPositionChangeListener()
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun configCompassView() {
        val compassView = mapView.compass
        compassView.image = resources.getDrawable(R.drawable.ic_compass, null)
        compassView.position = Gravity.BOTTOM or Gravity.END
        compassView.marginRight = COMPASS_MARGIN_RIGHT.dpToPx()
        compassView.marginBottom = COMPASS_MARGIN_BOTTOM.dpToPx()
    }

    private fun addPositionChangeListener() {
        if (viewModel.canLocateToCurrentPosition) {
            mapView.location.addOnIndicatorPositionChangedListener(
                onIndicatorPositionChangedListener
            )
        }
        mapView.gestures.addOnMoveListener(onMoveListener)
    }

    private fun onPermissionReady() {
        mapView.location.updateSettings {
            enabled = true
            pulsingEnabled = true
        }
        if (viewModel.isGpsVisible.value == false) {
            addPositionChangeListener()
        }
    }

    private fun customLocationImage() {
        val context = requireContext()
        mapView.location.locationPuck = LocationPuck2D(
            topImage = AppCompatResources.getDrawable(
                context,
                R.drawable.ic_map_user
            ),
            bearingImage = AppCompatResources.getDrawable(
                context,
                R.drawable.ic_map_bearing
            ),
            shadowImage = AppCompatResources.getDrawable(
                context,
                R.drawable.ic_map_user_stroke
            ),
            scaleExpression = interpolate {
                linear()
                zoom()
                stop {
                    literal(0.0)
                    literal(0.6)
                }
                stop {
                    literal(10.0)
                    literal(1.0)
                }
            }.toJson()
        )
    }

    override fun onResume() {
        super.onResume()
        actionController?.hideToolBar()
        clearStatusColor()
        if (!PermissionsManager.areLocationPermissionsGranted(requireContext())) {
            permissionsManager.requestLocationPermissions(requireActivity())
        } else if (viewModel.canLocateToCurrentPosition) {
            onPermissionReady()
        }
        viewModel.resetCreatingReport()
        if (viewModel.searchSuggestion != null) {
            viewModel.activeReport()
        }
    }

    override fun onPause() {
        returnStatusColor()
        viewModel.storeCameraOptions(mapboxMap.cameraState)
        removeMapViewListeners()
        if (!PermissionsManager.areLocationPermissionsGranted(requireContext())) {
            viewModel.disableMoveToCurrentLocation()
        }
        super.onPause()
    }

    override fun onDestroy() {
        removeMapViewListeners()
        super.onDestroy()
    }

    private fun removeMapViewListeners() {
        if (!::mapView.isInitialized) return
        mapView.location.removeOnIndicatorPositionChangedListener(
            onIndicatorPositionChangedListener
        )
        if (viewModel.reporting.value == false) {
            mapView.gestures.removeOnMoveListener(onMoveListener)
        }
    }

    private fun clearStatusColor() {
        requireActivity().updateStatusColor(Color.TRANSPARENT)
    }

    private fun returnStatusColor() {
        requireActivity().updateStatusColor(requireContext().fetchAttributeColor(R.attr.colorOnPrimary))
    }

    override fun onExplanationNeeded(permissionsToExplain: MutableList<String>?) {
    }

    override fun onPermissionResult(granted: Boolean) {
        if (granted) {
            onPermissionReady()
        }
    }

    private fun replaceSource(geoJson: String, id: String) {
        try {
            mapboxMap.getStyle()?.let { style ->
                if (style.getSource(id) != null) {
                    val geoJsonSource = style.getSourceAs<GeoJsonSource>(id)
                    if (geoJsonSource?.data != geoJson) {
                        geoJsonSource?.data(geoJson)
                    }
                }
            }
        } catch (exception: Exception) {
        }
    }

    private fun updateSafetyHalo(polygon: Polygon, style: Style) {
        try {
            val source = style.getSource(BUBBLE_SOURCE)
            val feature = Feature.fromGeometry(polygon)
            val featureCollection = FeatureCollection.fromFeature(feature)
            if (source == null) {
                val fillLayer = FillLayer(BUBBLE_LAYER_ID, BUBBLE_SOURCE).apply {
                    fillColor(resources.getColor(R.color.blue_whale, null))
                    fillOpacity(0.2)
                    fillOutlineColor(resources.getColor(R.color.blue_whale_700, null))
                }

                val geoJsonSource = GeoJsonSource.Builder(BUBBLE_SOURCE)
                    .data(featureCollection.toJson())
                    .build()
                style.addSource(geoJsonSource)
                style.addLayer(fillLayer)
            } else {
                val geoJsonSource = style.getSourceAs<GeoJsonSource>(BUBBLE_SOURCE)
                geoJsonSource?.data(featureCollection.toJson())
            }
        } catch (exception: Exception) {
            Timber.e(exception)
        }
    }

    companion object {
        private const val POSITION_ANIMATION_IN_MILLIS = 300L
        private const val COMPASS_MARGIN_RIGHT = 12
        private const val COMPASS_MARGIN_BOTTOM = 72
        private const val FEATURE_LINE_WIDTH = 2.0
        private const val FEATURE_CIRCLE_RADIUS = 4.0

        private const val ALL_FEATURES_LAYER = "features-line-layer"
        private const val ALL_FEATURES_SOURCE = "features-source"

        private const val BUBBLE_SOURCE = "bubble-source"
        private const val BUBBLE_LAYER_ID = "bubble-layer-id"

        private const val HIGHLIGHT_POLYGON_FEATURES_LAYER = "features-highlight-polygon-layer"
        private const val HIGHLIGHT_POLYGON_FEATURES_SOURCE = "features-highlight-polygon-source"

        private const val CLOSEST_POINT_LAYER = "feature-closest-point-layer"
        private const val CLOSEST_POINT_SOURCE = "feature-closest-point-source"

        private const val SOURCE_SUFFIX = "-source"
        private const val PIN_LAYER_SUFFIX = "-pin-layer"
        private const val DEFAULT_PIN_KEY = "generic_steal"
    }
}
