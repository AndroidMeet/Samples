package com.thundermaps.saferme.core.domain.models

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.mapbox.geojson.Point
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class SmSearchSuggestion(
    @Expose val address: String?,
    @Expose val point: Point?,
    @Expose val isRecent: Boolean = false
) : Parcelable
