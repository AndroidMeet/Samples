package com.thundermaps.saferme.features.main.reportdetails.manage.models

data class AssigneeData(
    val assignedName: String?,
    val dueString: String?,
    val state: String?
)
