package com.thundermaps.saferme.features.authentication.login.domain.di

import com.thundermaps.saferme.features.authentication.login.domain.LoginRepository
import com.thundermaps.saferme.features.authentication.login.domain.LoginRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
abstract class LoginModule {
    @Suppress("unused")
    @Binds
    abstract fun bindLoginRepository(
        loginRepositoryImpl: LoginRepositoryImpl
    ): LoginRepository
}
