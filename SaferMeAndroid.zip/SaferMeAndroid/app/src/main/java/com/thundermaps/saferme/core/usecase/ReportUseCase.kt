package com.thundermaps.saferme.core.usecase

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReportUseCase @Inject constructor() {
    private val _showingReportBottom = MutableLiveData(false)
    val showingReport: LiveData<Boolean> = _showingReportBottom

    private val _creatingReport = MutableLiveData(false)
    val creatingReport: LiveData<Boolean> = _creatingReport

    fun createReportButtonClicked() {
        _creatingReport.value = true
        _showingReportBottom.value = false
    }

    fun activateReport() {
        if (_creatingReport.value == false) {
            _showingReportBottom.value = true
        }
    }

    fun resetCreatingReport() {
        _creatingReport.value = false
    }

    fun deactivateReport() {
        _showingReportBottom.value = false
    }
}
