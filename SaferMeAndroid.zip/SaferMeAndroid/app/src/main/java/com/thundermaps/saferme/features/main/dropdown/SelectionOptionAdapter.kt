package com.thundermaps.saferme.features.main.dropdown

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.databinding.ItemSelectionOptionBinding
import com.thundermaps.saferme.features.main.dropdown.domain.model.SelectionOptionData
import javax.inject.Inject

class SelectionOptionAdapter @Inject constructor() :
    BaseAdapter<SelectionOptionData, SelectionOptionAdapter.Companion.SelectionOptionHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SelectionOptionHolder =
        SelectionOptionHolder(
            ItemSelectionOptionBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: SelectionOptionHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, itemInterface)
        }
    }

    companion object {
        class SelectionOptionHolder(
            private val binding: ItemSelectionOptionBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: SelectionOptionData, itemInterface: ItemInterface?) {
                val onClick = View.OnClickListener { itemInterface?.onItemSelected(item) }
                binding.selectionOptionData = item
                binding.onItemClicked = onClick
            }
        }
    }
}
