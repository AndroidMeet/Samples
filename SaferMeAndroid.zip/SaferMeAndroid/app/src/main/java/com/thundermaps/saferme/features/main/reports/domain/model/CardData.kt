package com.thundermaps.saferme.features.main.reports.domain.model

import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.getFormFields
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.locationObject
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.reportStateObject
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.riskLevelObject
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.resources.Location
import com.thundermaps.apilib.android.api.responses.models.FieldType
import com.thundermaps.apilib.android.api.responses.models.FormFieldImage
import com.thundermaps.apilib.android.api.responses.models.FormValue.ValueFormFieldImage
import com.thundermaps.apilib.android.api.responses.models.ReportState
import com.thundermaps.apilib.android.api.responses.models.RiskLevel
import com.thundermaps.domain.models.DiffItem
import com.thundermaps.saferme.core.util.TimeUtil
import com.thundermaps.saferme.core.util.TimeUtil.toMediumDateInString
import com.thundermaps.saferme.core.util.TimeUtil.toShortTimeInString
import java.util.Date

@ExcludeFromJacocoGeneratedReport
data class CardData(
    val id: String,
    val title: String?,
    val category: String?,
    val fieldImage: FormFieldImage?,
    val reportState: ReportState?,
    val riskLevel: RiskLevel?,
    val address: String?,
    val location: Location?,
    val reporter: String?,
    val date: Date?
) : DiffItem {
    override val uniqueId: Any get() = id
    val createdDateMediumString get() = date?.toMediumDateInString()
    val createdTimeShortString get() = date?.toShortTimeInString()?.lowercase()
    val channelName get() = category?.split(", ")?.lastOrNull() ?: ""

    companion object {
        @ExcludeFromJacocoGeneratedReport
        fun of(report: ObsidianReport, anonymous: String? = null): CardData {
            val date = report.isoCreatedAt?.let { TimeUtil.convertIsoDateStringToDate(it) }
            return CardData(
                report.uuid,
                report.title,
                report.categoriesTitle,
                (report.getFormFields?.firstOrNull { it.fieldType == FieldType.Image }?.value as? ValueFormFieldImage)?.images?.firstOrNull(),
                report.reportStateObject,
                report.riskLevelObject,
                report.address,
                report.locationObject,
                report.userShortName ?: anonymous,
                date
            )
        }
    }
}
