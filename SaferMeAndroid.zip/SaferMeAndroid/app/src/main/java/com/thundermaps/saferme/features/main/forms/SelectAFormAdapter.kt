package com.thundermaps.saferme.features.main.forms

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.databinding.ItemSelectAFormBinding
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SelectAFormAdapter @Inject constructor() :
    BaseAdapter<ObsidianChannel, SelectAFormAdapter.Companion.SelectAFormHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SelectAFormHolder =
        SelectAFormHolder(
            ItemSelectAFormBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: SelectAFormHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, itemInterface)
        }
    }

    companion object {
        class SelectAFormHolder(
            private val binding: ItemSelectAFormBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: ObsidianChannel, listener: ItemInterface?) {
                binding.name = item.name
                val onClick = View.OnClickListener { listener?.onItemSelected(item) }
                binding.onChannelSelected = onClick
            }
        }
    }
}
