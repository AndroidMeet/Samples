package com.thundermaps.saferme.features.main.dropdown.domain.model

import android.os.Parcelable
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class SelectionOptionList(
    val list: List<SelectionOptionData>,
    val title: Int,
    val key: String
) : Parcelable
