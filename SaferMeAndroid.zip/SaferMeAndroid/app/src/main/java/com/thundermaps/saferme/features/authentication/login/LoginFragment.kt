package com.thundermaps.saferme.features.authentication.login

import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.google.android.gms.common.util.VisibleForTesting
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.Screen
import com.thundermaps.saferme.core.ui.extensions.hideKeyboard
import com.thundermaps.saferme.databinding.FragmentLoginBinding
import com.thundermaps.saferme.features.authentication.UserDetailsListener
import dagger.hilt.android.AndroidEntryPoint
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LoginFragment : BaseFragment<FragmentLoginBinding, LoginViewModel>() {
    private val navigationController get() = findNavController()
    override val viewModel: LoginViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_login
    private var timeWhenLoginButtonClicked: Long = 0L

    @VisibleForTesting
    var delayLauncherTime = 1000L

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.setOnLoginPressed {
            timeWhenLoginButtonClicked = System.currentTimeMillis()
            showLoader()
            viewModel.login()
        }

        binding.setOnForgotPasswordPressed {
            navigationController.navigate(LoginFragmentDirections.openForgotPasswordScreen())
        }

        binding.setOnLoginSsoPressed {
            navigationController.navigate(LoginFragmentDirections.openSsoScreen())
        }

        binding.viewLogin.run {
            emailEdittext.setOnFocusChangeListener { _, hasFocus ->
                viewModel?.updateEditingEmail(hasFocus)
            }
            passwordEdittext.setOnFocusChangeListener { _, hasFocus ->
                viewModel?.updateEditingPassword(hasFocus)
            }
            passwordEdittext.setOnEditorActionListener(onEditorActionListener())
        }

        viewModel.nextScreen.observe(viewLifecycleOwner) {
            if (it != null) (activity as? UserDetailsListener)?.getUserDetails()
            val diffInMilliseconds: Long = System.currentTimeMillis() - timeWhenLoginButtonClicked
            val diffInSeconds: Long = TimeUnit.MILLISECONDS.toSeconds(diffInMilliseconds)
            viewLifecycleOwner.lifecycleScope.launch {
                if (diffInSeconds < 1) {
                    delay(delayLauncherTime)
                }
                loadNextScreen(it)
            }
        }

        viewModel.loginResult.observe(viewLifecycleOwner) {
            if (it.isLoading) {
                requireActivity().hideKeyboard()
            }
        }
    }

    private fun loadNextScreen(screen: Screen?) {
        screen?.let { nextScreen ->
            when (nextScreen) {
                Screen.UPDATE_PROFILE -> {}
                Screen.UPDATE_PASSWORD -> {
                    viewModel.passwordInput.text.value?.let { oldPassword ->
                        navigationController.navigate(
                            LoginFragmentDirections.openUpdatePasswordScreen(
                                oldPassword
                            )
                        )
                    }
                }
                Screen.SELECT_TEAM -> {
                    navigationController.navigate(LoginFragmentDirections.openTeamsScreen())
                }
                Screen.MAP -> {
                    navigationController.navigate(LoginFragmentDirections.openMainScreen())
                }
            }
        }
        hideLoader()
    }

    private fun onEditorActionListener() = TextView.OnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE && viewModel.isReadyForLogin.value == true) {
                viewModel.login()
                false
            } else {
                true
            }
        }

    override fun onResume() {
        super.onResume()
        actionController?.hideToolBar()
    }
}
