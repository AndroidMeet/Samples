package com.thundermaps.saferme.core.domain.models

import android.os.Parcelable
import com.thundermaps.apilib.android.api.responses.models.FormFieldSignature
import kotlinx.parcelize.Parcelize

@Parcelize
data class Signature(
    val reportUuid: String,
    val formFieldId: Int,
    val formFieldSignature: FormFieldSignature? = null
) : Parcelable
