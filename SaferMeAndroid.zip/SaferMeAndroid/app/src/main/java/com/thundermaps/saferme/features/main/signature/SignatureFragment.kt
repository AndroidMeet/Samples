package com.thundermaps.saferme.features.main.signature

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.github.gcacace.signaturepad.views.SignaturePad
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.extensions.loadImageAsBitmap
import com.thundermaps.saferme.databinding.FragmentSignatureBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SignatureFragment : BaseFragment<FragmentSignatureBinding, SignatureViewModel>() {
    private val args: SignatureFragmentArgs by navArgs()
    override val viewModel: SignatureViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_signature

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        args.signature?.let { signature ->
            viewModel.updateSignature(signature)
            signature.formFieldSignature?.let {
                requireContext().loadImageAsBitmap(it.url) { bitmap ->
                    binding.signaturePad.signatureBitmap = bitmap
                }
            }
        }
        binding.signaturePad.setOnSignedListener(object : SignaturePad.OnSignedListener {
            override fun onStartSigning() {
                viewModel.updateSign(null)
                binding.signaturePad.clear()
            }

            override fun onSigned() {
                viewModel.updateSign(binding.signaturePad.transparentSignatureBitmap)
            }

            override fun onClear() {
                viewModel.updateSign(null)
            }
        })

        viewModel.signature.observe(viewLifecycleOwner) {
            if (viewModel.isReadyToPopBack && it.isSuccess) {
                val navigation = findNavController()
                navigation.previousBackStackEntry?.savedStateHandle?.set(
                    SIGNATURE_KEY,
                    it.getNullableData()
                )
                navigation.popBackStack()
            }
        }

        binding.setOnSaveClicked {
            viewModel.submitSignature()
        }
    }

    companion object {
        const val SIGNATURE_KEY = "signature_key"
    }
}
