package com.thundermaps.saferme.features.authentication.updatepassword.widgets

import android.widget.TextView
import androidx.annotation.StringRes
import androidx.databinding.BindingAdapter
import com.thundermaps.saferme.R
import com.thundermaps.saferme.features.authentication.updatepassword.domain.PasswordStrengthLevel

@BindingAdapter("passwordText")
fun setText(view: TextView, @StringRes resId: Int) {
    if (resId == 0) {
        view.setText(R.string.password_status_too_weak)
    } else {
        view.setText(resId)
    }
}

@BindingAdapter("score")
fun setScore(view: PasswordIndicatorView, level: PasswordStrengthLevel?) {
    if (level != null) {
        view.setSecurityLevel(level, true)
    } else {
        view.setSecurityLevel(PasswordStrengthLevel.minLevel, true)
    }
}
