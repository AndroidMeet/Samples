package com.thundermaps.saferme

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.thundermaps.saferme.features.main.MainActivity

class SaferMeFirebaseMessagingService : FirebaseMessagingService() {

    private val channelName = "SaferMe Default channel"

    override fun onMessageReceived(remoteMsg: RemoteMessage) {
        super.onMessageReceived(remoteMsg)

        remoteMsg.notification?.let { notification ->
            val body = notification.body
            val title = notification.title
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra(notificationType, remoteMsg.data[notificationType])
            when (remoteMsg.data[notificationType]) {
                notificationTypeTask -> {
                    intent.putExtra(keyTaskId, remoteMsg.data[keyTaskId])
                    intent.putExtra(keyTeamId, remoteMsg.data[keyTeamId])
                    intent.putExtra(keyReportId, remoteMsg.data[keyReportId])
                    intent.putExtra(keyCategory, remoteMsg.data[keyCategory])
                }
                notificationTypeReport, notificationTypeRefreshReport -> {
                    intent.putExtra(keyReportUUID, remoteMsg.data[keyReportUUID])
                }
            }

            val pendingIntent = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )

            val channelId = getString(R.string.notification_channel_id)
            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val notificationBuilder = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_notification_bell)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent)

            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    channelName,
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                notificationManager.createNotificationChannel(channel)
            }

            notificationManager.notify(remoteMsg.messageId, 0, notificationBuilder.build())
        }
    }

    companion object {
        const val notificationType = "type"
        const val notificationTypeTask = "task"
        const val notificationTypeReport = "report"
        const val notificationTypeRefreshReport = "refreshReport"
        const val keyTaskId = "task_id"
        const val keyTeamId = "team_id"
        const val keyReportId = "report_id"
        const val keyCategory = "category"
        const val keyReportUUID = "report_uuid"
    }
}
