package com.thundermaps.saferme.features.authentication

interface UserDetailsListener {
    fun getUserDetails()
}
