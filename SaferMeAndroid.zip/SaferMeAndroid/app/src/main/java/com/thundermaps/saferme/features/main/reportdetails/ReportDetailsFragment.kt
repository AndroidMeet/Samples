package com.thundermaps.saferme.features.main.reportdetails

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.material.tabs.TabLayoutMediator
import com.saferme.obsidian.store.resources.ObsidianReport
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.models.ReportData
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.adapter.CollectionAdapter
import com.thundermaps.saferme.core.util.Deeplink
import com.thundermaps.saferme.core.util.toPoint
import com.thundermaps.saferme.databinding.FragmentReportDetailsBinding
import com.thundermaps.saferme.features.main.photoviewer.PhotoViewerData
import com.thundermaps.saferme.features.main.reportdetails.details.ReportDetailsTabFragment
import com.thundermaps.saferme.features.main.reportdetails.manage.ManageTabFragment
import com.thundermaps.saferme.features.main.reportdetails.tasks.TasksTabFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ReportDetailsFragment : BaseFragment<FragmentReportDetailsBinding, ReportDetailsViewModel>() {
    private val args: ReportDetailsFragmentArgs by navArgs()
    override val viewModel: ReportDetailsViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_report_details

    private val reportDetailsTabFragment by lazy { ReportDetailsTabFragment() }

    private val manageTabFragment by lazy { ManageTabFragment() }

    private val tasksTabFragment by lazy {
        TasksTabFragment()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
        viewModel.loadReport(args.uuid)
        viewModel.report.observe(viewLifecycleOwner) { result ->
            if (result.isLoading) {
                binding.viewReportHeader.veilLayout.veil()
                binding.veilLayout.veil()
            } else {
                result.getNullableData()?.let { report ->
                    if (reportDetailsTabFragment.isResumed) {
                        reportDetailsTabFragment.setReport(report)
                    }
                }
                binding.viewReportHeader.veilLayout.unVeil()
                binding.veilLayout.unVeil()
            }
        }

        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_edit -> {
                    viewModel.report.value?.getNullableData()?.let {
                        findNavController().navigate(
                            ReportDetailsFragmentDirections.openCreateReport(
                                ReportData.Edit(it.uuid)
                            )
                        )
                    }
                    true
                }
                R.id.action_open_map -> {
                    viewModel.report.value?.getNullableData()?.location?.toPoint()?.let {
                        val request = Deeplink.createMapDeeplinkRequest(it)
                        findNavController().navigate(request)
                        true
                    } ?: false
                }
                else -> false
            }
        }
        updateTaskTabUuid()
        binding.pager.adapter = CollectionAdapter(
            this,
            listOf(reportDetailsTabFragment, manageTabFragment, tasksTabFragment)
        )

        viewModel.titles.observe(viewLifecycleOwner) {
            if (!it.isNullOrEmpty()) tabLayoutSetup(it)
        }
    }

    private fun updateTaskTabUuid() {
        val bundle = Bundle()
        bundle.putString(TasksTabFragment.UUID, args.uuid)
        tasksTabFragment.arguments = bundle
    }

    private fun tabLayoutSetup(titles: List<String>) {
        TabLayoutMediator(binding.tabLayout, binding.pager) { tab, position ->
            tab.text = titles[position]
        }.attach()
    }

    override fun onResume() {
        super.onResume()
        actionController?.hideToolBar()
    }

    fun openPhotoViewer(photoViewerData: PhotoViewerData) {
        findNavController().navigate(ReportDetailsFragmentDirections.openPhotoViewer(photoViewerData))
    }

    fun updateManageReport(): ObsidianReport? {
        return viewModel.report.value?.getNullableData()
    }
}
