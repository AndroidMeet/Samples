package com.thundermaps.saferme.features.main.profile.domain

import com.thundermaps.apilib.android.api.responses.models.Avatar

data class Profile(
    val name: String,
    val team: String,
    val avatar: Avatar
)
