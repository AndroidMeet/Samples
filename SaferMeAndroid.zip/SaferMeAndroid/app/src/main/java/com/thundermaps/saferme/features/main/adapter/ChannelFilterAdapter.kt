package com.thundermaps.saferme.features.main.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.core.ui.input.CheckBoxInput
import com.thundermaps.saferme.databinding.ItemOptionChannelBinding
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChannelFilterAdapter @Inject constructor() :
    BaseAdapter<CheckBoxInput, ChannelFilterAdapter.Companion.ChannelHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelHolder =
        ChannelHolder(
            ItemOptionChannelBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ChannelHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, itemInterface)
        }
    }

    companion object {
        class ChannelHolder(
            private val binding: ItemOptionChannelBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: CheckBoxInput, listener: ItemInterface?) {
                val onClick = View.OnClickListener { listener?.onItemSelected(item) }
                binding.inputs = item
                binding.changeCheckedStatus = onClick
            }
        }
    }
}
