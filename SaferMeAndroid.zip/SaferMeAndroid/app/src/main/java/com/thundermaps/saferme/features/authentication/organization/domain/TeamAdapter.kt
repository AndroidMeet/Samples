package com.thundermaps.saferme.features.authentication.organization.domain

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.databinding.ItemTeamBinding
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TeamAdapter @Inject constructor() :
    BaseAdapter<ObsidianTeam, TeamAdapter.Companion.TeamHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamHolder = TeamHolder(
        ItemTeamBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: TeamHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, itemInterface)
        }
    }

    companion object {
        class TeamHolder(
            private val binding: ItemTeamBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: ObsidianTeam, listener: ItemInterface?) {
                binding.team = item
                itemView.setOnClickListener {
                    listener?.onItemSelected(item)
                }
            }
        }
    }
}
