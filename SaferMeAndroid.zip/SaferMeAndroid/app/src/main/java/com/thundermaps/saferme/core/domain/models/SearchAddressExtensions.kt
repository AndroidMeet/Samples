package com.thundermaps.saferme.core.domain.models

import com.mapbox.search.result.SearchAddress

fun SearchAddress.toFullAddress(): String? = formattedAddress(SearchAddress.FormatStyle.Full)

fun SearchAddress?.toLongAddress(): String? = this?.formattedAddress(SearchAddress.FormatStyle.Long)
