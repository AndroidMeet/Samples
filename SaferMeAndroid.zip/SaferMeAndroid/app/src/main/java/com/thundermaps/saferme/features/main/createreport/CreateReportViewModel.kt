package com.thundermaps.saferme.features.main.createreport

import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import com.google.gson.reflect.TypeToken
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianCategory
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.getFormFields
import com.saferme.obsidian.store.resources.ObsidianState.Companion.toReportState
import com.saferme.obsidian.store.resources.SafermePendingChange
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.responses.models.DataValue
import com.thundermaps.apilib.android.api.responses.models.FieldType
import com.thundermaps.apilib.android.api.responses.models.FormField
import com.thundermaps.apilib.android.api.responses.models.FormFieldImage
import com.thundermaps.apilib.android.api.responses.models.FormValue
import com.thundermaps.apilib.android.api.responses.models.Likelihood
import com.thundermaps.apilib.android.api.responses.models.Option
import com.thundermaps.apilib.android.api.responses.models.OptionHolder
import com.thundermaps.apilib.android.api.responses.models.ReportState
import com.thundermaps.apilib.android.api.responses.models.RiskAssessment
import com.thundermaps.apilib.android.api.responses.models.RiskLevel
import com.thundermaps.apilib.android.api.responses.models.RiskMatrixConfig
import com.thundermaps.apilib.android.api.responses.models.Severity
import com.thundermaps.apilib.android.api.responses.models.SliderData
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.domain.models.PhotoType
import com.thundermaps.saferme.core.domain.models.ReportData
import com.thundermaps.saferme.core.domain.models.Signature
import com.thundermaps.saferme.core.domain.models.toObsidianReport
import com.thundermaps.saferme.core.ui.extensions.createImageFile
import com.thundermaps.saferme.core.ui.extensions.getImageUriForFile
import com.thundermaps.saferme.core.ui.extensions.replace
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import com.thundermaps.saferme.core.util.TimeUtil
import com.thundermaps.saferme.core.util.TimeUtil.toMediumDateInString
import com.thundermaps.saferme.core.util.TimeUtil.toShortTimeInString
import com.thundermaps.saferme.features.main.category.model.ExtendedCategory
import com.thundermaps.saferme.features.main.createreport.models.DynamicItem
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.Calendar
import java.util.TimeZone
import javax.inject.Inject
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@HiltViewModel
class CreateReportViewModel @Inject constructor(
    private val app: SaferMeApplication,
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext,
    private val gson: Gson
) : AndroidViewModel(app) {
    private val _channel = MutableLiveData<ObsidianChannel?>()
    val channel: LiveData<ObsidianChannel?> = _channel

    private val selectedCheckBoxOptionMap = mutableMapOf<String, List<Option>>()
    private val selectedRadioOptionMap = mutableMapOf<String, Option>()
    private val inputMap = mutableMapOf<String, TextFieldInput>()
    private val numberListMap = mutableMapOf<String, List<DynamicItem.NumberItem>>()
    private val bulletListMap = mutableMapOf<String, List<DynamicItem.BulletItem>>()

    val calendar: Calendar by lazy { Calendar.getInstance(TimeZone.getDefault()) }

    private val _dateInString = MutableLiveData<String?>()
    val dateInString: LiveData<String?> = _dateInString

    private val _timeInString = MutableLiveData<String?>()
    val timeInString: LiveData<String?> = _timeInString

    private val _photos = MutableLiveData(listOf(PhotoItem(isDeletable = false, reportUuid = "")))
    val photos: LiveData<List<PhotoItem>> = _photos
    var photoType: PhotoType? = null
        private set
    val realPhotos get() = _photos.value?.filterNot { it.isAddItem }

    var capturePhotoPath: String? = null
        private set

    private val _signature = MutableLiveData<Signature>()
    val signature: LiveData<Signature> = _signature

    private val _report = MediatorLiveData<ObsidianReport>()

    @ExcludeFromJacocoGeneratedReport
    val report: LiveData<ObsidianReport?> = _report

    private var riskAssessment: RiskAssessment? = null
    private var rangeValue: Int = -1
    private val _finishCreateReport = MutableLiveData<Unit>(null)
    val finishCreateReport: LiveData<Unit> = _finishCreateReport

    private var _reportStates = MediatorLiveData<List<ReportState>?>()
    val reportStates: LiveData<List<ReportState>?> = _reportStates

    var selectedReportState: ReportState? = null
        private set

    private val _titleId = MutableLiveData(R.string.add_details)
    val titleId: LiveData<Int> = _titleId

    private val _canEditReport = MutableLiveData(false)
    val canEditReport: LiveData<Boolean> = _canEditReport

    private val _category = MutableLiveData<ObsidianCategory>()
    val category: LiveData<ObsidianCategory> = _category

    var riskMatrixConfig: RiskMatrixConfig? = null
        private set

    private var isCreatingReport = false

    init {
        _report.addSource(_dateInString) {
            updateDateTimeFormValue()
        }
        _report.addSource(_timeInString) {
            updateDateTimeFormValue()
        }
    }

    fun updateReportData(data: ReportData) {
        if (report.value != null) return
        isCreatingReport = data is ReportData.Create
        riskMatrixConfig = null
        if (data is ReportData.Create) {
            _titleId.postValue(R.string.add_details)
            _canEditReport.postValue(true)
            if (_channel.value == null || _channel.value != data.channel) {
                _report.value = data.toObsidianReport()
                _channel.value = data.channel
                val channelId: Int = data.channel.id.toInt()
                syncForm(channelId)
                updateReportStates(channelId)
            }
        } else if (data is ReportData.Edit) {
            _titleId.postValue(R.string.edit_report)
            _canEditReport.postValue(false)
            viewModelScope.launch(dispatcherContext.io) {
                val reportDeferred = async { obsidianApi.reportManager.readOne(data.uuid) }
                val report = reportDeferred.await().copy(
                    requestedAction = SafermePendingChange.UPDATE.toString()
                )
                val fields = report.getFormFields?.toJsonArray()
                val newReport = report.copy(formFields = fields)
                _report.postValue(newReport)
                newReport.accountId?.let { channelId ->
                    updateReportStates(channelId)
                    val channel = obsidianApi.channelsManager.getChannel(channelId.toLong())
                    _channel.postValue(channel)
                }
            }
        }
    }

    fun getExistCategory(id: Int) {
        viewModelScope.launch(dispatcherContext.io) {
            _category.postValue(obsidianApi.categoryManager.getCategory(id))
        }
    }

    private fun updateReportStates(channelId: Int) {
        viewModelScope.launch(dispatcherContext.io) {
            val states = obsidianApi.stateManager.getStatesByChannel(channelId)
            withContext(dispatcherContext.main) {
                _reportStates.addSource(states) { reports ->
                    if (!reports.isNullOrEmpty()) {
                        val list = reports.map { it.toReportState() }
                        if (_reportStates.value != list)
                            _reportStates.postValue(list)
                    }
                }
            }
        }
    }

    private fun getForm(channelId: Int) = obsidianApi.formManager.getForm(channelId)
    private fun syncForm(channelId: Int) {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.formManager.syncForm(channelId)
            withContext(dispatcherContext.main) {
                _report.addSource(getForm(channelId)) { form ->
                    val fields = form?.formFields?.sortedBy { it.formOrder }?.toJsonArray()
                    _report.value?.let { report ->
                        _report.postValue(
                            report.copy(
                                formFields = fields
                            )
                        )
                    }
                }
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun getConfigMatrix(jsonObject: JsonObject): RiskMatrixConfig =
        gson.fromJson(jsonObject, RiskMatrixConfig::class.java).also {
            riskMatrixConfig = it
        }

    @ExcludeFromJacocoGeneratedReport
    fun getDropdown(jsonObject: JsonObject): OptionHolder =
        gson.fromJson(jsonObject, OptionHolder::class.java)

    @ExcludeFromJacocoGeneratedReport
    fun getCheckOptionHolder(formField: FormField, jsonObject: JsonObject): OptionHolder {
        val optionHolder = getDropdown(jsonObject)
        val checkedOptions = mutableSetOf<Option>()
        (formField.value as? FormValue.ValueJsonArray)?.value?.forEach { element ->
            (element as? JsonPrimitive)?.asString?.let { value ->
                optionHolder.options.firstOrNull { it.value == value }
                    ?.let { checkedOptions.add(it) }
            }
        }
        if (checkedOptions.isNotEmpty()) {
            selectedCheckBoxOptionMap[formField.key] = checkedOptions.toList()
        }
        return optionHolder
    }

    @ExcludeFromJacocoGeneratedReport
    fun getRadioOptionHolder(formField: FormField, jsonObject: JsonObject): OptionHolder {
        val optionHolder = getDropdown(jsonObject)
        (formField.value as? FormValue.ValueString)?.value?.let { value ->
            optionHolder.options.firstOrNull { it.value == value }?.let {
                selectedRadioOptionMap[formField.key] = it
            }
        }
        return optionHolder
    }

    @ExcludeFromJacocoGeneratedReport
    fun getSlideData(jsonObject: JsonObject): SliderData =
        gson.fromJson(jsonObject, SliderData::class.java)

    @ExcludeFromJacocoGeneratedReport
    fun getCheckedOption(fieldKey: String): List<Option> {
        return selectedCheckBoxOptionMap[fieldKey]?.toMutableList() ?: mutableListOf()
    }

    @ExcludeFromJacocoGeneratedReport
    fun checkOption(fieldKey: String, option: Option) {
        val selectedCheckBoxOptions = getCheckedOption(fieldKey).toMutableList()
        if (selectedCheckBoxOptions.contains(option)) {
            selectedCheckBoxOptions.remove(option)
        } else {
            selectedCheckBoxOptions.add(option)
        }
        selectedCheckBoxOptionMap[fieldKey] = selectedCheckBoxOptions
        _canEditReport.value = true
    }

    @ExcludeFromJacocoGeneratedReport
    fun getRadioOption(fieldKey: String): Option? {
        return selectedRadioOptionMap[fieldKey]
    }

    @ExcludeFromJacocoGeneratedReport
    fun selectOption(fieldKey: String, option: Option) {
        val currentSelectedRadioOption = getRadioOption(fieldKey)
        if (currentSelectedRadioOption != option) {
            selectedRadioOptionMap[fieldKey] = option
            _canEditReport.value = true
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun getNumberItems(key: String): List<DynamicItem.NumberItem> {
        return numberListMap[key] ?: emptyList()
    }

    @ExcludeFromJacocoGeneratedReport
    fun getBulletItems(key: String): List<DynamicItem.BulletItem> {
        return bulletListMap[key] ?: emptyList()
    }

    @ExcludeFromJacocoGeneratedReport
    fun deleteBulletItem(key: String, item: DynamicItem.BulletItem): List<DynamicItem.BulletItem> {
        val bulletItems = getBulletItems(key).toMutableList()
        bulletItems.remove(item)
        bulletListMap[key] = bulletItems
        _canEditReport.value = true
        return bulletItems
    }

    @ExcludeFromJacocoGeneratedReport
    fun deleteNumberItem(key: String, item: DynamicItem.NumberItem): List<DynamicItem.NumberItem> {
        val numberItems = getNumberItems(key).toMutableList()
        numberItems.remove(item)
        numberListMap[key] = numberItems
        _canEditReport.value = true
        return numberItems
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateBulletItem(key: String, item: DynamicItem.BulletItem): List<DynamicItem.BulletItem> {
        val bulletItems = getBulletItems(key).toMutableList()
        bulletItems.firstOrNull { it.id == item.id }?.let { oldItem ->
            bulletItems.replace(oldItem, item)
        }
        bulletListMap[key] = bulletItems
        _canEditReport.value = true
        return bulletItems
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateNumberItem(key: String, item: DynamicItem.NumberItem): List<DynamicItem.NumberItem> {
        val numberItems = getNumberItems(key).toMutableList()
        numberItems.firstOrNull { it.id == item.id }?.let { oldItem ->
            numberItems.replace(oldItem, item)
        }
        numberListMap[key] = numberItems
        _canEditReport.value = true
        return numberItems
    }

    fun addBulletItem(key: String): List<DynamicItem.BulletItem> {
        val bulletItems = getBulletItems(key).toMutableList()
        bulletItems.add(DynamicItem.BulletItem(text = null))
        bulletListMap[key] = bulletItems
        _canEditReport.value = true
        return bulletItems
    }

    @ExcludeFromJacocoGeneratedReport
    fun addExistBulletItems(formField: FormField) {
        (formField.value as? FormValue.ValueJsonArray)?.value?.let { array ->
            val numberItems = mutableListOf<DynamicItem.BulletItem>()
            array.forEach {
                numberItems.add(DynamicItem.BulletItem(text = it.asString))
            }
            bulletListMap[formField.key] = numberItems
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun addNumberItem(key: String): List<DynamicItem.NumberItem> {
        val numberItems = getNumberItems(key).toMutableList()
        numberItems.add(DynamicItem.NumberItem(text = null))
        numberListMap[key] = numberItems
        _canEditReport.value = true
        return numberItems
    }

    @ExcludeFromJacocoGeneratedReport
    fun addExistNumberItems(formField: FormField) {
        (formField.value as? FormValue.ValueJsonArray)?.value?.let { array ->
            val numberItems = mutableListOf<DynamicItem.NumberItem>()
            array.forEach {
                numberItems.add(DynamicItem.NumberItem(text = it.asString))
            }
            numberListMap[formField.key] = numberItems
        }
    }

    fun updateDate(year: Int, month: Int, dayOfMonth: Int) {
        calendar.run {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DATE, dayOfMonth)
        }
        _canEditReport.value = true
        _dateInString.postValue(calendar.time.toMediumDateInString())
    }

    fun updateTime(hourOfDay: Int, minute: Int) {
        calendar.run {
            set(Calendar.HOUR_OF_DAY, hourOfDay)
            set(Calendar.MINUTE, minute)
        }
        _canEditReport.value = true
        _timeInString.postValue(calendar.time.toShortTimeInString())
    }

    fun emitDefaultDateTime(formField: FormField? = null) {
        (formField?.value as? FormValue.ValueString)?.value?.let {
            TimeUtil.convertIsoDateStringToDate(it)?.let { date ->
                calendar.time = date
            }
        }
        val time = calendar.time
        _dateInString.postValue(time.toMediumDateInString())
        _timeInString.postValue(time.toShortTimeInString())
    }

    fun updatePhotoType(type: PhotoType?) {
        if (photoType != type) {
            photoType = type
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun addCapturePhoto() {
        capturePhotoPath?.let {
            addDeletablePhoto(it)
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun addDeletablePhoto(path: String) {
        _report.value?.let { report ->
            val photoItem = PhotoItem(path = path, isDeletable = true, reportUuid = report.uuid)
            addPhoto(photoItem)
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private fun addPhoto(photoItem: PhotoItem) {
        _photos.value?.let {
            val mutablePhotos = it.toMutableList()
            mutablePhotos.add(mutablePhotos.size - 1, photoItem)
            _photos.postValue(mutablePhotos)
            _canEditReport.value = true
            uploadPhoto(photoItem)
        }
    }

    private fun uploadPhoto(photoItem: PhotoItem) {
        if (photoItem.url == null) {
            viewModelScope.launch(dispatcherContext.io) {
                uploadPhotoItem(photoItem)
            }
        }
    }

    private suspend fun uploadPhotoItem(photoItem: PhotoItem) {
        photoItem.path?.let { path ->
            obsidianApi.fileAttachmentManager.uploadPhoto(path)?.let { fileAttachment ->
                val newPhotoItem = photoItem.copy(
                    attachmentId = fileAttachment.id,
                    url = fileAttachment.originalUrl
                )
                _photos.value?.let {
                    val list = it.toMutableList()
                    list.replace(photoItem, newPhotoItem)
                    _photos.postValue(list)
                }
            }
        }
    }

    fun uploadPendingPhotos() {
        viewModelScope.launch(dispatcherContext.io) {
            val scope = this
            _photos.value?.filter { it.url == null && it.attachmentId == null }
                ?.let { pendingItems ->
                    pendingItems.map {
                        scope.async {
                            uploadPhoto(it)
                        }
                    }.forEach {
                        it.await()
                    }
                }
        }
    }

    fun deletePhoto(photoItem: PhotoItem) {
        _photos.value?.let {
            val mutablePhotos = it.toMutableList()
            mutablePhotos.remove(photoItem)
            _photos.postValue(mutablePhotos)
        }
    }

    fun createCapturePhotoUri(): Uri? {
        capturePhotoPath = null
        return app.createImageFile()?.let { file ->
            app.getImageUriForFile(file).also {
                capturePhotoPath = file.absolutePath
            }
        }
    }

    fun updateSignature(signature: Signature, canEdit: Boolean = true) {
        _signature.postValue(signature)
        updateReportSignature(signature)
        _canEditReport.value = canEdit
    }

    @ExcludeFromJacocoGeneratedReport
    private fun updateReportSignature(signature: Signature) {
        signature.formFieldSignature?.let { signatureValue ->
            _report.value?.let { report ->
                val fields = report.getFormFields?.toMutableList()
                fields?.let {
                    it.firstOrNull { field -> field.id == signature.formFieldId }
                        ?.let { value ->
                            val formField = value.copy(
                                value = FormValue.ValueFormFieldSignature(signatureValue)
                            )
                            fields.replace(value, formField)
                            _report.postValue(
                                report.copy(
                                    formFields = fields.toJsonArray()
                                )
                            )
                        }
                }
            }
        }
    }

    fun getInputField(formField: FormField, needAssignValue: Boolean): TextFieldInput {
        val inputField = inputMap[formField.key] ?: TextFieldInput(
            if (formField.mandatory == true) {
                app.getString(R.string.mandatory_suffix_placeholder, formField.label ?: "")
            } else {
                formField.label ?: ""
            }
        ).also {
            inputMap[formField.key] = it
        }
        if (needAssignValue) {
            val value = (formField.value as? FormValue.ValueString)?.value
            inputField.text.value = value
            inputMap[formField.key] = inputField
        }
        return inputField
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateDropdown(value: String, key: String) {
        val report = report.value ?: return
        val fields = report.getFormFields ?: return
        fields.firstOrNull { it.fieldType == FieldType.DropDown && it.key == key }
            ?.let { formField ->
                val newValue = FormValue.ValueString(value)
                if (formField.value != newValue) {
                    val mutableFields = fields.toMutableList()
                    val newFormField = formField.copy(
                        value = newValue
                    )
                    mutableFields.replace(formField, newFormField)
                    _canEditReport.value = true
                    _report.postValue(report.copy(formFields = mutableFields.toJsonArray()))
                }
            }
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateRiskLevel(riskLevel: RiskLevel) {
        riskAssessment = riskAssessment?.copy(
            riskLevel = riskLevel
        ) ?: RiskAssessment(riskLevel = riskLevel)
        _canEditReport.value = true
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateSeverity(severity: Severity) {
        riskAssessment = riskAssessment?.copy(
            severity = severity
        ) ?: RiskAssessment(severity = severity)
        _canEditReport.value = true
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateLikelihood(likelihood: Likelihood) {
        riskAssessment = riskAssessment?.copy(
            likelihood = likelihood
        ) ?: RiskAssessment(likelihood = likelihood)
        _canEditReport.value = true
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateCategory(extendedCategory: ExtendedCategory) {
        _report.value?.let {
            val report = it.copy(
                categoryId = extendedCategory.categoryData.id,
                categoriesTitle = extendedCategory.categoryTitles
            )
            _report.value = report
        }
        _canEditReport.value = true
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateReportState(reportState: ReportState) {
        if (selectedReportState != reportState) {
            selectedReportState = reportState
            val fields = _report.value?.getFormFields?.toMutableList()

            val fieldsArray =
                fields?.firstOrNull { it.fieldType == FieldType.ReportState }?.let { stateField ->
                    val newStateField = stateField.copy(
                        value = FormValue.ValueJsonObject(
                            gson.toJsonTree(reportState).asJsonObject
                        )
                    )
                    fields.replace(stateField, newStateField)
                    fields.toJsonArray()
                } ?: _report.value?.formFields

            _report.value?.copy(
                reportState = gson.toJsonTree(reportState).asJsonObject,
                reportStateId = reportState.id,
                formFields = fieldsArray
            )?.let {
                _report.postValue(it)
            }
            _canEditReport.value = true
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun submitReport(animationTime: Long = ANIMATION_TIME + 500) {
        val startTime = System.currentTimeMillis()
        _report.value?.let { report ->
            viewModelScope.launch(dispatcherContext.io) {
                launch { uploadPendingPhotos() }.join()
                var fields = updatePhotoFormValue(report.getFormFields)
                fields = updateCheckboxOptions(fields)
                fields = updateSelectionOptions(fields)
                fields = updateIntegerRangeField(fields)
                fields = updateDynamicFields(fields, FieldType.BulletedList) {
                    getBulletItems(it)
                }
                fields = updateDynamicFields(fields, FieldType.NumberedList) {
                    getNumberItems(it)
                }
                withContext(dispatcherContext.main) {
                    fields = updateInputText(fields)
                }
                val userDetails = obsidianApi.provideSessionsManager().userDetails
                val obsidianReport = report.copy(
                    formFields = fields?.filter { it.value != null }
                        ?.toJsonArray(),
                    riskLevel = if (riskAssessment != null && riskAssessment?.riskLevel != null) gson.toJsonTree(
                        riskAssessment?.riskLevel
                    )?.asJsonObject else null,
                    riskAssessment = if (riskAssessment != null) gson.toJsonTree(
                        riskAssessment
                    )?.asJsonObject else null,
                    userId = userDetails?.id?.toInt(),
                    userShortName = listOfNotNull(
                        userDetails?.firstName,
                        userDetails?.lastName
                    ).joinToString(" "),
                    isoCreatedAt = TimeUtil.getIsoDateInString(),
                    reportState = selectedReportState?.let { gson.toJsonTree(it).asJsonObject }
                )
                if (isCreatingReport) {
                    obsidianApi.reportManager.create(obsidianReport)
                } else {
                    obsidianApi.reportManager.update(obsidianReport)
                }
                val totalTime = System.currentTimeMillis() - startTime
                if (totalTime < animationTime) {
                    delay(animationTime - totalTime)
                }
                _finishCreateReport.postValue(Unit)
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private fun updateCheckboxOptions(fields: List<FormField>?): List<FormField>? {
        fields?.filter { it.fieldType == FieldType.CheckBox }?.let { checkboxFields ->
            if (checkboxFields.isNotEmpty()) {
                val mutableFields = fields.toMutableList()
                checkboxFields.forEach { field ->
                    val selectedCheckBoxOptions = getCheckedOption(field.key)
                    if (selectedCheckBoxOptions.isNotEmpty()) {
                        val newFormField = field.copy(
                            value = FormValue.ValueJsonArray(
                                selectedCheckBoxOptions.map { it.value }.toJsonArray()
                            )
                        )
                        mutableFields.replace(field, newFormField)
                    } else {
                        mutableFields.remove(field)
                    }
                }
                return mutableFields
            }
        }
        return fields
    }

    @ExcludeFromJacocoGeneratedReport
    private fun updateSelectionOptions(fields: List<FormField>?): List<FormField>? {
        fields?.filter { it.fieldType == FieldType.RadioButton }?.let { radioFields ->
            if (radioFields.isNotEmpty()) {
                val mutableFields = fields.toMutableList()
                radioFields.forEach { field ->
                    val value = getRadioOption(field.key)?.value
                    if (value != null) {
                        val newFormField = field.copy(
                            value = FormValue.ValueString(value)
                        )
                        mutableFields.replace(field, newFormField)
                    } else {
                        mutableFields.remove(field)
                    }
                }
                return mutableFields
            }
        }
        return fields
    }

    @ExcludeFromJacocoGeneratedReport
    private fun updateDynamicFields(
        fields: List<FormField>?,
        fieldType: FieldType,
        getDynamicItems: (key: String) -> List<DynamicItem>
    ): List<FormField> {
        val mutableFields = fields?.toMutableList() ?: return emptyList()
        fields.filter { it.fieldType == fieldType }.forEach { field ->
            val values = getDynamicItems(field.key).mapNotNull { it.value }
            if (values.isEmpty()) {
                mutableFields.remove(field)
            } else {
                val newFormField = field.copy(
                    value = FormValue.ValueJsonArray(values.toJsonArray())
                )
                mutableFields.replace(field, newFormField)
            }
        }
        return mutableFields
    }

    @ExcludeFromJacocoGeneratedReport
    private fun updateDateTimeFormValue() {
        val report = report.value ?: return
        val fields = report.getFormFields ?: return
        fields.firstOrNull { it.fieldType == FieldType.DateAndTime }?.let { formField ->
            val dateInString = dateInString.value
            val timeInString = timeInString.value
            if (dateInString != null && timeInString != null) {
                val mutableFields = fields.toMutableList()
                val newFormField = formField.copy(
                    value = FormValue.ValueString("$dateInString $timeInString")
                )
                mutableFields.replace(formField, newFormField)
                _report.postValue(report.copy(formFields = mutableFields.toJsonArray()))
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private fun updatePhotoFormValue(fields: List<FormField>?): List<FormField>? {
        val fieldImages: List<FormFieldImage>? =
            realPhotos?.filter {
                it.attachmentId != null && it.url != null
            }?.mapNotNull {
                val id = it.attachmentId
                val url = it.url
                if (id != null && url != null) {
                    FormFieldImage(
                        id = id,
                        originalUrl = url,
                        filename = "",
                        styleUrl = null
                    )
                } else null
            }
        return fields?.firstOrNull { it.fieldType == FieldType.Image }
            ?.let { photoFormField ->
                val mutableFields = fields.toMutableList()
                val newFormField = photoFormField.copy(
                    value = FormValue.ValueFormFieldImage(fieldImages ?: emptyList())
                )
                mutableFields.replace(photoFormField, newFormField)
                mutableFields
            } ?: fields
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateInputText(fields: List<FormField>?): List<FormField>? {
        return fields?.let { list ->
            val texBoxFields = list.filter {
                it.fieldType == FieldType.ShortTextBox || it.fieldType == FieldType.LongTextBox
            }
            if (texBoxFields.isNotEmpty()) {
                val mutableList = list.toMutableList()
                texBoxFields.forEach { field ->
                    val newField = field.copy(
                        value = FormValue.ValueString(getInputField(field, false).text.value ?: "")
                    )
                    mutableList.replace(field, newField)
                }
                mutableList
            } else {
                list
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateRangeValue(value: Int) {
        rangeValue = value
        _canEditReport.value
    }

    @ExcludeFromJacocoGeneratedReport
    private fun updateIntegerRangeField(fields: List<FormField>?): List<FormField>? {
        if (rangeValue == -1) return fields
        fields?.firstOrNull { it.fieldType == FieldType.IntegerRange }?.let { formField ->
            (formField.data as? DataValue.DataJsonObject)?.let { data ->
                val sliderData = getSlideData(data.value)
                if (rangeValue >= sliderData.minimum && rangeValue <= sliderData.maximum) {
                    val mutableFields = fields.toMutableList()
                    val newFormField = formField.copy(
                        value = FormValue.ValueInt(rangeValue)
                    )
                    mutableFields.replace(formField, newFormField)
                    return mutableFields
                }
            }
        }
        return fields
    }

    fun addExistPhoto(photoItems: List<PhotoItem>) {
        val photos = _photos.value?.toMutableList() ?: mutableListOf()
        val willAddPhotos = if (photos.isEmpty()) {
            photoItems
        } else {
            photoItems.filter { item ->
                photos.firstOrNull { it.attachmentId == item.attachmentId } == null
            }
        }
        if (willAddPhotos.isNotEmpty()) {
            photos.addAll(0, willAddPhotos)
            _photos.value = photos
        }
    }

    @ExcludeFromJacocoGeneratedReport
    fun updateCanEditReportByTextBox(key: String, value: String) {
        val report = report.value ?: return
        val fields = report.getFormFields ?: return
        fields.firstOrNull { it.key == key }?.let { formField ->
            val newValue = FormValue.ValueString(value)
            if (formField.value != newValue) {
                val mutableFields = fields.toMutableList()
                val newFormField = formField.copy(
                    value = newValue
                )
                mutableFields.replace(formField, newFormField)
                _report.postValue(report.copy(formFields = mutableFields.toJsonArray()))
                _canEditReport.postValue(true)
            }
        }
    }

    @ExcludeFromJacocoGeneratedReport
    private fun <T> List<T>.toJsonArray(): JsonArray {
        return gson.toJsonTree(
            this,
            object : TypeToken<List<T>>() {}.type
        ).asJsonArray
    }

    fun updateCanEditReportBySignature(canEdit: Boolean) {
        _canEditReport.postValue(canEdit)
    }

    companion object {
        const val ANIMATION_TIME = 1200L
    }
}
