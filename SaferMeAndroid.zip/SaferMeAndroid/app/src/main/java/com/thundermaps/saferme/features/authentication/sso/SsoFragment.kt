package com.thundermaps.saferme.features.authentication.sso

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.thundermaps.apilib.android.api.com.thundermaps.apilib.android.logging.ELog
import com.thundermaps.apilib.android.api.com.thundermaps.apilib.android.logging.SafermeException
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.Screen
import com.thundermaps.saferme.databinding.FragmentSsoBinding
import com.thundermaps.saferme.features.authentication.UserDetailsListener
import com.thundermaps.saferme.features.authentication.login.LoginFragmentDirections
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SsoFragment : BaseFragment<FragmentSsoBinding, SsoViewModel>() {
    override val viewModel: SsoViewModel by viewModels()
    private val navigationController get() = findNavController()
    override fun provideLayoutId(): Int = R.layout.fragment_sso
    private val loginErrorDialog by lazy {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.sso_failed_title)
            .setMessage(R.string.sso_failed_message)
            .setPositiveButton(android.R.string.ok) { dialog, _ ->
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel) { dialog, _ ->
                dialog.dismiss()
            }
            .create()
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupWebView()
        viewModel.progressSsoLogin.observe(viewLifecycleOwner) {
            if (it.isError) {
                showErrorDialog()
            } else {
                loginErrorDialog.dismiss()
            }
        }
        viewModel.signInUrl.observe(viewLifecycleOwner) { url ->
            url?.let {
                binding.ssoLayout.visibility = View.GONE
                binding.webview.visibility = View.VISIBLE
                binding.webview.loadUrl(it)
                actionController?.hideToolBar()
            }
        }
        viewModel.nextScreen.observe(viewLifecycleOwner) {
            if (it != null) (activity as? UserDetailsListener)?.getUserDetails()
            it?.let { nextScreen ->
                when (nextScreen) {
                    Screen.UPDATE_PROFILE -> {}
                    Screen.SELECT_TEAM -> {
                        navigationController.navigate(LoginFragmentDirections.openTeamsScreen())
                    }
                    Screen.MAP -> {
                        navigationController.navigate(LoginFragmentDirections.openMainScreen())
                    }
                    else -> {}
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webview.settings.javaScriptEnabled = true
        binding.webview.webViewClient = MyWebViewClient()
    }

    private fun showErrorDialog() {
        if (!loginErrorDialog.isShowing) loginErrorDialog.show()
    }

    private fun clearWebViewData() {
        binding.webview.clearCache(true)
        binding.webview.clearFormData()
        binding.webview.clearHistory()
    }

    inner class MyWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
            if (url?.contains(CALL_BACK_PART) == true) {
                binding.ssoLayout.visibility = View.VISIBLE
                binding.webview.visibility = View.GONE
                actionController?.showToolBar()
                try {
                    viewModel.loadSsoSessions((url.split(CALL_BACK_PART)[1]).split("&session_state")[0])
                } catch (exception: Exception) {
                    ELog.e(SafermeException.Builder("", "", exception).build())
                }
                clearWebViewData()
                return true
            }
            return false
        }
    }

    companion object {
        private const val CALL_BACK_PART = "//auth/?code="
    }
}
