package com.thundermaps.saferme.features.main.category

import androidx.annotation.VisibleForTesting
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianCategory
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.ui.extensions.replace
import com.thundermaps.saferme.features.main.category.model.CategoryData
import com.thundermaps.saferme.features.main.category.model.DepthLevel
import com.thundermaps.saferme.features.main.category.model.ExtendedCategory
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class CategoryViewModel @Inject constructor(
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    private var channelId: Int = 0
    private val selectCategoryIds = mutableListOf<Int>()
    private val _categoryData = mutableListOf<CategoryData>()
    private val _categories = MutableLiveData<List<CategoryData>>()
    var numberOfSync = 0
        private set
    val categories: LiveData<List<CategoryData>> = _categories

    fun updateChannelId(id: Int) {
        if (channelId != id) {
            channelId = id
            numberOfSync = 0
        }
    }

    fun syncCategory() {
        numberOfSync++
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.categoryManager.syncCategory(channelId)
        }
    }

    fun getSavedCategories() = liveData(dispatcherContext.io) {
        emitSource(obsidianApi.categoryManager.getCategories(channelId))
    }

    fun updateCategoryData(categories: List<ObsidianCategory>) {
        _categoryData.clear()
        selectCategoryIds.clear()
        _categoryData.addAll(categories.map {
            CategoryData.of(it, false)
        })
        _categories.postValue(_categoryData.filter { it.depth == DepthLevel.FIRST_LEVEL })
    }

    fun onItemSelect(item: CategoryData) {
        if (item.id == selectCategoryIds.lastOrNull()) return
        when (item.depth) {
            DepthLevel.FIRST_LEVEL -> {
                selectCategoryIds.clear()
                selectCategoryIds.add(item.id)
                var selectedIndex = 0
                val categories = _categoryData.filter { it.depth == DepthLevel.FIRST_LEVEL }
                    .mapIndexed { index, it ->
                        if (it.id == item.id) {
                            selectedIndex = index
                            it.copy(isSelected = true)
                        } else {
                            it
                        }
                    }.toMutableList()

                val subCategoryOfSelectedItem = _categoryData.filter { it.parentId == item.id }

                if (subCategoryOfSelectedItem.isNotEmpty()) {
                    categories.addAll(selectedIndex + 1, subCategoryOfSelectedItem)
                }
                _categories.postValue(categories)
            }
            DepthLevel.SECOND_LEVEL -> {
                var parentIndex = 0
                selectCategoryIds.clear()

                val categories = _categoryData.filter { it.depth == DepthLevel.FIRST_LEVEL }
                    .mapIndexed { index, categoryData ->
                        if (categoryData.id == item.parentId) {
                            parentIndex = index
                            selectCategoryIds.add(categoryData.id)
                            categoryData.copy(isSelected = true)
                        } else {
                            categoryData
                        }
                    }.toMutableList()
                val subCategoryOfSelectedItem = _categoryData.filter { it.parentId == item.id }

                selectCategoryIds.add(item.id)
                val selectedItem = item.copy(isSelected = true)
                val siblings = _categoryData.filter { it.parentId == item.parentId }.map {
                    if (it.id == item.id) {
                        selectedItem
                    } else {
                        it
                    }
                }
                categories.addAll(parentIndex + 1, siblings)

                val selectedItemIndex = categories.indexOf(selectedItem)
                categories.addAll(selectedItemIndex + 1, subCategoryOfSelectedItem)

                _categories.postValue(categories)
            }
            DepthLevel.THIRD_LEVEL -> {
                _categories.value?.let { list ->
                    val categories = list.toMutableList()
                    categories.filter { it.parentId == item.parentId }.forEach { sibling ->
                        if (selectCategoryIds.contains(sibling.id)) {
                            categories.replace(sibling, sibling.copy(isSelected = false))
                            selectCategoryIds.remove(sibling.id)
                        }
                    }
                    categories.replace(item, item.copy(isSelected = true))
                    selectCategoryIds.add(item.id)
                    _categories.postValue(categories)
                }
            }
            else -> {}
        }
    }

    fun hasNoChildren(id: Int) = _categoryData.none { it.parentId == id }

    @VisibleForTesting
    fun getCategoryTitles(parentId: Int?, titles: String): String {
        return if (parentId == null) {
            titles
        } else {
            val parent = _categoryData.first { it.id == parentId }
            getCategoryTitles(parent.parentId, "$titles, ${parent.name}")
        }
    }

    fun getExtendedCategoryData(category: CategoryData) = ExtendedCategory(
        category,
        getCategoryTitles(category.parentId, category.name)
    )
}
