package com.thundermaps.saferme.features.main.tasks.domain.di

import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.TaskManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object TaskModule {
    @Provides
    fun provideTasksManager(
        obsidianApi: ObsidianApi
    ): TaskManager = obsidianApi.Tasks()
}
