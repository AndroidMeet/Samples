package com.thundermaps.saferme.features.main.settings.domain

data class DeviceDetails(
    val appVersion: String,
    val appBuild: String,
    val deviceModel: String,
    val deviceVersion: String
)
