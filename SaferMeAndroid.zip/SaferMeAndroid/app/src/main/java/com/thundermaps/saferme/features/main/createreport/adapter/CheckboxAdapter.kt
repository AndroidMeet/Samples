package com.thundermaps.saferme.features.main.createreport.adapter

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import androidx.annotation.LayoutRes
import com.thundermaps.apilib.android.api.responses.models.Option
import com.thundermaps.saferme.core.domain.utils.ItemInterface

class CheckboxAdapter(
    context: Context,
    @LayoutRes res: Int,
    val items: List<Option>,
    val itemInterface: ItemInterface
) : ArrayAdapter<Option>(context, res, items) {
    private val selectedOptions = mutableListOf<Option>()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent)
        (view as? CheckBox)?.let {
            items.getOrNull(position)?.let { option ->
                it.text = option.label
                it.isChecked = (selectedOptions.contains(option))
            }
            it.setOnCheckedChangeListener { _, _ ->
                itemInterface.onItemSelected(position)
            }
        }
        return view
    }

    fun updateSelectedItems(options: List<Option>) {
        selectedOptions.clear()
        selectedOptions.addAll(options)
    }
}
