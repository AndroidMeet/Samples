package com.thundermaps.saferme.features.main.search

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.domain.models.SmSearchSuggestion
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val searchAddressUseCase: SearchAddressUseCase,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    val suggestions: LiveData<List<SmSearchSuggestion>> =
        searchAddressUseCase.saferMeSearchSuggestions

    fun didSearchSelected(suggestion: SmSearchSuggestion) {
        searchAddressUseCase.didSelectSearchSuggestion(suggestion)
    }

    fun searchText(text: String) = searchAddressUseCase.didSearch(text)

    fun startSearch() {
        viewModelScope.launch(dispatcherContext.io) {
            searchAddressUseCase.startSearch()
        }
    }
}
