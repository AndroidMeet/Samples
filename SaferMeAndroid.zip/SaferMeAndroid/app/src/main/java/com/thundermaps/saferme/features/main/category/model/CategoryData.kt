package com.thundermaps.saferme.features.main.category.model

import android.os.Parcelable
import com.saferme.obsidian.store.resources.ObsidianCategory
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.domain.models.DiffItem
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class CategoryData(
    val id: Int,
    val name: String,
    val depth: DepthLevel,
    val parentId: Int?,
    val isSelected: Boolean = false
) : DiffItem, Parcelable {
    override val uniqueId: Any
        get() = id

    companion object {
        @ExcludeFromJacocoGeneratedReport
        fun of(obsidianCategory: ObsidianCategory, isSelected: Boolean) = CategoryData(
            id = obsidianCategory.id,
            name = obsidianCategory.name,
            parentId = obsidianCategory.parentId,
            isSelected = isSelected,
            depth = obsidianCategory.depth.toDepthLevel()
        )

        @ExcludeFromJacocoGeneratedReport
        private fun Int.toDepthLevel() = when (this) {
            0 -> DepthLevel.ROOT
            1 -> DepthLevel.FIRST_LEVEL
            2 -> DepthLevel.SECOND_LEVEL
            3 -> DepthLevel.THIRD_LEVEL
            else -> DepthLevel.THIRD_LEVEL
        }
    }
}

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class ExtendedCategory(
    val categoryData: CategoryData,
    val categoryTitles: String
) : Parcelable

@ExcludeFromJacocoGeneratedReport
enum class DepthLevel(val value: Int) {
    ROOT(0), FIRST_LEVEL(1), SECOND_LEVEL(2), THIRD_LEVEL(3)
}
