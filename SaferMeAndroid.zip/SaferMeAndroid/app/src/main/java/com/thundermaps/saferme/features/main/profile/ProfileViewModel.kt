package com.thundermaps.saferme.features.main.profile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.features.main.profile.domain.Profile
import com.thundermaps.saferme.features.main.profile.domain.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val profileRepository: ProfileRepository,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    private val _profile = MutableLiveData<Result<Profile>>(Result.Initial)
    val profile: LiveData<Profile?> = Transformations.map(_profile) {
        it.getNullableData()
    }

    fun loadProfile() {
        _profile.value = Result.Loading(null)
        viewModelScope.launch(dispatcherContext.io) {
            _profile.postValue(profileRepository.getProfile())
        }
    }
}
