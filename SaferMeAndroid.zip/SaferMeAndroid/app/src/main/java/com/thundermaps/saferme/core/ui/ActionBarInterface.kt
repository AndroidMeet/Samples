package com.thundermaps.saferme.core.ui

import androidx.annotation.StringRes

interface ActionBarInterface {
    fun showNavigationIcon()
    fun hideNavigationIcon()
    fun hideToolBar()
    fun showToolBar()
    fun updateTitle(@StringRes titleId: Int) {}
}
