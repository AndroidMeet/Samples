package com.thundermaps.saferme.features.main.createreport

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.View.MeasureSpec
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.LinearLayout
import android.widget.ListView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.children
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.fragment.findNavController
import com.google.android.material.textfield.TextInputLayout
import com.jaygoo.widget.OnRangeChangedListener
import com.jaygoo.widget.RangeSeekBar
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.getFormFields
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.reportStateObject
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.riskAssessmentObject
import com.thundermaps.apilib.android.api.responses.models.DataValue
import com.thundermaps.apilib.android.api.responses.models.FieldType
import com.thundermaps.apilib.android.api.responses.models.FormField
import com.thundermaps.apilib.android.api.responses.models.FormFieldSignature
import com.thundermaps.apilib.android.api.responses.models.FormValue
import com.thundermaps.apilib.android.api.responses.models.Option
import com.thundermaps.apilib.android.api.responses.models.ReportState
import com.thundermaps.apilib.android.api.responses.models.RiskAssessment
import com.thundermaps.apilib.android.api.responses.models.RiskMatrixConfig
import com.thundermaps.apilib.android.api.responses.models.SliderData
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.domain.models.PhotoType
import com.thundermaps.saferme.core.domain.models.ReportData
import com.thundermaps.saferme.core.domain.models.Signature
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.core.ui.GridSpacingItemDecoration
import com.thundermaps.saferme.core.ui.extensions.checkAndRequestPermissions
import com.thundermaps.saferme.core.ui.extensions.getCategoryId
import com.thundermaps.saferme.core.ui.extensions.getImagePathOfSelectImage
import com.thundermaps.saferme.core.ui.extensions.getPhotos
import com.thundermaps.saferme.core.ui.extensions.loadData
import com.thundermaps.saferme.core.ui.extensions.marginTop
import com.thundermaps.saferme.core.ui.extensions.removeFromParent
import com.thundermaps.saferme.core.ui.extensions.setTheme
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import com.thundermaps.saferme.databinding.FragmentCreateReportBinding
import com.thundermaps.saferme.databinding.ViewDateTimeBinding
import com.thundermaps.saferme.databinding.ViewFileAttachmentBinding
import com.thundermaps.saferme.databinding.ViewLableListBinding
import com.thundermaps.saferme.databinding.ViewListWithAddBinding
import com.thundermaps.saferme.databinding.ViewLongBoxTextBinding
import com.thundermaps.saferme.databinding.ViewPhotoBinding
import com.thundermaps.saferme.databinding.ViewSectionBreakBinding
import com.thundermaps.saferme.databinding.ViewShortBoxTextBinding
import com.thundermaps.saferme.databinding.ViewSignatureBinding
import com.thundermaps.saferme.databinding.ViewSliderBinding
import com.thundermaps.saferme.databinding.ViewWebviewContainerBinding
import com.thundermaps.saferme.features.main.category.CategoryFragment.Companion.CATEGORY_KEY
import com.thundermaps.saferme.features.main.category.model.ExtendedCategory
import com.thundermaps.saferme.features.main.createreport.adapter.CheckboxAdapter
import com.thundermaps.saferme.features.main.createreport.adapter.DynamicAdapter
import com.thundermaps.saferme.features.main.createreport.adapter.PhotoAdapter
import com.thundermaps.saferme.features.main.createreport.adapter.RadioAdapter
import com.thundermaps.saferme.features.main.createreport.adapter.UpdateItem
import com.thundermaps.saferme.features.main.createreport.models.DynamicItem
import com.thundermaps.saferme.features.main.dropdown.domain.model.SelectionOptionData
import com.thundermaps.saferme.features.main.dropdown.domain.model.SelectionOptionList
import com.thundermaps.saferme.features.main.photoviewer.PhotoViewerData
import com.thundermaps.saferme.features.main.signature.SignatureFragment.Companion.SIGNATURE_KEY
import dagger.hilt.android.AndroidEntryPoint
import java.util.Calendar
import timber.log.Timber

@SuppressLint("InflateParams")
@AndroidEntryPoint
class CreateReportFragment : BaseFragment<FragmentCreateReportBinding, CreateReportViewModel>() {
    init {
        isPersistenceView = true
    }

    private val navigation get() = findNavController()
    private val _context: Context get() = requireContext()
    override val viewModel: CreateReportViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_create_report
    private val container get() = binding.container
    private lateinit var inflater: LayoutInflater

    private val categoryView by lazy {
        autoCompleteView.also {
            it.setHint(R.string.field_type_category)
            it.editText?.let { editText ->

                editText.setOnClickListener {
                    val channelId =
                        viewModel.channel.value?.id?.toInt() ?: viewModel.report.value?.accountId
                    if (channelId != null) {
                        navigation.navigate(
                            CreateReportFragmentDirections.openCategoryFragment(
                                channelId
                            )
                        )
                    }
                }
            }
        }
    }

    private val viewShortBoxTextBinding get() = ViewShortBoxTextBinding.inflate(inflater)

    private val viewLongBoxTextBinding get() = ViewLongBoxTextBinding.inflate(inflater)

    private val riskView by lazy {
        autoCompleteView
    }

    private val severityView by lazy {
        autoCompleteView.also {
            it.setHint(R.string.field_type_severity)
        }
    }

    private val likelihoodView by lazy {
        autoCompleteView.also {
            it.setHint(R.string.field_type_likelihood)
        }
    }

    private val viewLabelListBinding get() = ViewLableListBinding.inflate(inflater)

    private val fieldAttachmentBinding by lazy {
        ViewFileAttachmentBinding.inflate(inflater)
    }

    private val viewListWithAddBinding get() = ViewListWithAddBinding.inflate(inflater)

    private val viewDateTimeBinding by lazy {
        ViewDateTimeBinding.inflate(inflater)
    }

    private val sectionBreakBinding get() = ViewSectionBreakBinding.inflate(inflater)

    private val viewWebViewContainerBinding by lazy {
        ViewWebviewContainerBinding.inflate(inflater)
    }

    private val dateDialog by lazy {
        val calendar = viewModel.calendar
        DatePickerDialog(
            _context,
            { _, year, month, dayOfMonth ->
                viewModel.updateDate(year = year, month = month, dayOfMonth = dayOfMonth)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DATE)
        )
    }

    private val timeDialog by lazy {
        val calendar = viewModel.calendar
        TimePickerDialog(
            _context,
            { _, hourOfDay, minute ->
                viewModel.updateTime(hourOfDay, minute)
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        )
    }

    private val autoCompleteView
        get() = layoutInflater.inflate(
            R.layout.view_dropdown,
            null,
            false
        ) as TextInputLayout

    private val viewSliderBinding get() = ViewSliderBinding.inflate(inflater)

    private val viewPhotoBinding by lazy {
        ViewPhotoBinding.inflate(inflater)
    }

    private val photoAdapter by lazy {
        PhotoAdapter().apply {
            updateInterface(object : ItemInterface {
                override fun <T : Any> onItemSelected(item: T) {
                    (item as? PhotoItem)?.let {
                        if (it.isAddItem) {
                            removePhotoTypeInStackEntry()
                            navigation.navigate(CreateReportFragmentDirections.openSelectPhotoModel())
                        } else {
                            viewModel.realPhotos?.let { photos ->
                                val position = photos.indexOf(it)
                                navigation.navigate(
                                    CreateReportFragmentDirections.openPhotoViewer(
                                        PhotoViewerData(position, photos)
                                    )
                                )
                            }
                        }
                    }
                }

                override fun <T : Any> onItemDelete(item: T) {
                    super.onItemDelete(item)
                    (item as? PhotoItem)?.let {
                        viewModel.deletePhoto(it)
                    }
                }
            })
        }
    }

    private val gridSpacingItemDecoration by lazy {
        GridSpacingItemDecoration(
            NUMBER_OF_COLUMN,
            _context.resources.getDimension(R.dimen.margin_medium).toInt(),
            false
        )
    }

    private val photoObserver by lazy {
        LifecycleEventObserver { _, event ->
            navBackStackEntry?.savedStateHandle?.let { savedStateHandle ->
                if (event == Lifecycle.Event.ON_RESUME &&
                    savedStateHandle.contains(SelectPhotoBottomModal.PHOTO_TYPE)
                ) {
                    savedStateHandle.get<PhotoType>(SelectPhotoBottomModal.PHOTO_TYPE)?.let {
                        viewModel.updatePhotoType(it)
                        getPhoto()
                    }
                }
            }
        }
    }

    private val resultCaptureImageLauncher by lazy {
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                viewModel.addCapturePhoto()
            }
        }
    }

    private val resultSelectPhotoLauncher by lazy {
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val data: Intent? = result.data
                data?.data?.let {
                    _context.getImagePathOfSelectImage(it)?.let { path ->
                        viewModel.addDeletablePhoto(path)
                    }
                }
            }
        }
    }

    private val viewSignatureBinding by lazy {
        ViewSignatureBinding.inflate(inflater)
    }

    private val navController get() = findNavController()
    private val navBackStackEntry
        get() = try {
            navController.getBackStackEntry(R.id.createReportFragment)
        } catch (exception: IllegalArgumentException) {
            null
        }

    private val wrapContentHeightParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private val submitButtonAnimation by lazy {
        AlphaAnimation(1.0f, 0.2f).apply {
            duration = CreateReportViewModel.ANIMATION_TIME
            setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(animation: Animation?) {
                    binding.submitButton.setText(R.string.submit)
                }

                override fun onAnimationEnd(animation: Animation?) {
                    setSubmitButtonAnimationState()
                }

                override fun onAnimationRepeat(animation: Animation?) {
                    setSubmitButtonAnimationState()
                }
            })
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        this.inflater = inflater
        resultCaptureImageLauncher
        resultSelectPhotoLauncher
        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.getParcelable<ReportData>(REPORT_DATA_KEY)?.let {
            viewModel.updateReportData(it)
        }
        createReport()
        viewModel.finishCreateReport.observe(viewLifecycleOwner) {
            if (it != null) {
                findNavController().popBackStack()
            }
        }
        setupStateView()
        viewModel.titleId.observe(viewLifecycleOwner) {
            actionController?.updateTitle(it)
        }
        binding.submitButton.setOnClickListener {
            viewModel.submitReport()
            binding.submitButton.startAnimation(submitButtonAnimation)
        }
        observerToCreateReportView()
        observerRiskValueChange()

        viewModel.canEditReport.observe(viewLifecycleOwner) {
            Timber.e("=== Meet Can edit report : $it")
        }
    }

    private fun observerToCreateReportView() {
        viewModel.report.observe(viewLifecycleOwner) { reportValue ->
            binding.veilLayout.unVeil()
            reportValue?.let { report ->
                report.reportStateObject?.let { updateStateValue(it) }
                report.getFormFields?.forEach { formField ->
                    when (formField.fieldType) {
                        FieldType.Category -> addCategoryComponent(formField)
                        FieldType.ShortTextBox -> addShortTextBox(formField)
                        FieldType.LongTextBox -> addLongTextBox(formField)
                        FieldType.RiskMatrix ->
                            (formField.data as? DataValue.DataJsonObject)?.let { data ->
                                addRiskMatrix(
                                    viewModel.getConfigMatrix(data.value),
                                    reportValue.riskAssessmentObject
                                )
                            }
                        FieldType.DropDown -> addDropdown(formField)
                        FieldType.CheckBox -> addCheckBoxes(formField)
                        FieldType.RadioButton -> addRadioButtons(formField)
                        FieldType.FileUpload -> {
                            val binding = fieldAttachmentBinding
                            binding.root.tag = formField.key
                            container.addViewWithTryCatch(binding.root)
                        }
                        FieldType.BulletedList -> addBulletList(formField)
                        FieldType.NumberedList -> addNumberList(formField)
                        FieldType.DateAndTime -> addDateTime(formField)
                        FieldType.IntegerRange -> (formField.data as? DataValue.DataJsonObject)?.let { data ->
                            addSlider(
                                viewModel.getSlideData(data.value),
                                formField.value,
                                formField.key
                            )
                        }
                        FieldType.SectionBreak -> {
                            val binding = sectionBreakBinding
                            binding.root.tag = formField.key
                            container.addViewWithTryCatch(binding.root)
                        }
                        FieldType.Image -> addPhoto(reportValue.uuid, formField)
                        FieldType.Signature -> addSignature(report.uuid, formField)
                        FieldType.FreeText -> addFreeTextField(formField)
                        else -> {
                            // Do nothing
                        }
                    }
                }
            }
        }
    }

    private fun observerRiskValueChange() {
        observeBackStackEntryDrop(KEY_RISK_LEVEL) { result ->
            viewModel.riskMatrixConfig?.let { matrixConfig ->
                matrixConfig.riskLevels.firstOrNull { it.label == result }?.let { selectedValue ->
                    viewModel.updateRiskLevel(selectedValue)
                    riskView.editText?.setText(result)
                }
            }
        }

        observeBackStackEntryDrop(KEY_SEVERITY) { result ->
            viewModel.riskMatrixConfig?.let { matrixConfig ->
                matrixConfig.severities.firstOrNull { it.label == result }?.let { selectedValue ->
                    viewModel.updateSeverity(selectedValue)
                    severityView.editText?.setText(result)
                }
            }
        }

        observeBackStackEntryDrop(KEY_LIKELIHOODS) { result ->
            viewModel.riskMatrixConfig?.let { matrixConfig ->
                matrixConfig.likelihoods.firstOrNull { it.label == result }?.let { selectedValue ->
                    viewModel.updateLikelihood(selectedValue)
                    likelihoodView.editText?.setText(result)
                }
            }
        }
    }

    private fun observeBackStackEntryDrop(key: String, callBack: (value: String) -> Unit) {
        navigation.currentBackStackEntry?.savedStateHandle?.getLiveData<String>(
            key
        )?.observe(viewLifecycleOwner) { result ->
            callBack(result)
        }
    }

    fun setSubmitButtonAnimationState() {
        binding.submitButton.setText(R.string.report_submitted)
        binding.submitButton.setBackgroundColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.report_submitted
            )
        )
    }

    private fun setupStateView() {
        val inputView = binding.stateView.root.also {
            it.setHint(R.string.state)
            it.setEndIconOnClickListener(null)
        }
        viewModel.reportStates.observe(viewLifecycleOwner) { it ->
            it?.let { states ->
                val labels = states.map { SelectionOptionData(it.name) }
                inputView.editText?.let { editText ->
                    editText.setOnClickListener {
                        navigation.navigate(
                            CreateReportFragmentDirections.selectionOptionFragment(
                                SelectionOptionList(
                                    labels,
                                    R.string.state,
                                    KEY_STATES
                                )
                            )
                        )
                    }
                }

                observeBackStackEntryDrop(KEY_STATES) { result ->
                    states.firstOrNull { it.name == result }?.let { state ->
                        viewModel.updateReportState(state)
                        inputView.editText?.setText(result)
                    }
                }
            }
        }
    }

    private fun updateStateValue(reportState: ReportState) {
        binding.stateView.root.editText?.setText(reportState.name)
    }

    private fun createReport() {
        observerCategoryChange()
        observerSignatureChange()
        binding.veilLayout.veil()
        observerPhotoType()
    }

    private fun addCategoryComponent(formField: FormField) {
        if (!binding.container.children.contains(categoryView)) {
            categoryView.removeFromParent()
            categoryView.tag = formField.key
            container.addViewWithTryCatch(categoryView, wrapContentHeightParams)
            formField.getCategoryId()?.let { viewModel.getExistCategory(it) }
        }
        viewModel.category.observe(viewLifecycleOwner) {
            if (categoryView.editText?.text.isNullOrEmpty() && it != null) {
                categoryView.editText?.setText(it.name)
            }
        }
    }

    private fun observerCategoryChange() {
        if (container.children.contains(categoryView)) {
            navigation.currentBackStackEntry?.savedStateHandle?.getLiveData<ExtendedCategory>(
                CATEGORY_KEY
            )?.observe(viewLifecycleOwner) {
                categoryView.editText?.setText(it.categoryData.name)
                viewModel.updateCategory(it)
            }
        }
    }

    private fun addShortTextBox(formField: FormField) {
        val shortBoxBinding = addOrGetEditBox(formField, viewShortBoxTextBinding)
        val input = getAndObserveInput(formField)
        shortBoxBinding.shortTextInput = input
    }

    private fun addLongTextBox(formField: FormField) {
        val longBoxBinding = addOrGetEditBox(formField, viewLongBoxTextBinding)
        val input = getAndObserveInput(formField)
        longBoxBinding.descriptionInput = input
    }

    private fun getAndObserveInput(formField: FormField): TextFieldInput {
        return viewModel.getInputField(formField, true).also {
            it.text.observe(viewLifecycleOwner) { value ->
                value?.let {
                    viewModel.updateCanEditReportByTextBox(formField.key, value)
                }
            }
        }
    }

    private fun <T : ViewDataBinding> addOrGetEditBox(formField: FormField, viewBinding: T): T =
        DataBindingUtil.findBinding(
            container.findViewWithTag(formField.key)
        ) ?: run {
            viewBinding.root.tag = formField.key
            container.addViewWithTryCatch(viewBinding.root, wrapContentHeightParams)
            viewBinding
        }

    private fun addRiskMatrix(matrixConfig: RiskMatrixConfig, riskAssessment: RiskAssessment?) {
        if (matrixConfig.riskLevels.isNotEmpty()) {
            val labels = matrixConfig.riskLevels.map { SelectionOptionData(it.label) }
            riskView.tag = KEY_RISK_LEVEL
            container.addViewWithTryCatch(riskView, wrapContentHeightParams)
            riskView.editText?.let { editText ->
                editText.setOnClickListener {
                    navigation.navigate(
                        CreateReportFragmentDirections.selectionOptionFragment(
                            SelectionOptionList(
                                labels,
                                R.string.field_type_risk_levels,
                                KEY_RISK_LEVEL
                            )
                        )
                    )
                }
            }

            riskAssessment?.let {
                it.riskLevel?.let { risk ->
                    riskView.editText?.setText(risk.label)
                }
            }
        }

        if (matrixConfig.severities.isNotEmpty()) {
            val labels = matrixConfig.severities.map { SelectionOptionData(it.label) }
            severityView.tag = KEY_SEVERITY
            container.addViewWithTryCatch(severityView, wrapContentHeightParams)
            severityView.editText?.let { editText ->
                editText.setOnClickListener {
                    navigation.navigate(
                        CreateReportFragmentDirections.selectionOptionFragment(
                            SelectionOptionList(
                                labels,
                                R.string.field_type_severity,
                                KEY_SEVERITY
                            )
                        )
                    )
                }
            }

            riskAssessment?.let {
                it.severity?.let { severity ->
                    severityView.editText?.setText(severity.label)
                }
            }
        }
        if (matrixConfig.likelihoods.isNotEmpty()) {
            val labels = matrixConfig.likelihoods.map { SelectionOptionData(it.label) }
            likelihoodView.tag = KEY_LIKELIHOODS
            container.addViewWithTryCatch(likelihoodView, wrapContentHeightParams)
            likelihoodView.editText?.let { editText ->

                editText.setOnClickListener {
                    navigation.navigate(
                        CreateReportFragmentDirections.selectionOptionFragment(
                            SelectionOptionList(
                                labels,
                                R.string.field_type_likelihood,
                                KEY_LIKELIHOODS
                            )
                        )
                    )
                }
            }

            riskAssessment?.let {
                it.likelihood?.let { likelihood ->
                    likelihoodView.editText?.setText(likelihood.label)
                }
            }
        }
    }

    private fun addDropdown(formField: FormField) {
        (formField.data as? DataValue.DataJsonObject)?.let { data ->
            val dropdownView = autoCompleteView.also { it.hint = formField.label }
            dropdownView.tag = formField.key
            val selectedValue = (formField.value as? FormValue.ValueString)?.value
            val options = viewModel.getDropdown(data.value).options
            val labels = options.map { SelectionOptionData(it.label) }
            container.addViewWithTryCatch(dropdownView, wrapContentHeightParams)

            dropdownView.editText?.let { editText ->
                editText.setOnClickListener {
                    navigation.navigate(
                        CreateReportFragmentDirections.selectionOptionFragment(
                            SelectionOptionList(
                                labels,
                                R.string.field_type_drop_down,
                                formField.key
                            )
                        )
                    )
                }
                selectedValue?.let { selectedValue ->
                    options.firstOrNull { it.value == selectedValue }?.let { option ->
                        editText.setText(option.label)
                    }
                }
            }

            observeBackStackEntryDrop(formField.key) { result ->
                val autoCompleteTextView = container.findViewWithTag<TextInputLayout>(formField.key)
                if (autoCompleteTextView != null) {
                    autoCompleteTextView.editText?.setText(result)
                    viewModel.updateDropdown(result, formField.key)
                }
            }
        }
    }

    private fun addCheckBoxes(formField: FormField) {
        (formField.data as? DataValue.DataJsonObject)?.let { data ->
            val key = formField.key
            val label = formField.label
            val optionHolder = viewModel.getCheckOptionHolder(formField, data.value)
            if (container.findViewWithTag<View>(key) == null) {
                val binding = viewLabelListBinding
                binding.root.tag = key
                container.addViewWithTryCatch(binding.root)
                binding.label.text = label
                val changeListener = object : ItemInterface {
                    override fun <T : Any> onItemSelected(item: T) {
                        (item as? Int)?.let { position ->
                            (binding.list.adapter as? CheckboxAdapter)?.let { adapter ->
                                optionHolder.options.getOrNull(position)?.let {
                                    viewModel.checkOption(key, it)
                                    adapter.updateSelectedItems(viewModel.getCheckedOption(key))
                                    adapter.notifyDataSetChanged()
                                }
                            }
                        }
                    }
                }
                val checkboxAdapter = CheckboxAdapter(
                    _context,
                    R.layout.item_check_box,
                    optionHolder.options,
                    changeListener
                )
                binding.list.adapter = checkboxAdapter
                checkboxAdapter.updateSelectedItems(viewModel.getCheckedOption(key))
                binding.list.expandHeight()
            }
        }
    }

    private fun addRadioButtons(formField: FormField) {
        (formField.data as? DataValue.DataJsonObject)?.let { data ->
            val key = formField.key
            val label = formField.label
            val optionHolder = viewModel.getRadioOptionHolder(formField, data.value)
            if (container.findViewWithTag<View>(key) == null) {
                val binding = viewLabelListBinding
                binding.root.tag = key
                container.addViewWithTryCatch(binding.root)
                binding.label.text = label
                val itemSelect: (option: Option) -> Unit = { option ->
                    viewModel.selectOption(key, option)
                    (binding.list.adapter as? RadioAdapter)?.let {
                        it.updateSelectedItem(option)
                        it.notifyDataSetChanged()
                    }
                }
                val radioAdapter = RadioAdapter(
                    _context,
                    R.layout.item_radio_button,
                    optionHolder.options,
                    itemSelect
                )
                viewModel.getRadioOption(key)?.let { radioAdapter.updateSelectedItem(it) }
                binding.list.adapter = radioAdapter
                binding.list.expandHeight()
            }
        }
    }

    private fun addBulletList(formField: FormField) {
        if (container.findViewWithTag<View>(formField.key) == null) {
            val binding = viewListWithAddBinding
            binding.root.tag = formField.key
            container.addViewWithTryCatch(binding.root)
            binding.label.text = formField.label
            viewModel.addExistBulletItems(formField)
            val adapter = DynamicAdapter(object : UpdateItem {
                override fun onUpdateItem(item: DynamicItem) {
                    (item as? DynamicItem.BulletItem)?.let {
                        (binding.recyclerView.adapter as? DynamicAdapter)?.updateItems(
                            viewModel.updateBulletItem(formField.key, it)
                        )
                    }
                }
            })
            binding.addButton.setOnClickListener {
                adapter.updateItems(viewModel.addBulletItem(formField.key))
            }

            adapter.updateItems(viewModel.getBulletItems(formField.key))
            adapter.updateInterface(object : ItemInterface {
                override fun <T : Any> onItemSelected(item: T) {
                    (item as? DynamicItem.BulletItem)?.let {
                        adapter.updateItems(viewModel.deleteBulletItem(formField.key, it))
                    }
                }
            })
            binding.recyclerView.adapter = adapter
        }
    }

    private fun addNumberList(formField: FormField) {
        if (container.findViewWithTag<View>(formField.key) == null) {
            val binding = viewListWithAddBinding
            binding.root.tag = formField.key
            val adapter = DynamicAdapter(object : UpdateItem {
                override fun onUpdateItem(item: DynamicItem) {
                    (item as? DynamicItem.NumberItem)?.let {
                        val list = viewModel.updateNumberItem(formField.key, it)
                        (binding.recyclerView.adapter as? DynamicAdapter)?.updateItems(list)
                    }
                }
            })
            container.addViewWithTryCatch(binding.root)
            binding.label.text = formField.label
            viewModel.addExistNumberItems(formField)
            binding.addButton.setOnClickListener {
                val list = viewModel.addNumberItem(formField.key)
                adapter.updateItems(list)
            }

            adapter.updateItems(viewModel.getNumberItems(formField.key))
            adapter.updateInterface(object : ItemInterface {
                override fun <T : Any> onItemSelected(item: T) {
                    (item as? DynamicItem.NumberItem)?.let {
                        val list = viewModel.deleteNumberItem(formField.key, it)
                        adapter.updateItems(list)
                    }
                }
            })
            binding.recyclerView.adapter = adapter
        }
    }

    private fun addDateTime(formField: FormField) {
        if (container.findViewWithTag<View>(formField.key) == null) {
            val binding = viewDateTimeBinding
            binding.root.tag = formField.key
            container.addViewWithTryCatch(binding.root)
            viewModel.emitDefaultDateTime(formField)
            binding.dateTextField.setOnClickListener {
                dateDialog.show()
            }
            viewModel.dateInString.observe(viewLifecycleOwner) {
                binding.dateTextField.setText(it)
            }
            binding.timeTextField.setOnClickListener {
                timeDialog.show()
            }
            viewModel.timeInString.observe(viewLifecycleOwner) {
                binding.timeTextField.setText(it)
            }
        }
    }

    private fun addSlider(sliderData: SliderData, formValue: FormValue? = null, key: String) {
        if (container.findViewWithTag<View>(key) == null) {
            viewSliderBinding.root.tag = key
            container.addViewWithTryCatch(viewSliderBinding.root)
            viewSliderBinding.sliderStep.tickMarkTextArray =
                (sliderData.minimum..sliderData.maximum).map { it.toString() }.toTypedArray()
            viewSliderBinding.sliderStep.steps = (sliderData.maximum - sliderData.minimum)
            viewSliderBinding.sliderStep.setRange(
                sliderData.minimum.toFloat(),
                sliderData.maximum.toFloat()
            )
            val value = (formValue as? FormValue.ValueInt)?.value?.toFloat()
            if (value == null) {
                viewSliderBinding.sliderStep.setProgress(sliderData.default.toFloat())
            } else {
                viewSliderBinding.sliderStep.setProgress(value)
            }
            viewSliderBinding.sliderStep.setOnRangeChangedListener(object : OnRangeChangedListener {
                override fun onRangeChanged(
                    view: RangeSeekBar?,
                    leftValue: Float,
                    rightValue: Float,
                    isFromUser: Boolean
                ) {
                    viewModel.updateRangeValue(leftValue.toInt())
                }

                override fun onStartTrackingTouch(view: RangeSeekBar?, isLeft: Boolean) {
                    // Do nothing
                }

                override fun onStopTrackingTouch(view: RangeSeekBar?, isLeft: Boolean) {
                    // Do nothing
                }
            })
        }
    }

    private fun addSignature(uuid: String, formField: FormField) {
        viewSignatureBinding.root.tag = formField.key
        container.addViewWithTryCatch(viewSignatureBinding.root)
        (formField.value as? FormValue.ValueFormFieldImage)?.let { value ->
            if (viewModel.signature.value == null) {
                val image = value.images.last()
                val signature = Signature(
                    reportUuid = uuid,
                    formFieldId = formField.id,
                    formFieldSignature = FormFieldSignature(
                        fileAttachmentId = image.id,
                        fileName = image.filename,
                        url = image.originalUrl,
                        signeeName = ""
                    )
                )
                viewModel.updateSignature(signature, false)
            }
        }
        viewModel.signature.observe(viewLifecycleOwner) {
            if (it != viewSignatureBinding.signature) {
                viewSignatureBinding.signature = it
                viewModel.updateCanEditReportBySignature(true)
            }
        }
        viewSignatureBinding.addSignatureButton.setOnClickListener {
            val signature = viewModel.signature.value ?: viewModel.report.value?.uuid?.let {
                Signature(it, formFieldId = formField.id)
            }
            if (signature != null) {
                navigation.navigate(CreateReportFragmentDirections.openSignatureView(signature))
            }
        }
    }

    private fun addFreeTextField(formField: FormField) {
        if (container.findViewWithTag<View>(formField.key) == null) {
            binding.root.tag = formField.key
            container.addViewWithTryCatch(viewWebViewContainerBinding.root)
            formField.label?.let {
                viewWebViewContainerBinding.webView.loadData(it)
                viewWebViewContainerBinding.webView.setTheme()
            }
        }
    }

    private fun addPhoto(reportUuid: String, formField: FormField) {
        viewPhotoBinding.root.tag = formField.key
        container.addViewWithTryCatch(viewPhotoBinding.root)
        if (!gridSpacingItemDecoration.isUsed) {
            formField.getPhotos(reportUuid)?.let { photos ->
                viewModel.addExistPhoto(photos.map { item -> item.copy(isDeletable = true) })
            }
            viewPhotoBinding.photoRecycleView.adapter = photoAdapter
            viewPhotoBinding.photoRecycleView.addItemDecoration(gridSpacingItemDecoration).also {
                gridSpacingItemDecoration.setUsed()
            }
            viewModel.photos.observe(viewLifecycleOwner) {
                photoAdapter.updateItems(it)
            }
        }
    }

    private fun observerPhotoType() {
        val lifecycle = navBackStackEntry?.lifecycle
        lifecycle?.removeObserver(photoObserver)
        lifecycle?.addObserver(photoObserver)

        viewLifecycleOwner.lifecycle.addObserver(LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_DESTROY) {
                navBackStackEntry?.lifecycle?.removeObserver(photoObserver)
            }
        })
    }

    private fun removePhotoTypeInStackEntry() {
        navBackStackEntry?.savedStateHandle?.remove<PhotoType>(
            SelectPhotoBottomModal.PHOTO_TYPE
        )
    }

    private fun getPhoto() {
        if (viewModel.photoType == PhotoType.CAMERA && checkAndRequestPermissions(listOf(Manifest.permission.CAMERA))) {
            takePhoto()
        } else if (viewModel.photoType == PhotoType.LIBRARY && checkAndRequestPermissions(
                listOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE
                )
            )
        ) {
            selectPhoto()
        }
        removePhotoTypeInStackEntry()
    }

    private fun takePhoto() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            viewModel.createCapturePhotoUri()?.let { photoUri ->
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
                resultCaptureImageLauncher.launch(takePictureIntent)
            }
        }
        viewModel.updatePhotoType(null)
    }

    private fun selectPhoto() {
        val intent = Intent(
            Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )
        resultSelectPhotoLauncher.launch(intent)
        viewModel.updatePhotoType(null)
    }

    private fun ViewGroup.addViewWithTryCatch(
        view: View,
        params: ViewGroup.LayoutParams = wrapContentHeightParams
    ) {
        children.firstOrNull { it.tag == view.tag }.let {
            if (it == null || indexOfChild(it) < 0) {
                try {
                    addView(view, params)
                    if (this == container) {
                        view.marginTop()
                    }
                } catch (exception: Exception) {
                    exception.printStackTrace()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (viewModel.photoType != null) {
            getPhoto()
        }
        actionController?.showToolBar()
    }

    private fun observerSignatureChange() {
        if (container.children.contains(viewSignatureBinding.root)) {
            navigation.currentBackStackEntry?.savedStateHandle?.getLiveData<Signature>(
                SIGNATURE_KEY
            )?.observe(viewLifecycleOwner) {
                viewModel.updateSignature(signature = it)
            }
        }
    }

    private fun ListView.expandHeight() {
        var totalHeight = 0

        for (i in 0 until adapter.count) {
            val mView: View = adapter.getView(i, null, this)
            mView.measure(
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            )
            totalHeight += mView.measuredHeight
        }

        val params: ViewGroup.LayoutParams = layoutParams
        params.height = (totalHeight + dividerHeight * (adapter.count - 1))
        layoutParams = params
        requestLayout()
    }

    companion object {
        private const val NUMBER_OF_COLUMN = 3
        private const val REPORT_DATA_KEY = "reportData"
        private const val KEY_STATES = "state"
        private const val KEY_RISK_LEVEL = "risk level"
        private const val KEY_LIKELIHOODS = "likelihoods"
        private const val KEY_SEVERITY = "severity"
    }
}
