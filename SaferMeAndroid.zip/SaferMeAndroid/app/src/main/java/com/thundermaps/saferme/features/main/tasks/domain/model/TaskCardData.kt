package com.thundermaps.saferme.features.main.tasks.domain.model

import android.content.Context
import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.saferme.obsidian.Provider
import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianTask
import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.domain.models.DiffItem
import com.thundermaps.saferme.core.domain.models.TaskCardType
import com.thundermaps.saferme.core.ui.extensions.getDueDateTime
import com.thundermaps.saferme.core.util.TimeUtil
import com.thundermaps.saferme.core.util.TimeUtil.toMediumDateInString
import com.thundermaps.saferme.core.util.TimeUtil.toShortTimeInString
import java.util.Date
import kotlinx.parcelize.Parcelize

@ExcludeFromJacocoGeneratedReport
@Parcelize
data class TaskCardData(
    @Expose val id: String,
    @Expose val title: String? = null,
    @Expose val description: String? = null,
    @Expose val assignee: Int? = null,
    @Expose val assigneeName: String? = null,
    @Expose val creatorName: String? = null,
    @Expose val creatorId: Int? = null,
    @Expose val reportId: String? = null,
    @Expose val createdDate: Date? = null,
    @Expose val completedDate: Date? = null,
    @Expose val reportTitle: String? = null,
    @Expose val type: TaskCardType,
    @Expose val assignmentDueDate: Date? = null
) : Parcelable, DiffItem {

    override val uniqueId: Any get() = id
    val createdDateMediumString get() = createdDate?.toMediumDateInString()
    val completedDateMediumString get() = completedDate?.toMediumDateInString()
    val createdTimeShortString get() = createdDate?.toShortTimeInString()?.lowercase()

    fun getDueDateInString(context: Context): String? {
        return assignmentDueDate?.let {
            context.getDueDateTime(it.time)
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        (other as? TaskCardData)?.let {
            if (id != other.id) return false
        }
        return true
    }

    @ExcludeFromJacocoGeneratedReport
    fun toJson(): String {
        return Provider.gson.toJson(this)
    }

    @ExcludeFromJacocoGeneratedReport
    fun toObsidianTask(modifiedDate: String? = null) =
        TaskCardData.toObsidian(this).copy(modified_date = modifiedDate)

    companion object {
        @ExcludeFromJacocoGeneratedReport
        fun of(task: ObsidianTask, assigneeName: String?, creatorName: String?): TaskCardData {

            val createdDate =
                task.client_created_at?.let { TimeUtil.convertIsoDateStringToDateWithMS(it) }
            val completedDate =
                task.completed_at?.let { TimeUtil.convertIsoDateStringToDateWithMS(it) }
            return TaskCardData(
                task.uuid,
                task.title,
                task.description,
                task.assignee_id,
                assigneeName,
                creatorName,
                task.creator_id,
                task.report_uuid,
                createdDate,
                completedDate,
                null,
                TaskCardType.TASK,
                null
            )
        }

        @ExcludeFromJacocoGeneratedReport
        fun of(report: ObsidianReport): TaskCardData {
            val createdDate =
                report.isoCreatedAt?.let { TimeUtil.convertIsoDateStringToDate(it) }
            val assignmentDueDate =
                report.assignmentDueAt?.let { TimeUtil.convertIsoDateStringToDate(it) }
            return TaskCardData(
                report.uuid,
                report.title,
                report.description,
                Integer.valueOf(report.assigneeId!!) ?: 0,
                null,
                null,
                report.userId,
                report.uuid,
                createdDate,
                null,
                report.title,
                TaskCardType.REPORT,
                assignmentDueDate
            )
        }

        @ExcludeFromJacocoGeneratedReport
        fun toObsidian(task: TaskCardData): ObsidianTask {
            val createdDate = task.createdDate?.let { TimeUtil.convertIsoDateToString(it) }
            val completedDate = task.completedDate?.let { TimeUtil.convertIsoDateToString(it) }

            return ObsidianTask(
                uuid = task.id,
                task.assignee,
                createdDate,
                completedDate,
                task.creatorId,
                task.description,
                task.reportId,
                task.title,
                etag = null,
                true,
                requested_action = null,
                modified_date = null,
                retry_count = 0
            )
        }

        @ExcludeFromJacocoGeneratedReport
        fun of(json: String): TaskCardData = Provider.gson.fromJson(json, TaskCardData::class.java)
    }
}
