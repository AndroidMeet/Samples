package com.thundermaps.saferme.features.authentication

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.ActionBarInterface
import com.thundermaps.saferme.databinding.ActivityLoginBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AuthenticationActivity : AppCompatActivity(), ActionBarInterface, UserDetailsListener {
    private lateinit var binding: ActivityLoginBinding

    private val navHostFragment by lazy { supportFragmentManager.findFragmentById(R.id.login_fragment_container) as NavHostFragment }
    private val navController get() = navHostFragment.navController
    private val viewModel: AuthenticationViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val appBarConfiguration = AppBarConfiguration(navController.graph)
        binding.toolBar.setupWithNavController(navController, appBarConfiguration)
    }

    override fun hideToolBar() {
        binding.toolBar.visibility = View.GONE
    }

    override fun showToolBar() {
        binding.toolBar.visibility = View.VISIBLE
    }

    override fun showNavigationIcon() {
        binding.toolBar.setNavigationIcon(R.drawable.ic_baseline_arrow_back_24)
    }

    override fun hideNavigationIcon() {
        binding.toolBar.navigationIcon = null
    }

    override fun getUserDetails() {
        viewModel.getUserDetails()
    }
}
