package com.thundermaps.saferme.core.ui.input

import java.util.regex.Pattern

@Suppress("RegExpRedundantEscape", "RegExpDuplicateCharacterInClass")
private const val EMAIL_PATTERN = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
        "\\@" +
        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
        "(" +
        "\\." +
        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
        ")+"

private const val PHONE_PATTERN = "^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*\$"

fun TextFieldInput.isEmptyOrNull(errorString: String?): Boolean {
    val value: String? = text.value
    return if (value == null || value.isNullOrEmpty() || value.isBlank()) {
        showError(errorString)
        true
    } else {
        clearError()
        false
    }
}

fun TextFieldInput.verifyEmail(
    errorString: String?,
    emailError: String?
): Boolean = isEmptyOrNull(errorString).run {
    if (this) {
        this
    } else {
        verifyError(emailError, EMAIL_PATTERN)
    }
}

fun TextFieldInput.verifyPhone(
    errorString: String?,
    phoneError: String?
): Boolean = isEmptyOrNull(errorString).run {
    if (this) {
        this
    } else {
        verifyError(phoneError, PHONE_PATTERN)
    }
}

private fun TextFieldInput.verifyError(
    error: String?,
    patternString: String
): Boolean {
    val text = text.value ?: return false
    val pattern = Pattern.compile(patternString)
    val matcher = pattern.matcher(text)
    return if (!matcher.matches()) {
        showError(error)
        true
    } else {
        false
    }
}
