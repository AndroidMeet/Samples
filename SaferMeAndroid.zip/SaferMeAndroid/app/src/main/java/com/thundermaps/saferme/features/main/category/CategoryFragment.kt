package com.thundermaps.saferme.features.main.category

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentCategoryBinding
import com.thundermaps.saferme.features.main.category.model.CategoryData
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class CategoryFragment : BaseFragment<FragmentCategoryBinding, CategoryViewModel>(), ItemInterface {
    private val args: CategoryFragmentArgs by navArgs()

    @Inject
    lateinit var adapter: CategoryAdapter
    override val viewModel: CategoryViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_category

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.updateChannelId(args.channelId)
        viewModel.getSavedCategories().observe(viewLifecycleOwner) {
            viewModel.updateCategoryData(it)
        }

        configAdapter()
        binding.swipeRefresh.setOnRefreshListener {
            refresh()
        }
    }

    private fun refresh() {
        viewModel.syncCategory()
        binding.categoryRecyclerview.veil()
    }

    private fun configAdapter() {
        adapter.updateInterface(this)
        DividerItemDecoration(requireContext(), LinearLayoutManager.VERTICAL).run {
            binding.categoryRecyclerview.getRecyclerView().addItemDecoration(this)
        }
        binding.categoryRecyclerview.addVeiledItems(NUMBER_SHIMMER_ITEMS)
        binding.categoryRecyclerview.setLayoutManager(LinearLayoutManager(requireContext()))
        viewModel.categories.observe(viewLifecycleOwner) {
            binding.swipeRefresh.isRefreshing = false
            if (it == null) {
                binding.categoryRecyclerview.veil()
            } else {
                binding.categoryRecyclerview.unVeil()
                if (it.isEmpty() && viewModel.numberOfSync == 0) {
                    refresh()
                }
                adapter.updateItems(it)
            }
        }
        binding.categoryRecyclerview.setAdapter(adapter)
    }

    override fun <T : Any> onItemSelected(item: T) {
        (item as? CategoryData)?.let {
            if (viewModel.hasNoChildren(it.id)) {
                val navigation = findNavController()
                val extendedCategory = viewModel.getExtendedCategoryData(it)
                navigation.previousBackStackEntry?.savedStateHandle?.set(CATEGORY_KEY, extendedCategory)
                navigation.popBackStack()
            } else {
                viewModel.onItemSelect(it)
            }
        }
    }

    companion object {
        private const val NUMBER_SHIMMER_ITEMS = 5
        const val CATEGORY_KEY = "category_key"
    }
}
