package com.thundermaps.saferme.features.authentication.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.thundermaps.apilib.android.api.requests.models.SessionBody
import com.thundermaps.apilib.android.api.requests.models.User
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.data.exceptions.SaferMeException
import com.thundermaps.saferme.core.domain.models.isAccountLocked
import com.thundermaps.saferme.core.ui.Screen
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import com.thundermaps.saferme.core.ui.input.isEmptyOrNull
import com.thundermaps.saferme.core.ui.input.verifyEmail
import com.thundermaps.saferme.core.ui.nextScreen
import com.thundermaps.saferme.features.authentication.login.domain.LoginRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val app: Application,
    private val loginRepository: LoginRepository,
    private val dispatcherContext: DispatcherContext
) : AndroidViewModel(app) {
    private val readyLogin = MediatorLiveData<Boolean>()
    val isReadyForLogin: LiveData<Boolean> get() = readyLogin
    private val _loginState = MutableLiveData<Result<Sessions>>(Result.Initial)
    val loginResult: LiveData<Result<Sessions>> = _loginState
    val isStaging: LiveData<Boolean> = loginRepository.isStaging

    private val cacheSessions = liveData {
        emit(loginRepository.getCacheSessions())
    }

    private val _nextScreen = MediatorLiveData<Screen?>()

    val nextScreen: LiveData<Screen?> = _nextScreen

    val userInput = TextFieldInput(app.getString(R.string.login_email))
    val passwordInput = TextFieldInput(app.getString(R.string.login_password))
    private val emailEmptyError by lazy { app.getString(R.string.login_email_empty_error) }
    private val emailInvalid by lazy { app.getString(R.string.login_email_invalid) }
    private val passwordEmptyError by lazy { app.getString(R.string.login_password_empty_error) }
    private val passwordTooShort by lazy { app.getString(R.string.login_password_too_short) }
    private val emailOrPasswordIncorrect by lazy { app.getString(R.string.login_email_or_password_incorrect) }
    private val _isAccountLocked = MutableLiveData<Boolean>()
    val isAccountLocked: LiveData<Boolean> = _isAccountLocked

    private val _isEditingEmail = MutableLiveData(false)
    val isEditingEmail: LiveData<Boolean> = _isEditingEmail
    private val _isEditingPassword = MutableLiveData(false)
    val isEditingPassword: LiveData<Boolean> = _isEditingPassword

    init {
        readyLogin.value = false
        validateReadyLogin()
        _nextScreen.addSource(cacheSessions) {
            _nextScreen.postValue(it?.nextScreen())
        }

        _nextScreen.addSource(loginResult) { result ->
            if (!result.isLoading && cacheSessions.value == null) {
                _nextScreen.postValue(
                    if (result.isSuccess) {
                        result.getNullableData()?.nextScreen()
                    } else {
                        if (result is Result.Error) {
                            val exception = result.exception
                            if (exception is SaferMeException && exception.responseError?.isAccountLocked() == true) {
                                userInput.text.value?.let { checkEmailIfLocked(it, true) }
                            } else {
                                userInput.showError(emailOrPasswordIncorrect)
                                passwordInput.showError(emailOrPasswordIncorrect)
                            }
                        }
                        null
                    }
                )
            }
        }
        viewModelScope.launch(dispatcherContext.io) {
            loginRepository.syncBrand()
        }
    }

    private fun validateReadyLogin() {
        fun updateValue() {
            readyLogin.postValue(!userInput.isError && !userInput.text.value.isNullOrEmpty() && !passwordInput.isError && !passwordInput.text.value.isNullOrEmpty() && isAccountLocked.value != true)
        }
        readyLogin.addSource(userInput.text) {
            checkEmail()
            updateValue()
        }

        readyLogin.addSource(passwordInput.text) {
            checkPassword()
            updateValue()
        }

        readyLogin.addSource(_isAccountLocked) {
            updateValue()
        }
    }

    fun checkEmail() = userInput.verifyEmail(emailEmptyError, emailInvalid).also { isValidEmail ->
        if (isValidEmail) {
            userInput.text.value?.let { email -> checkEmailIfLocked(email) }
        }
    }

    fun checkPassword() = passwordInput.isEmptyOrNull(passwordEmptyError).run {
        if (this) {
            this
        } else {
            val password = passwordInput.text.value
            if (password != null && password.length < PASSWORD_LENGTH) {
                passwordInput.showError(passwordTooShort)
                true
            } else {
                passwordInput.clearError()
                false
            }
        }
    }.also { isValid ->
        if (isValid) {
            userInput.text.value?.let {
                checkEmailIfLocked(it)
            }
        }
    }

    fun login() {
        val email = userInput.text.value ?: return
        val password = passwordInput.text.value ?: return
        updateEditingPassword(false)
        updateEditingEmail(false)
        _loginState.value = Result.Loading(null)
        viewModelScope.launch(dispatcherContext.io) {
            val result = loginRepository.login(SessionBody(User(email, password)))
            _loginState.postValue(result)
        }
    }

    private fun checkEmailIfLocked(email: String, fromServer: Boolean = false) {
        viewModelScope.launch(dispatcherContext.io) {
            val isLocked = loginRepository.isAccountLocked(email)
            withContext(dispatcherContext.main) {
                if (isLocked && fromServer) {
                    userInput.showError(" ")
                    passwordInput.showError(" ")
                }
                _isAccountLocked.value = isLocked
            }
        }
    }

    fun updateEditingEmail(value: Boolean) {
        _isEditingEmail.value = value
    }

    fun updateEditingPassword(value: Boolean) {
        _isEditingPassword.value = value
    }

    fun selectStaging() {
        loginRepository.useStagingEnv()
        viewModelScope.launch(dispatcherContext.io) {
            loginRepository.syncBrand()
        }
    }

    fun selectLive() {
        loginRepository.useLiveEnv()
        viewModelScope.launch(dispatcherContext.io) {
            loginRepository.syncBrand()
        }
    }

    companion object {
        private const val PASSWORD_LENGTH = 8
    }
}
