package com.thundermaps.saferme.core.ui.extensions

import com.thundermaps.apilib.android.api.responses.models.FieldType
import com.thundermaps.apilib.android.api.responses.models.FormField
import com.thundermaps.apilib.android.api.responses.models.FormValue
import com.thundermaps.saferme.core.domain.models.PhotoItem

fun FormField?.getPhotos(reportUuid: String): List<PhotoItem>? =
    (this?.value as? FormValue.ValueFormFieldImage)?.images?.map {
        PhotoItem(attachmentId = it.id, url = it.originalUrl, reportUuid = reportUuid)
    }

fun FormField?.getCategoryId(): Int? = if (this?.fieldType == FieldType.Category) {
    (value as? FormValue.ValueInt)?.value
} else {
    null
}
