package com.thundermaps.saferme.core.domain.utils

import androidx.recyclerview.widget.DiffUtil
import com.thundermaps.domain.models.DiffItem

class GenericDiff(
    private val oldItems: List<DiffItem>,
    private val newItems: List<DiffItem>
) : DiffUtil.Callback() {
    override fun getOldListSize(): Int = oldItems.size

    override fun getNewListSize(): Int = newItems.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldItems[oldItemPosition].uniqueId == newItems[newItemPosition].uniqueId
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldItems[oldItemPosition] == newItems[newItemPosition]
    }
}
