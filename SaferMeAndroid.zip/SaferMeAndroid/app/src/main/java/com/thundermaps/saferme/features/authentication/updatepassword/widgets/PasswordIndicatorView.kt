package com.thundermaps.saferme.features.authentication.updatepassword.widgets

import android.animation.ArgbEvaluator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Resources
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.core.content.ContextCompat
import com.thundermaps.saferme.R
import com.thundermaps.saferme.features.authentication.updatepassword.domain.PasswordStrengthLevel

class PasswordIndicatorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defaultStyle: Int = 0
) : View(context, attrs, defaultStyle) {
    private var currentLineWidth = 0
    private var correctLineWidth = 0
    private var currentColor = 0
    private var correctColor = 0
    private val linePaint by lazy { Paint() }
    private val backgroundPaint by lazy {
        Paint().apply {
            strokeWidth = 8f.dpToPx()
            color = ContextCompat.getColor(context, R.color.password_indicator_background)
        }
    }
    private var securityLevel = PasswordStrengthLevel.ofLevel(0)

    private var animate = true
    private var animDuration = 300

    init {
        currentColor = ContextCompat.getColor(context, R.color.password_indicator_background)
    }

    @Suppress("unused")
    fun setAnimDuration(animDuration: Int) {
        this.animDuration = animDuration
    }

    fun setAnimate(animate: Boolean) {
        this.animate = animate
    }

    private fun refresh() {
        val duration = if (animate) animDuration else 0
        val colorProp = PropertyValuesHolder.ofInt("color", currentColor, correctColor)
        val widthProperty = PropertyValuesHolder.ofInt("width", currentLineWidth, correctLineWidth)
        val colorAnim = ValueAnimator()
        colorAnim.duration = duration.toLong()
        colorAnim.setValues(colorProp, widthProperty)
        colorAnim.setEvaluator(ArgbEvaluator())
        colorAnim.interpolator = AccelerateDecelerateInterpolator()
        colorAnim.addUpdateListener { animation ->
            currentColor = animation.getAnimatedValue("color") as Int
            currentLineWidth = animation.getAnimatedValue("width") as Int
            invalidate()
        }
        colorAnim.start()
    }

    fun setSecurityLevel(level: PasswordStrengthLevel, force: Boolean) {
        if (force || securityLevel != level) {
            securityLevel = level
            correctLineWidth = (width * level.percentageWidth).toInt()
            correctColor =
                level.colorRes?.let { ContextCompat.getColor(context, it) } ?: currentColor
            refresh()
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        linePaint.strokeWidth = 8f.dpToPx()
        linePaint.color = currentColor
        canvas.drawLine(
            0f,
            (height / 2).toFloat(),
            width.toFloat(),
            (height / 2).toFloat(),
            backgroundPaint
        )
        canvas.drawLine(
            0f,
            (height / 2).toFloat(),
            currentLineWidth.toFloat(),
            (height / 2).toFloat(),
            linePaint
        )
    }

    private fun Float.dpToPx(): Float = this * Resources.getSystem().displayMetrics.density
}
