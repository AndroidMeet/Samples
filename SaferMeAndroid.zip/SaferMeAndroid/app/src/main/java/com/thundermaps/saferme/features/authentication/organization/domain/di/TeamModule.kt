package com.thundermaps.saferme.features.authentication.organization.domain.di

import com.thundermaps.saferme.core.data.repo.TeamRepository
import com.thundermaps.saferme.core.data.repo.TeamRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
abstract class TeamModule {
    @Suppress("unused")
    @Binds
    abstract fun bindTeamRepository(
        teamRepository: TeamRepositoryImpl
    ): TeamRepository
}
