package com.thundermaps.saferme.core.ui.extensions

import com.google.gson.JsonObject
import com.mapbox.geojson.Feature
import com.saferme.obsidian.store.resources.ObsidianReport
import com.thundermaps.saferme.core.util.toPoint

fun ObsidianReport.toFeature(updatedAppearance: String): Feature = Feature.fromGeometry(
    location?.toPoint(),
    JsonObject().apply {
        addProperty("appearance", updatedAppearance)
        addProperty("title", title)
        addProperty("address", address)
    },
    uuid
)
