package com.thundermaps.saferme.core.util

import com.google.gson.JsonObject
import com.mapbox.geojson.Point

private const val LATITUDE_KEY = "latitude"
private const val LONGITUDE_KEY = "longitude"

fun Point?.toLocationJsonObject(): JsonObject? = this?.let {
    JsonObject().apply {
        addProperty(LATITUDE_KEY, latitude())
        addProperty(LONGITUDE_KEY, longitude())
    }
}

fun JsonObject?.toPoint(): Point? {
    val latitude = this?.getAsJsonPrimitive(LATITUDE_KEY)?.asDouble ?: return null
    val longitude = getAsJsonPrimitive(LONGITUDE_KEY)?.asDouble ?: return null

    return Point.fromLngLat(longitude, latitude)
}
