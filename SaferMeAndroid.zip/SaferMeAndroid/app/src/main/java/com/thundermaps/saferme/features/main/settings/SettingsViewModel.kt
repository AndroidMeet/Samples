package com.thundermaps.saferme.features.main.settings

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.requests.models.UpdateEmailNotificationEnableBody
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.features.authentication.AuthenticationRepository
import com.thundermaps.saferme.features.main.settings.domain.DeviceDetails
import com.thundermaps.saferme.features.main.settings.domain.DeviceDetailsRepository
import com.thundermaps.saferme.features.main.settings.models.SettingsItemData
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class SettingsViewModel @Inject constructor(
    val app: SaferMeApplication,
    private val authorizedRepo: AuthenticationRepository,
    private val deviceDetailsRepository: DeviceDetailsRepository,
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {

    private val _deviceDetails = MutableLiveData<DeviceDetails>()
    val deviceDetails: LiveData<DeviceDetails?> = _deviceDetails

    private val _logoutOperation = MutableLiveData<Result<Unit>>(Result.Initial)
    val logoutOperation: LiveData<Unit> = Transformations.map(_logoutOperation) {}

    private val _deviceInfoVisibility = MutableStateFlow(false)
    val deviceInfoVisibility: StateFlow<Boolean> = _deviceInfoVisibility

    private val _emailNotificationChecked = MutableStateFlow(false)
    val emailNotificationChecked: StateFlow<Boolean> = _emailNotificationChecked

    private var clickCount: Int = 0

    val settingsList: List<SettingsItemData> = listOf(
        SettingsItemData(app.getString(R.string.location), R.drawable.ic_location_settings),
        SettingsItemData(app.getString(R.string.bluetooth), R.drawable.ic_bluetooth),
        SettingsItemData(
            app.getString(R.string.push_notification),
            R.drawable.ic_notification_bell
        ),
        SettingsItemData(app.getString(R.string.password), R.drawable.ic_password_key),
        SettingsItemData(app.getString(R.string.map_setting), R.drawable.ic_map_settings),
        SettingsItemData(app.getString(R.string.logout), R.drawable.ic_logout)
    )

    init {
        viewModelScope.launch(dispatcherContext.io) {
            authorizedRepo.getUserDetails()
            obsidianApi.provideSessionsManager().userDetails?.let { userDetails ->
                userDetails.emailNotificationEnabled?.let {
                    _emailNotificationChecked.value = it
                }
            }
        }
    }

    fun loadDeviceDetails() {
        _deviceDetails.postValue(deviceDetailsRepository.getDeviceDetails())
    }

    fun showDeviceDetails() {
        clickCount++
        if (clickCount == MAX_COUNT)
            _deviceInfoVisibility.value = true
    }

    fun onEmailNotificationClicked() {
        onUpdateNotificationChanged(!emailNotificationChecked.value)
    }

    fun onUpdateNotificationChanged(enabled: Boolean) {
        _emailNotificationChecked.value = enabled
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.provideSessionsManager().getSessions()?.let {
                obsidianApi.meManager.updateEmailNotificationEnables(
                    it.userId.toString(),
                    UpdateEmailNotificationEnableBody(enabled)
                )
                authorizedRepo.getUserDetails()
            }
        }
    }

    fun logout() {
        _logoutOperation.value = Result.Loading(null)
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.logout()
            _logoutOperation.postValue(Result.Success(Unit))
        }
    }

    companion object {
        const val MAX_COUNT = 5
    }
}
