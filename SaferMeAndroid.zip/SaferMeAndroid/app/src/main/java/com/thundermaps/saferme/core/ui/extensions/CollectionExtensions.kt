package com.thundermaps.saferme.core.ui.extensions

fun <E> MutableList<E>.replace(old: E, new: E) {
    if (contains(old)) {
        val index = indexOf(old)
        remove(old)
        add(index, new)
    }
}
