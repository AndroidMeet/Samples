package com.thundermaps.saferme.features.main.profile.domain

import androidx.annotation.VisibleForTesting
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.responses.models.Result
import javax.inject.Inject
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

interface ProfileRepository {
    suspend fun getProfile(): Result<Profile>
}

class ProfileRepositoryImpl @Inject constructor(
    private val obsidianApi: ObsidianApi
) : ProfileRepository {
    override suspend fun getProfile(): Result<Profile> = coroutineScope {
        val sessionsManager = obsidianApi.provideSessionsManager()
        val teamManager = obsidianApi.teamManager
        teamManager.syncTeam()
        val sessionsDeferred = async { sessionsManager.getSessions() }
        val teamsDeferred = async { teamManager.getTeamsSync() }
        val userDetails = sessionsManager.userDetails
        val sessions = sessionsDeferred.await()
        val teams = teamsDeferred.await()
        if (sessions?.teamId != null && userDetails != null && !teams.isNullOrEmpty()) {
            Result.Success(
                Profile(
                    "${userDetails.firstName} ${userDetails.lastName}",
                    teams.firstOrNull { it.id == sessions.teamId }?.name ?: "",
                    userDetails.avatar
                )
            )
        } else {
            Result.Error(null, Exception(INVALIDATE_DATA_MESSAGE))
        }
    }

    companion object {
        @VisibleForTesting
        const val INVALIDATE_DATA_MESSAGE = "Invalidate data"
    }
}
