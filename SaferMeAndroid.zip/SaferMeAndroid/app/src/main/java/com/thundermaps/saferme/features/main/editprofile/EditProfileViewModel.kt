package com.thundermaps.saferme.features.main.editprofile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.requests.models.UpdateProfileBody
import com.thundermaps.apilib.android.api.requests.models.UserBody
import com.thundermaps.apilib.android.api.responses.models.UserDetails
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.DispatcherContext
import com.thundermaps.saferme.core.ui.input.TextFieldInput
import com.thundermaps.saferme.core.ui.input.verifyEmail
import com.thundermaps.saferme.core.ui.input.verifyPhone
import com.thundermaps.saferme.features.authentication.AuthenticationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class EditProfileViewModel @Inject constructor(
    val app: SaferMeApplication,
    private val authorizedRepo: AuthenticationRepository,
    private val obsidianApi: ObsidianApi,
    private val dispatcherContext: DispatcherContext
) : ViewModel() {
    val firstNameInput = TextFieldInput(app.getString(R.string.hint_first_name))
    val lastNameInput = TextFieldInput(app.getString(R.string.hint_last_name))
    val emailInput = TextFieldInput(app.getString(R.string.hint_email))
    val contactNumberInput = TextFieldInput(app.getString(R.string.hint_contact_number))

    private val _canUpdateProfile = MediatorLiveData<Boolean>()
    val canUpdateProfile: LiveData<Boolean> = _canUpdateProfile

    private val _saveUserProfile = MutableLiveData<Boolean>()
    val saveUserProfile: LiveData<Boolean> = _saveUserProfile

    private val emailEmptyError by lazy { app.getString(R.string.login_email_empty_error) }
    private val emailInvalid by lazy { app.getString(R.string.login_email_invalid) }

    private val phoneEmptyError by lazy { app.getString(R.string.phone_empty) }
    private val phoneInvalid by lazy { app.getString(R.string.phone_invalid) }

    private val _canDisplayEmailError = MutableLiveData(false)
    private val _canDisplayContactError = MutableLiveData(false)
    val canDisplayEmailError: LiveData<Boolean> = _canDisplayEmailError
    val canDisplayContactError: LiveData<Boolean> = _canDisplayContactError

    init {
        _canUpdateProfile.addSource(firstNameInput.text) {
            validateData()
        }
        _canUpdateProfile.addSource(lastNameInput.text) {
            validateData()
        }
        _canUpdateProfile.addSource(emailInput.text) {
            validateData()
        }
        _canUpdateProfile.addSource(contactNumberInput.text) {
            validateData()
        }
    }

    private fun validateData() {
        val userDetails = obsidianApi.provideSessionsManager().userDetails
        val contactChanged =
            userDetails?.contactNumber != contactNumberInput.text.value && !contactNumberInput.text.value.isNullOrEmpty()
        if (emailInput.verifyEmail(emailEmptyError, emailInvalid) ||
            (contactChanged && contactNumberInput.verifyPhone(phoneEmptyError, phoneInvalid))
        ) {
            _canUpdateProfile.value = false
        } else {
            updateCanSaveProfile()
        }
    }

    private fun updateCanSaveProfile() {
        obsidianApi.provideSessionsManager().userDetails?.let {
            _canUpdateProfile.value =
                (!firstNameInput.text.value.isNullOrEmpty() && !lastNameInput.text.value.isNullOrEmpty() && !emailInput.text.value.isNullOrEmpty() && !emailInput.isError) &&
                        (it.firstName != firstNameInput.text.value || it.lastName != lastNameInput.text.value || it.email != emailInput.text.value || it.contactNumber != contactNumberInput.text.value)
        }
    }

    fun updateProfile() {
        viewModelScope.launch(dispatcherContext.io) {
            obsidianApi.provideSessionsManager().userDetails?.id?.let { id ->
                obsidianApi.meManager.saveUserDetails(
                    id.toString(),
                    UpdateProfileBody(
                        UserBody(
                            firstNameInput.text.value.toString(),
                            lastNameInput.text.value.toString(),
                            emailInput.text.value.toString(),
                            contactNumberInput.text.value ?: ""
                        )
                    )
                ).let { result ->
                    if (result.isSuccess) {
                        authorizedRepo.getUserDetails()
                    }
                    _saveUserProfile.postValue(result.isSuccess)
                }
            }
        }
    }

    private fun updateFields(userDetails: UserDetails) {
        firstNameInput.text.postValue(userDetails.firstName)
        lastNameInput.text.postValue(userDetails.lastName)
        emailInput.text.postValue(userDetails.email)
        contactNumberInput.text.postValue(userDetails.contactNumber)
    }

    fun fetchUserDetails() {
        obsidianApi.provideSessionsManager().userDetails?.let {
            updateFields(it)
        }
    }

    fun updateCanDisplayEmailError(value: Boolean) {
        _canDisplayEmailError.value = value
        if (value) {
            validateData()
        }
    }

    fun updateCanDisplayContactError(value: Boolean) {
        _canDisplayContactError.value =
            !value && !obsidianApi.provideSessionsManager().userDetails?.contactNumber.isNullOrEmpty()
        if (value) {
            validateData()
        }
    }
}
