package com.thundermaps.saferme.features.main.category

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.thundermaps.saferme.core.domain.utils.ItemInterface
import com.thundermaps.saferme.core.ui.adapter.BaseAdapter
import com.thundermaps.saferme.databinding.ItemCategoryBinding
import com.thundermaps.saferme.features.main.category.model.CategoryData
import javax.inject.Inject

class CategoryAdapter @Inject constructor() :
    BaseAdapter<CategoryData, CategoryAdapter.Companion.CategoryHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryHolder =
        CategoryHolder(
            ItemCategoryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: CategoryHolder, position: Int) {
        items.getOrNull(position)?.let {
            holder.bind(it, itemInterface)
        }
    }

    companion object {
        class CategoryHolder(
            private val binding: ItemCategoryBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(item: CategoryData, listener: ItemInterface?) {
                binding.category = item
                val onClick = View.OnClickListener {
                    listener?.onItemSelected(item)
                }
                binding.onChannelSelected = onClick
            }
        }
    }
}
