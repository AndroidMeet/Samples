package com.thundermaps.saferme.features.main.reportdetails.manage

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentManageTabBinding
import com.thundermaps.saferme.features.main.reportdetails.ReportDetailsFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ManageTabFragment : BaseFragment<FragmentManageTabBinding, ManageTabViewModel>() {
    override val viewModel: ManageTabViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_manage_tab

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setReport()
        viewModel.report.observe(viewLifecycleOwner) { report ->
            viewModel.updateAssigneeData(report)
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.hideToolBar()
    }

    private fun setReport() {
        (parentFragment as? ReportDetailsFragment)?.updateManageReport()?.let { report ->
            viewModel.storeReport(report)
        }
    }
}
