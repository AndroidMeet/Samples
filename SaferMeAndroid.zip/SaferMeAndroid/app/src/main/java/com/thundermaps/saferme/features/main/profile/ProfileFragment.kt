package com.thundermaps.saferme.features.main.profile

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentProfileBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ProfileFragment : BaseFragment<FragmentProfileBinding, ProfileViewModel>() {
    override val viewModel: ProfileViewModel by viewModels()
    override fun provideLayoutId(): Int = R.layout.fragment_profile
    private val navController get() = findNavController()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.layoutViewProfile.setOnSwitchOrganization {
            viewModel.profile.value?.let {
                navController.navigate(ProfileFragmentDirections.openChangeOrganization(it.team))
            }
        }

        binding.layoutViewProfile.setOnEditProfile {
            viewModel.profile.value?.let {
                navController.navigate(ProfileFragmentDirections.openEditProfilePage())
            }
        }

        binding.layoutViewProfile.setOnProfilePictureClicked {
            Toast.makeText(requireContext(), "The feature isn’t ready yet", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_settings, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)
        return when (item.itemId) {
            R.id.action_settings -> {
                navController.navigate(ProfileFragmentDirections.openSettingsPage())
                true
            }
            else -> false
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.loadProfile()
        actionController?.showToolBar()
        actionController?.hideNavigationIcon()
    }
}
