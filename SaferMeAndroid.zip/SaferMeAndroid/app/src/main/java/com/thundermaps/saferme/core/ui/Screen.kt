package com.thundermaps.saferme.core.ui

import com.thundermaps.apilib.android.api.ExcludeFromJacocoGeneratedReport
import com.thundermaps.apilib.android.api.responses.models.Sessions

enum class Screen {
    UPDATE_PASSWORD, UPDATE_PROFILE, MAP, SELECT_TEAM
}

@ExcludeFromJacocoGeneratedReport
fun Sessions.nextScreen(): Screen = when {
    teamId == null -> {
        Screen.SELECT_TEAM
    }
    profileDetailsPending -> {
        Screen.UPDATE_PROFILE
    }
    passwordUpdatePending -> {
        Screen.UPDATE_PASSWORD
    }
    else -> {
        Screen.MAP
    }
}
