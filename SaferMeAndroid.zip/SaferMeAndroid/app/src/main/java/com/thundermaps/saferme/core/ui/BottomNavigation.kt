package com.thundermaps.saferme.core.ui

interface BottomNavigation {
    fun showBottomNavigation()
    fun makeBottomNavigationInvisible(onFinish: () -> Unit)
    fun makeBottomNavigationGone()
}
