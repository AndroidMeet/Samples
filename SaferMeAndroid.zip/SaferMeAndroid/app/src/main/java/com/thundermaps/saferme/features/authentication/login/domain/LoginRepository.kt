package com.thundermaps.saferme.features.authentication.login.domain

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.apilib.android.api.requests.models.SessionBody
import com.thundermaps.apilib.android.api.responses.models.ResponseException
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.core.data.exceptions.SaferMeException
import com.thundermaps.saferme.core.domain.AppIdProvider
import com.thundermaps.saferme.core.domain.models.isAccountLocked
import javax.inject.Inject
import kotlinx.coroutines.coroutineScope

interface LoginRepository {
    val isStaging: LiveData<Boolean>
    suspend fun login(body: SessionBody): Result<Sessions>
    suspend fun getCacheSessions(): Sessions?

    suspend fun isAccountLocked(email: String): Boolean
    fun useStagingEnv()
    fun useLiveEnv()
    suspend fun syncBrand()
}

class LoginRepositoryImpl @Inject constructor(
    private val obsidianApi: ObsidianApi,
    private val accountLocker: AccountLocker,
    private val appIdProvider: AppIdProvider
) : LoginRepository {
    private val sessionsManager = obsidianApi.provideSessionsManager()
    private val loginService = obsidianApi.loginService
    private val _isStaging = MutableLiveData(loginService.isStaging())
    override val isStaging: LiveData<Boolean> = _isStaging

    override suspend fun getCacheSessions(): Sessions? {
        return sessionsManager.getSessions()
    }

    override suspend fun syncBrand() {
        obsidianApi.brandManager.sync(appIdProvider.appId)
    }

    override suspend fun login(body: SessionBody): Result<Sessions> = coroutineScope {
        val result = loginService.login(body, appIdProvider.appId)
        if (result is Result.Error) {
            val responseException = result.exception
            if (responseException is ResponseException) {
                val responseError = responseException.responseError
                if (responseError.isAccountLocked()) {
                    lockAccount(body.user.email)
                } else {
                    increaseFailureTimes(body.user.email)
                }
                return@coroutineScope Result.Error(null, SaferMeException(responseError))
            }
            return@coroutineScope result
        } else {
            result.getNullableData()?.let { sessions ->
                resetFailureLogin(body.user.email)
                sessionsManager.saveSessions(sessions, appIdProvider.appId)
            }

            return@coroutineScope result
        }
    }

    private suspend fun increaseFailureTimes(email: String) {
        accountLocker.increaseFailureTimes(email)
    }

    private suspend fun lockAccount(email: String) {
        accountLocker.lockAccount(email)
    }

    private suspend fun resetFailureLogin(email: String) {
        accountLocker.resetLockedAccount(email)
    }

    override suspend fun isAccountLocked(email: String): Boolean {
        return accountLocker.isLocked(email)
    }

    override fun useStagingEnv() {
        _isStaging.postValue(true)
        sessionsManager.setToStagingEnvironment(true)
    }

    override fun useLiveEnv() {
        _isStaging.postValue(false)
        sessionsManager.setToStagingEnvironment(false)
    }
}
