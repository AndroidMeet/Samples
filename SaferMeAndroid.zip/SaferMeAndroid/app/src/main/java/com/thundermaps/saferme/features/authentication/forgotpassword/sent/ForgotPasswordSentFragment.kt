package com.thundermaps.saferme.features.authentication.forgotpassword.sent

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.ui.BaseFragment
import com.thundermaps.saferme.databinding.FragmentForgotPasswordSentBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ForgotPasswordSentFragment : BaseFragment<FragmentForgotPasswordSentBinding, ForgotPasswordSentViewModel>() {
    private val navigationController get() = findNavController()
    private val args: ForgotPasswordSentFragmentArgs by navArgs()

    override val viewModel: ForgotPasswordSentViewModel by viewModels()

    override fun provideLayoutId(): Int = R.layout.fragment_forgot_password_sent

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupListener()

        viewModel.updateEmail(args.email)
    }

    private fun setupListener() {
        binding.returnToLoginButton.setOnClickListener {
            navigationController.navigate(ForgotPasswordSentFragmentDirections.openLogin())
        }
        binding.sendNewLinkButton.setOnClickListener {
            navigationController.navigate(ForgotPasswordSentFragmentDirections.openForgotPasswordScreen())
        }
    }

    override fun onResume() {
        super.onResume()
        actionController?.showToolBar()
    }
}
