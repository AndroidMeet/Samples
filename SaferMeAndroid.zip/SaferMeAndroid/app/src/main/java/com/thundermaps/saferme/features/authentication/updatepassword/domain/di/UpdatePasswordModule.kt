package com.thundermaps.saferme.features.authentication.updatepassword.domain.di

import com.nulabinc.zxcvbn.Zxcvbn
import com.thundermaps.saferme.features.authentication.updatepassword.domain.PasswordCalculator
import com.thundermaps.saferme.features.authentication.updatepassword.domain.PasswordCalculatorImpl
import com.thundermaps.saferme.features.authentication.updatepassword.domain.UpdatePasswordRepository
import com.thundermaps.saferme.features.authentication.updatepassword.domain.UpdatePasswordRepositoryImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
class UpdatePasswordModule {
    @Provides
    fun providerPasswordCalculator(): Zxcvbn = Zxcvbn()

    @Provides
    fun providePasswordCalculator(passwordCalculator: PasswordCalculatorImpl): PasswordCalculator = passwordCalculator

    @Provides
    fun provideUpdatePasswordRepository(repository: UpdatePasswordRepositoryImpl): UpdatePasswordRepository = repository
}
