package com.thundermaps.saferme.features.authentication.updatepassword

import android.app.Application
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.nulabinc.zxcvbn.Zxcvbn
import com.thundermaps.apilib.android.api.requests.models.UpdatePasswordBody
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.features.authentication.updatepassword.domain.PasswordCalculator
import com.thundermaps.saferme.features.authentication.updatepassword.domain.PasswordCalculatorImpl
import com.thundermaps.saferme.features.authentication.updatepassword.domain.PasswordStrengthLevel
import com.thundermaps.saferme.features.authentication.updatepassword.domain.UpdatePasswordRepository
import com.thundermaps.saferme.features.authentication.updatepassword.domain.UpdatePasswordViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class UpdatePasswordViewModelTest : BaseTest() {
    private val testContextProvider = TestContextProvider()
    private val passwordCalculator: PasswordCalculator = PasswordCalculatorImpl(Zxcvbn())
    private val repository: UpdatePasswordRepository = mock()
    private lateinit var viewModel: UpdatePasswordViewModel

    private val application: Application = mock {
        on { getString(R.string.new_password) } doReturn NEW_PASSWORD
    }

    @Before
    fun setup() {
        viewModel = UpdatePasswordViewModel(
            application,
            passwordCalculator,
            repository,
            testContextProvider
        )
        viewModel.setOldPassword(INITIAL_PASSWORD)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(application, repository)
    }

    @Test
    fun `verify initialize view model`() {
        verify(application).getString(R.string.new_password)
    }

    @Test
    fun `enter too weak password then password strength level = TOO_WEAK `() = runBlock {
        viewModel.passwordInput.text.value = "abcdef"

        viewModel.passwordStrengthLevel.observeForTesting {
            assertEquals(PasswordStrengthLevel.TOO_WEAK, viewModel.passwordStrengthLevel.value)
        }

        viewModel.isReadyToUpdate.observeForTesting {
            assertFalse(viewModel.isReadyToUpdate.value!!)
        }

        `verify initialize view model`()
    }

    @Test
    fun `enter weak password then password strength level = WEAK`() = runBlock {
        viewModel.passwordInput.text.value = "abcdeF"

        viewModel.passwordStrengthLevel.observeForTesting {
            assertEquals(PasswordStrengthLevel.WEAK, viewModel.passwordStrengthLevel.value)
        }

        viewModel.isReadyToUpdate.observeForTesting {
            assertFalse(viewModel.isReadyToUpdate.value!!)
        }

        `verify initialize view model`()
    }

    @Test
    fun `enter medium password then password strength level = MEDIUM`() = runBlock {
        viewModel.passwordInput.text.value = "2902jio"

        viewModel.passwordStrengthLevel.observeForTesting {
            assertEquals(PasswordStrengthLevel.MEDIUM, viewModel.passwordStrengthLevel.value)
        }

        viewModel.isReadyToUpdate.observeForTesting {
            assertFalse(viewModel.isReadyToUpdate.value!!)
        }

        `verify initialize view model`()
    }

    @Test
    fun `enter strong password then password strength level = STRONG`() = runBlock {
        viewModel.passwordInput.text.value = "Ab#cd3Faj92@()()"

        viewModel.passwordStrengthLevel.observeForTesting {
            assertEquals(PasswordStrengthLevel.STRONG, viewModel.passwordStrengthLevel.value)
        }

        viewModel.isReadyToUpdate.observeForTesting {
            assertTrue(viewModel.isReadyToUpdate.value!!)
        }

        `verify initialize view model`()
    }

    @Test
    fun `enter strong password then password strength level = STRONG but duplicate with the old password`() =
        runBlock {
            val password = "Ab#cd3Faj92@()()"
            viewModel.setOldPassword(password)
            whenever(application.getString(R.string.update_password_error_duplicate)).doReturn(
                DUPLICATE_MESSAGE
            )

            viewModel.passwordInput.text.value = password

            viewModel.passwordStrengthLevel.observeForTesting {
                assertEquals(PasswordStrengthLevel.STRONG, viewModel.passwordStrengthLevel.value)
            }

            viewModel.isReadyToUpdate.observeForTesting {
                assertFalse(viewModel.isReadyToUpdate.value!!)
            }

            viewModel.passwordInput.error.observeForTesting {
                assertTrue(viewModel.passwordInput.isError)
                assertEquals(DUPLICATE_MESSAGE, viewModel.passwordInput.error.value)
            }
            verify(application).getString(R.string.update_password_error_duplicate)

            `verify initialize view model`()
        }

    @Test
    fun `update password`() = runBlock {
        val password = "Ab#cd3Faj92@()()"
        viewModel.passwordInput.text.value = password

        viewModel.updatePassword()

        viewModel.passwordStrengthLevel.observeForTesting {
            assertEquals(PasswordStrengthLevel.STRONG, viewModel.passwordStrengthLevel.value)
        }

        viewModel.isReadyToUpdate.observeForTesting {
            assertTrue(viewModel.isReadyToUpdate.value!!)
        }

        val updatePasswordCaptor = argumentCaptor<UpdatePasswordBody>()
        verify(repository).updatePassword(updatePasswordCaptor.capture())

        assertEquals(
            UpdatePasswordBody(INITIAL_PASSWORD, password),
            updatePasswordCaptor.firstValue
        )

        `verify initialize view model`()
    }

    private fun runBlock(block: suspend () -> Unit) {
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            block()
        }
    }

    companion object {
        private const val NEW_PASSWORD = "New Password"
        private const val DUPLICATE_MESSAGE = "Duplicate password"
        private const val INITIAL_PASSWORD = "329095201AIaOITQ()("
    }
}
