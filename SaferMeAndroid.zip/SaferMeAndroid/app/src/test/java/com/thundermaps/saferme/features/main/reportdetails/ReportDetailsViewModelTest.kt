package com.thundermaps.saferme.features.main.reportdetails

import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.MockitoKotlinException
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.TaskManager
import com.saferme.obsidian.authentication.SessionsManager
import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianTask
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.features.main.reports.domain.model.CardData
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

@ExperimentalCoroutinesApi
class ReportDetailsViewModelTest : BaseTest() {
    private val app: SaferMeApplication = mock()
    private val testContextProvider = TestContextProvider()
    private val reportManager: ReportManager = mock()

    private lateinit var reportDetailsViewModel: ReportDetailsViewModel

    private val report: ObsidianReport = mock {
        on { uuid } doReturn UUID
    }

    private val taskManager: TaskManager = mock()

    private val cacheSession: Sessions = mock {
        on { userId } doReturn USERID
    }
    private val sessionsManager: SessionsManager = mock {
        on { getSessions() } doReturn cacheSession
    }

    private fun createReportDetailsViewModel() {
        reportDetailsViewModel = ReportDetailsViewModel(
            app,
            reportManager,
            taskManager,
            sessionsManager,
            testContextProvider
        )
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(app, reportManager, taskManager, sessionsManager)
    }

    @Test
    fun `verify get report success and number of tasks are not zero`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            mockCommon()
            createReportDetailsViewModel()
            whenever(reportManager.readOne(any())).doReturn(report)
            val tasksLiveData = MutableLiveData<List<ObsidianTask>>(listOf(mock(), mock()))
            whenever(taskManager.readReportTask(any(), any())).doReturn(tasksLiveData)
            whenever(app.getString(any(), any())).doReturn(TASKS2)

            reportDetailsViewModel.loadReport(UUID)

            val uuidArgumentCaptor = argumentCaptor<String>()
            verify(reportManager).readOne(uuidArgumentCaptor.capture())

            assertEquals(UUID, uuidArgumentCaptor.firstValue)

            reportDetailsViewModel.report.observeForTesting {
                assertEquals(report, reportDetailsViewModel.report.value?.getNullableData())
            }

            reportDetailsViewModel.cardData.observeForTesting {
                assertEquals(CardData.of(report), reportDetailsViewModel.cardData.value)
            }

            reportDetailsViewModel.titles.observeForTesting {
                verify(app).getString(R.string.report_tasks_placeholder, 2)
                assertEquals(TASKS2, reportDetailsViewModel.titles.value?.last())
            }
            verifyLoadReport()
            verifyCommon()
        }

    @Test
    fun `verify get report error`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        mockCommon()
        createReportDetailsViewModel()
        val exception = MockitoKotlinException("Error", null)
        whenever(reportManager.readOne(any())).thenThrow(exception)
        reportDetailsViewModel.loadReport(UUID)

        val uuidArgumentCaptor = argumentCaptor<String>()
        verify(reportManager).readOne(uuidArgumentCaptor.capture())

        assertEquals(UUID, uuidArgumentCaptor.firstValue)

        reportDetailsViewModel.report.observeForTesting {
            assertNull(reportDetailsViewModel.report.value?.getNullableData())
        }

        reportDetailsViewModel.cardData.observeForTesting {
            assertNull(reportDetailsViewModel.cardData.value)
        }

        verifyLoadReport()
        verifyCommon()
    }

    private fun verifyLoadReport() {
        val userIdCaptor = argumentCaptor<Int>()
        val uuidCaptor = argumentCaptor<String>()
        verify(taskManager).readReportTask(userIdCaptor.capture(), uuidCaptor.capture())
        assertEquals(UUID, uuidCaptor.firstValue)
        assertEquals(USERID.toInt(), userIdCaptor.firstValue)
        verify(sessionsManager).getSessions()
    }

    @Test
    fun `verify when viewmodel is initialized`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            mockCommon()

            createReportDetailsViewModel()

            assertEquals(listOf(DETAILS, MANAGE, TASKS), reportDetailsViewModel.titles.value)
            verifyCommon()
        }

    private fun mockCommon() {
        whenever(app.getString(R.string.report_details)).doReturn(DETAILS)
        whenever(app.getString(R.string.report_manage)).doReturn(MANAGE)
        whenever(app.getString(R.string.report_tasks_placeholder, 0)).doReturn(TASKS)
    }

    private fun verifyCommon() {
        verify(app).getString(R.string.report_details)
        verify(app).getString(R.string.report_manage)
        verify(app).getString(R.string.report_tasks_placeholder, 0)
    }

    companion object {
        private const val DETAILS = "Details"
        private const val MANAGE = "Manage"
        private const val TASKS = "Tasks (0)"
        private const val TASKS2 = "Tasks (2)"
        private const val UUID = "32903290-39203920-23920930209320932"
        private const val USERID = 3290329L
    }
}
