package com.thundermaps.saferme.features.main.reports

import android.content.res.Resources
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.sync.resources.ReportSync
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class ReportsTabViewModelTest {
    private val resources: Resources = mock {
        on { getStringArray(R.array.report_tabs) } doReturn titles
    }
    private val application: SaferMeApplication = mock {
        on { resources } doReturn resources
    }
    private val reportSyncMock: ReportSync = mock()
    private val reportManager: ReportManager = mock {
        on { reportSync } doReturn reportSyncMock
    }
    private val testContextProvider = TestContextProvider()
    private lateinit var reportsTabViewModel: ReportsTabViewModel

    @Before
    fun setUp() {
        reportsTabViewModel = ReportsTabViewModel(application, reportManager, testContextProvider)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(resources, application, reportManager, reportSyncMock, resources)
    }

    @Test
    fun `verify get titles`() {
        val result = reportsTabViewModel.titles

        assertEquals(titles.toList(), result)
        verify(resources).getStringArray(R.array.report_tabs)
        verify(application).resources
    }

    @Test
    fun `verify call sync reports`() = runBlockingTest {
        reportsTabViewModel.syncReport()

        verify(reportManager).reportSync
        verify(reportSyncMock).synchronize()
    }

    companion object {
        private val titles = listOf("All reports", "My reports").toTypedArray()
    }
}
