package com.thundermaps.saferme.features.main.createreport

import android.net.Uri
import android.os.Environment
import com.mapbox.geojson.Point
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.FileAttachmentManager
import com.saferme.obsidian.FormManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.Provider.gson
import com.saferme.obsidian.StateManager
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.apilib.android.api.responses.models.FileAttachment
import com.thundermaps.apilib.android.api.responses.models.FormField
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.models.CustomSearchResult
import com.thundermaps.saferme.core.domain.models.PhotoItem
import com.thundermaps.saferme.core.domain.models.PhotoType
import com.thundermaps.saferme.core.domain.models.ReportData
import com.thundermaps.saferme.core.domain.models.Signature
import com.thundermaps.saferme.core.ui.extensions.createImageFile
import com.thundermaps.saferme.core.ui.extensions.getImageUriForFile
import com.thundermaps.saferme.core.util.TimeUtil.toMediumDateInString
import com.thundermaps.saferme.core.util.TimeUtil.toShortTimeInString
import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import java.io.File
import java.util.Date
import java.util.UUID
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class CreateReportViewModelTest : BaseTest() {
    private val testContextProvider = TestContextProvider()
    private val app: SaferMeApplication = mock()
    private val formManager: FormManager = mock()
    private val stateManager: StateManager = mock()
    private val fileAttachmentManager: FileAttachmentManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { formManager } doReturn formManager
        on { fileAttachmentManager } doReturn fileAttachmentManager
        on { stateManager } doReturn stateManager
    }

    private val searchResult: CustomSearchResult = mock {
        on { location } doReturn LOCATION
    }
    private val obsidianChannel: ObsidianChannel = mock {
        on { id } doReturn CHANNEL_ID
    }

    private val createReportData = ReportData.Create(
        searchResult,
        obsidianChannel
    )

    private lateinit var createReportViewModel: CreateReportViewModel

    @Before
    fun setUp() {
        createReportViewModel = CreateReportViewModel(app, obsidianApi, testContextProvider, gson)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(
            formManager,
            obsidianApi,
            obsidianChannel,
            searchResult,
            app,
            fileAttachmentManager
        )
    }

    @Test
    fun `verify get Form`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        createReportViewModel.updateReportData(createReportData)

        val channelIdArgumentCaptor = argumentCaptor<Int>()
        verify(formManager).getForm(channelIdArgumentCaptor.capture())
        verify(searchResult).address
        verify(searchResult, times(2)).location
        verify(obsidianChannel, times(2)).id
        verify(obsidianApi).stateManager
        verify(stateManager).getStatesByChannel(CHANNEL_ID.toInt())
        assertEquals(CHANNEL_ID.toInt(), channelIdArgumentCaptor.firstValue)
        verifySyncForm()
    }

    private suspend fun verifySyncForm() {
        verify(obsidianApi, times(2)).formManager

        val channelIdArgumentCaptor = argumentCaptor<Int>()
        verify(formManager).syncForm(channelIdArgumentCaptor.capture())

        assertEquals(CHANNEL_ID.toInt(), channelIdArgumentCaptor.firstValue)
    }

    @Test
    fun `verify emit default date time`() {
        val time = Date()

        createReportViewModel.emitDefaultDateTime()

        createReportViewModel.timeInString.observeForTesting {
            assertEquals(time.toShortTimeInString(), createReportViewModel.timeInString.value)
        }

        createReportViewModel.dateInString.observeForTesting {
            assertEquals(time.toMediumDateInString(), createReportViewModel.dateInString.value)
        }
    }

    @Test
    fun `verify update date`() {
        val year = 2011
        val date = 14
        val month = 10
        val time = java.sql.Date.valueOf("$year-${month + 1}-$date")

        createReportViewModel.updateDate(year, month, date)
        createReportViewModel.dateInString.observeForTesting {
            assertEquals(time.toMediumDateInString(), createReportViewModel.dateInString.value)
        }
    }

    @Test
    fun `verify update time`() {
        val hour = 14
        val minute = 39
        createReportViewModel.updateTime(hour, minute)
        createReportViewModel.timeInString.observeForTesting {
            assertEquals("02:39pm", createReportViewModel.timeInString.value?.lowercase())
        }
    }

    @Test
    fun `verify default photos and photo type`() {
        assertNull(createReportViewModel.photoType)
        assertNotNull(createReportViewModel.photos.value)
        assertTrue(createReportViewModel.photos.value?.firstOrNull()?.isAddItem == true)
        assertNull(createReportViewModel.capturePhotoPath)
    }

    @Test
    fun `verify updatePhotoType`() {
        createReportViewModel.updatePhotoType(PhotoType.CAMERA)
        assertEquals(PhotoType.CAMERA, createReportViewModel.photoType)

        createReportViewModel.updatePhotoType(PhotoType.LIBRARY)
        assertEquals(PhotoType.LIBRARY, createReportViewModel.photoType)

        createReportViewModel.updatePhotoType(null)
        assertNull(createReportViewModel.photoType)
    }

    @Test
    fun `verify addPhoto and upload photo failure`() = runBlockingTest {
        `verify get Form`()
        val path = "photo1.png"

        createReportViewModel.addDeletablePhoto(path)

        val photoItem = createReportViewModel.photos.value?.firstOrNull { it.path == path }
        assertNotNull(photoItem)
        assertEquals(listOf(photoItem), createReportViewModel.realPhotos)

        val pathArgumentCaptor = argumentCaptor<String>()
        verify(obsidianApi).fileAttachmentManager
        verify(fileAttachmentManager).uploadPhoto(pathArgumentCaptor.capture())
        assertEquals(path, pathArgumentCaptor.firstValue)
    }

    @Test
    fun `verify addPhoto and upload photo success`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            `verify get Form`()
            val path = "photo1.png"
            val fileAttachment = FileAttachment(
                id = 32902,
                originalUrl = "http://abc.test",
                fileName = null
            )
            whenever(fileAttachmentManager.uploadPhoto(any())).doReturn(fileAttachment)

            createReportViewModel.addDeletablePhoto(path)

            val photoItem = createReportViewModel.photos.value?.firstOrNull { it.path == path }
            val newPhotoItem = photoItem?.copy(
                url = fileAttachment.originalUrl,
                attachmentId = fileAttachment.id
            )
            assertTrue(createReportViewModel.photos.value?.contains(newPhotoItem) == true)
            assertEquals(listOf(newPhotoItem), createReportViewModel.realPhotos)

            val pathArgumentCaptor = argumentCaptor<String>()
            verify(obsidianApi).fileAttachmentManager
            verify(fileAttachmentManager).uploadPhoto(pathArgumentCaptor.capture())
            assertEquals(photoItem?.path, pathArgumentCaptor.firstValue)
        }

    @Test
    fun `verify uploadPending`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            `verify get Form`()
            val path1 = "photo1.png"
            val path2 = "photo2.png"
            val fileAttachment1 = FileAttachment(
                id = 32902,
                originalUrl = "http://abc.test",
                fileName = null
            )
            val fileAttachment2 = FileAttachment(
                id = 32904,
                originalUrl = "http://abc.test2",
                fileName = null
            )

            createReportViewModel.addDeletablePhoto(path1)
            createReportViewModel.addDeletablePhoto(path2)

            val photoItem1 = createReportViewModel.photos.value?.firstOrNull { it.path == path1 }
            val photoItem2 = createReportViewModel.photos.value?.firstOrNull { it.path == path2 }

            assertTrue(createReportViewModel.photos.value?.contains(photoItem1) == true)
            assertTrue(createReportViewModel.photos.value?.contains(photoItem2) == true)
            assertEquals(listOf(photoItem1, photoItem2), createReportViewModel.realPhotos)

            val pathArgumentCaptor = argumentCaptor<String>()
            verify(obsidianApi, times(2)).fileAttachmentManager
            verify(fileAttachmentManager, times(2)).uploadPhoto(pathArgumentCaptor.capture())
            assertEquals(photoItem1?.path, pathArgumentCaptor.firstValue)
            assertEquals(photoItem2?.path, pathArgumentCaptor.secondValue)

            whenever(fileAttachmentManager.uploadPhoto(photoItem1?.path!!)).doReturn(fileAttachment1)
            val newPhotoItem1 = photoItem1.copy(
                url = fileAttachment1.originalUrl,
                attachmentId = fileAttachment1.id
            )
            whenever(fileAttachmentManager.uploadPhoto(photoItem2?.path!!)).doReturn(fileAttachment2)
            val newPhotoItem2 = photoItem2.copy(
                url = fileAttachment2.originalUrl,
                attachmentId = fileAttachment2.id
            )

            createReportViewModel.uploadPendingPhotos()

            verify(obsidianApi, times(4)).fileAttachmentManager
            verify(fileAttachmentManager, times(4)).uploadPhoto(pathArgumentCaptor.capture())
            assertEquals(photoItem1.path, pathArgumentCaptor.firstValue)
            assertEquals(photoItem2.path, pathArgumentCaptor.secondValue)
            assertEquals(photoItem1.path, pathArgumentCaptor.thirdValue)
            assertEquals(photoItem2.path, pathArgumentCaptor.lastValue)

            assertTrue(createReportViewModel.photos.value?.contains(newPhotoItem1) == true)
            assertTrue(createReportViewModel.photos.value?.contains(newPhotoItem2) == true)
            assertEquals(listOf(newPhotoItem1, newPhotoItem2), createReportViewModel.realPhotos)
        }

    @Test
    fun `verify remove Photo`() = runBlockingTest {
        `verify get Form`()
        val path = "photo1.png"

        createReportViewModel.addDeletablePhoto(path)

        val photoItem = createReportViewModel.photos.value?.firstOrNull { it.path == path }
        assertNotNull(photoItem)

        val pathArgumentCaptor = argumentCaptor<String>()
        verify(obsidianApi).fileAttachmentManager
        verify(fileAttachmentManager).uploadPhoto(pathArgumentCaptor.capture())
        assertEquals(path, pathArgumentCaptor.firstValue)

        createReportViewModel.deletePhoto(photoItem!!)
        assertTrue(createReportViewModel.photos.value?.contains(photoItem) == false)
    }

    @Test
    fun `verify create capture image failure`() {
        createReportViewModel.createCapturePhotoUri()

        assertNull(createReportViewModel.capturePhotoPath)

        val requestArgumentCapture = argumentCaptor<String>()
        verify(app).getExternalFilesDir(requestArgumentCapture.capture())
        assertEquals(Environment.DIRECTORY_PICTURES, requestArgumentCapture.firstValue)
    }

    @Test
    fun `verify create capture image success`() {
        val file = File("test.jpg")

        mockkStatic("com.thundermaps.saferme.core.ui.extensions.ContextExtensionsKt")
        every {
            app.createImageFile()
        } returns file

        val mockUri = mock<Uri>()

        every {
            app.getImageUriForFile(file)
        } returns mockUri

        val uri = createReportViewModel.createCapturePhotoUri()

        assertEquals(file.absolutePath, createReportViewModel.capturePhotoPath)
        assertEquals(mockUri, uri)

        unmockkAll()
    }

    @Test
    fun `verify update signature`() {
        val signature = Signature("test", 3, mock())
        createReportViewModel.updateSignature(signature)

        createReportViewModel.signature.observeForTesting {
            assertEquals(signature, createReportViewModel.signature.value)
        }
    }

    @Test
    fun `get input field`() {
        val abcId = 45
        val labelA = "label 34"
        val formField = mock<FormField> {
            on { id } doReturn abcId
            on { label } doReturn labelA
        }

        val input = createReportViewModel.getInputField(formField, false)
        assertEquals(labelA, input.title)
    }

    @Test
    fun `add exist photo`() {
        val reportUuid = UUID.randomUUID().toString()
        val fileId1 = 329029
        val fileId2 = 299420

        val photoItem1 = PhotoItem(
            reportUuid = reportUuid,
            attachmentId = fileId1,
            isDeletable = true
        )

        val photoItem2 = PhotoItem(
            reportUuid = reportUuid,
            attachmentId = fileId2,
            isDeletable = true
        )

        val photoItem3 = PhotoItem(
            reportUuid = reportUuid,
            attachmentId = fileId1,
            isDeletable = true
        )

        val photoItem4 = PhotoItem(
            reportUuid = reportUuid,
            attachmentId = fileId2,
            isDeletable = true
        )

        createReportViewModel.addExistPhoto(listOf(photoItem1, photoItem2))
        createReportViewModel.addExistPhoto(listOf(photoItem3, photoItem4))

        createReportViewModel.photos.observeForTesting {
            val photos = createReportViewModel.photos.value?.toMutableList()
            photos?.removeLast()
            assertEquals(listOf(photoItem1, photoItem2), photos)
        }
    }

    companion object {
        private const val CHANNEL_ID = 3290L
        private const val LATITUDE = 50.652111
        private const val LONGITUDE = -3.174039
        private val LOCATION = Point.fromLngLat(LONGITUDE, LATITUDE)
    }
}
