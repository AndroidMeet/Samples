package com.thundermaps.saferme.core.usecase

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ChannelManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.authentication.SessionsManager
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.apilib.android.api.responses.models.Clients
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.models.MapType
import com.thundermaps.saferme.core.usecase.MapOptionsUseCase.Companion.MAP_TYPE_KEY
import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.AfterClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class MapOptionsUseCaseTest : BaseTest() {
    private val channelManagerMock: ChannelManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { channelsManager } doReturn channelManagerMock
    }
    private val context = mock<Context>()
    private val editor = mock<SharedPreferences.Editor>()
    private val sharedPreferences = mock<SharedPreferences> {
        on { edit() } doReturn editor
        on { getInt(any(), any()) } doReturn MapType.ROAD.value
    }

    private lateinit var mapOptionsUseCase: MapOptionsUseCase

    @Before
    fun setUp() {
        mockkStatic(PreferenceManager::class)
        every { PreferenceManager.getDefaultSharedPreferences(context) } returns sharedPreferences

        mapOptionsUseCase = MapOptionsUseCase(context, obsidianApi)
    }

    @After
    fun tearDown() {
        verifyGetSavedMapType()
        verify(obsidianApi).channelsManager
        verifyNoMoreInteractions(
            context,
            editor,
            sharedPreferences,
            obsidianApi,
            channelManagerMock
        )
        tearDownClass()
    }

    private fun verifyGetSavedMapType() {
        val keyArgumentCaptor = argumentCaptor<String>()
        val valueCaptor = argumentCaptor<Int>()
        verify(sharedPreferences).getInt(keyArgumentCaptor.capture(), valueCaptor.capture())
        assertEquals(MAP_TYPE_KEY, keyArgumentCaptor.firstValue)
        assertEquals(MapType.ROAD.value, valueCaptor.firstValue)
    }

    @Test
    fun `verify default maptype is road`() {
        mapOptionsUseCase.mapType.observeForTesting {
            assertEquals(MapType.ROAD, mapOptionsUseCase.mapType.value)
        }

        mapOptionsUseCase.isOpeningMapOption.observeForTesting {
            assertFalse(mapOptionsUseCase.isOpeningMapOption.value!!)
        }
    }

    @Test
    fun `verify save maptype`() {
        val mapType = MapType.SATELLITE
        mapOptionsUseCase.updateMapType(mapType)

        mapOptionsUseCase.mapType.observeForTesting {
            assertEquals(mapType, mapOptionsUseCase.mapType.value)
        }

        val keyArgumentCaptor = argumentCaptor<String>()
        val valueCaptor = argumentCaptor<Int>()
        verify(editor).putInt(keyArgumentCaptor.capture(), valueCaptor.capture())
        assertEquals(MAP_TYPE_KEY, keyArgumentCaptor.firstValue)
        assertEquals(mapType.value, valueCaptor.firstValue)
        verify(editor).apply()
        verify(sharedPreferences).edit()
    }

    @Test
    fun `verify open map options`() {
        mapOptionsUseCase.openMapOptions()

        mapOptionsUseCase.isOpeningMapOption.observeForTesting {
            assertTrue(mapOptionsUseCase.isOpeningMapOption.value!!)
        }
    }

    @Test
    fun `verify close map options`() {
        mapOptionsUseCase.closeMapOptions()

        mapOptionsUseCase.isOpeningMapOption.observeForTesting {
            assertFalse(mapOptionsUseCase.isOpeningMapOption.value!!)
        }
    }

    @Test
    fun `verify load channels`() = runBlockingTest {
        mapOptionsUseCase.loadChannels()

        verify(channelManagerMock).syncChannels()
    }

    @Test
    fun `verify update channels`() = runBlockingTest {
        val channel: ObsidianChannel = mock()

        mapOptionsUseCase.updateChannel(channel)

        verify(channelManagerMock).updateChannel(channel)
    }

    @Test
    fun `verify get client`() = runBlockingTest {
        val mockClients: Clients = mock()
        val sessionManager: SessionsManager = mock {
            on { clients } doReturn mockClients
        }
        whenever(obsidianApi.provideSessionsManager()).doReturn(sessionManager)

        val clients = mapOptionsUseCase.clients

        verify(obsidianApi).provideSessionsManager()
        verify(sessionManager).clients
        assertEquals(mockClients, clients)
        verifyNoMoreInteractions(mockClients, sessionManager)
    }

    companion object {
        @AfterClass
        @JvmStatic
        fun tearDownClass() {
            unmockkAll()
        }
    }
}
