package com.thundermaps.saferme.features.splash

import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class SplashViewModelTest : BaseTest() {
    private val obsidianApi: ObsidianApi = mock()
    private lateinit var splashViewModel: SplashViewModel

    private val testContextProvider = TestContextProvider()

    @Before
    fun setUp() {
        splashViewModel = SplashViewModel(obsidianApi, testContextProvider)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(obsidianApi)
    }

    @Test
    fun `obsidian API will return isAuthenticated = false then user is not authorized`() =
        runBlockingTest {
            whenever(obsidianApi.isAuthenticated()).doReturn(false)

            val result = splashViewModel.isAuthenticated()
            result.observeForTesting {
                val status = result.value
                assertTrue(status!!.isSuccess)
                assertFalse(status.getNullableData()!!)
            }
            verify(obsidianApi).isAuthenticated()
        }

    @Test
    fun `obsidian API will return isAuthenticated = true then user is authorized`() =
        runBlockingTest {
            whenever(obsidianApi.isAuthenticated()).doReturn(true)
            val result = splashViewModel.isAuthenticated()
            result.observeForTesting {
                val status = result.value
                assertTrue(status!!.isSuccess)
                assertTrue(status.getNullableData()!!)
            }

            verify(obsidianApi).isAuthenticated()
        }
}
