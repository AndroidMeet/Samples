package com.thundermaps.saferme.features.authentication.updatepassword.domain

import android.content.res.Resources
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.MeManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.apilib.android.api.requests.models.UpdatePasswordBody
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.domain.AppIdProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class UpdatePasswordRepositoryTest : BaseTest() {
    private val myInfoManager: MeManager = mock()
    private val sessionsManager: SessionsManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { provideSessionsManager() } doReturn sessionsManager
        on { meManager } doReturn myInfoManager
    }

    private lateinit var repository: UpdatePasswordRepository
    private val appIdProvider = AppIdProvider()
    private val appId = appIdProvider.appId

    @Before
    fun setUp() {
        repository = UpdatePasswordRepositoryImpl(
            obsidianApi,
            appIdProvider
        )
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(myInfoManager, obsidianApi, sessionsManager)
    }

    @Test
    fun `update password success then save new sessions and update credential`() = runBlockingTest {
        val body = UpdatePasswordBody("ag909ew", "iewoighowihg")
        val mockResult = Result.Success(Unit)
        whenever(myInfoManager.updatePassword(body)).doReturn(mockResult)

        whenever(sessionsManager.getSessions()).doReturn(oldSessions)

        val result = repository.updatePassword(body)

        assertTrue(result.isSuccess)
        val bodyCaptor = argumentCaptor<UpdatePasswordBody>()
        verify(myInfoManager).updatePassword(bodyCaptor.capture())
        assertEquals(body, bodyCaptor.firstValue)
        verify(sessionsManager).getSessions()

        val newSessionsCaptor = argumentCaptor<Sessions>()
        verify(sessionsManager).saveSessions(newSessionsCaptor.capture(), eq(appId))
        assertEquals(oldSessions.copy(passwordUpdatePending = false), newSessionsCaptor.firstValue)

        verify(obsidianApi).provideSessionsManager()
        verify(obsidianApi).meManager
    }

    @Test
    fun `update password success then save new sessions`() = runBlockingTest {
        val body = UpdatePasswordBody("ag909ew", "iewoighowihg")

        val mockResult = Result.Success(Unit)
        whenever(myInfoManager.updatePassword(body)).doReturn(mockResult)

        val sessions = oldSessions.copy(profileDetailsPending = true)
        whenever(sessionsManager.getSessions()).doReturn(sessions)

        val result = repository.updatePassword(body)

        assertTrue(result.isSuccess)
        val bodyCaptor = argumentCaptor<UpdatePasswordBody>()
        verify(myInfoManager).updatePassword(bodyCaptor.capture())
        assertEquals(body, bodyCaptor.firstValue)
        verify(sessionsManager).getSessions()

        val newSessionsCaptor = argumentCaptor<Sessions>()
        verify(sessionsManager).saveSessions(newSessionsCaptor.capture(), eq(appId))
        assertEquals(sessions.copy(passwordUpdatePending = false), newSessionsCaptor.firstValue)
        verify(obsidianApi).provideSessionsManager()
        verify(obsidianApi).meManager
    }

    @Test
    fun `update password error`() = runBlockingTest {
        val body = UpdatePasswordBody("ag909ew", "iewoighowihg")
        val exception = Resources.NotFoundException()
        val mockResult = Result.Error(null, exception)
        whenever(myInfoManager.updatePassword(body)).doReturn(mockResult)

        val result = repository.updatePassword(body)

        assertTrue(result.isError)
        assertEquals(exception, (result as? Result.Error)?.exception)
        val bodyCaptor = argumentCaptor<UpdatePasswordBody>()
        verify(myInfoManager).updatePassword(bodyCaptor.capture())
        assertEquals(body, bodyCaptor.firstValue)

        verify(obsidianApi).meManager
    }

    companion object {
        val oldSessions = Sessions(
            "apiKey",
            true,
            439L,
            32902L,
            personalAccountOption = false,
            profileDetailsPending = false,
            passwordUpdatePending = true
        )
    }
}
