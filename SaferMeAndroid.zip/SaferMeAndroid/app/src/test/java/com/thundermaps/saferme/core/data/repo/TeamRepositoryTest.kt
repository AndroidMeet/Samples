package com.thundermaps.saferme.core.data.repo

import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.StateManager
import com.saferme.obsidian.TeamManager
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.domain.AppIdProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class TeamRepositoryTest : BaseTest() {
    private val sessionsManager: SessionsManager = mock()
    private val mockTeamManager: TeamManager = mock()
    private val stateManager: StateManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { provideSessionsManager() } doReturn sessionsManager
        on { teamManager } doReturn mockTeamManager
        on { stateManager } doReturn stateManager
    }
    private val appIdProvider = AppIdProvider()
    private lateinit var repository: TeamRepository

    @Before
    fun setup() {
        repository = TeamRepositoryImpl(obsidianApi, appIdProvider)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(obsidianApi, sessionsManager, stateManager)
    }

    @Test
    fun `verify sync team`() = runBlockingTest {
        repository.syncTeam()

        verify(mockTeamManager).syncTeam()
        verify(obsidianApi, times(2)).teamManager
    }

    @Test
    fun `verify update session`() = runBlockingTest {
        val sessions = Sessions(
            "apiKey",
            true,
            null,
            32902L,
            personalAccountOption = false,
            profileDetailsPending = true,
            passwordUpdatePending = false
        )
        val teamId = 3290L
        val copiedSessions: Sessions = sessions.copy(teamId = teamId)

        whenever(sessionsManager.getSessions()).doReturn(sessions)

        val result = repository.selectTeam(teamId)
        assertEquals(copiedSessions, result)

        verify(obsidianApi).teamManager
        verify(obsidianApi).provideSessionsManager()
        verify(obsidianApi).stateManager
        verify(sessionsManager).getSessions()
        verify(sessionsManager).saveSessions(copiedSessions, appIdProvider.appId)
        val teamIdArgumentCaptor = argumentCaptor<Int>()
        verify(stateManager).switchTeamAndSyncStates(teamIdArgumentCaptor.capture())
        assertEquals(teamId.toInt(), teamIdArgumentCaptor.firstValue)
    }
}
