package com.thundermaps.saferme.features.authentication.updatepassword.domain

import com.nulabinc.zxcvbn.Zxcvbn
import org.junit.Assert.assertEquals
import org.junit.Test

class PasswordCalculatorTest {
    private val calculator: Zxcvbn = Zxcvbn()
    private val passwordCalculator: PasswordCalculator = PasswordCalculatorImpl(calculator)
    @Test
    fun `verify too weak password`() {
        val level = passwordCalculator.measurePassword("abcdef")
        assertEquals(PasswordStrengthLevel.TOO_WEAK, level)
    }

    @Test
    fun `verify weak password`() {
        val level = passwordCalculator.measurePassword("abcdeF")
        assertEquals(PasswordStrengthLevel.WEAK, level)
    }

    @Test
    fun `verify medium password`() {
        val level = passwordCalculator.measurePassword("2902jio")
        assertEquals(PasswordStrengthLevel.MEDIUM, level)
    }

    @Test
    fun `verify strong password`() {
        val level = passwordCalculator.measurePassword("Ab#cd3Faj92@()()")
        assertEquals(PasswordStrengthLevel.STRONG, level)
    }
}
