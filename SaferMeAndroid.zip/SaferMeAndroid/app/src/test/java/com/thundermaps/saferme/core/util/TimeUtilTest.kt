package com.thundermaps.saferme.core.util

import com.thundermaps.saferme.core.util.TimeUtil.toMediumDateInString
import com.thundermaps.saferme.core.util.TimeUtil.toShortTimeInString
import io.mockk.every
import io.mockk.mockkObject
import io.mockk.unmockkAll
import java.util.Calendar
import java.util.Locale
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

class TimeUtilTest {
    @Before
    fun setUp() {
        Locale.setDefault(Locale.ENGLISH)
        mockkObject(TimeUtil)
        every { TimeUtil.convertIsoDateStringToDate(DATE1_IN_STRING) } returns DATE1
        every { TimeUtil.convertIsoDateStringToDate(DATE2_IN_STRING) } returns DATE2
    }

    @Test
    fun testConvertStringToDate() {
        val date = TimeUtil.convertIsoDateStringToDate(DATE1_IN_STRING)

        assertEquals(DATE1, date)

        val date1 = TimeUtil.convertIsoDateStringToDate("2021-05-11T13:45:14+13:00")
        assertNull(date1)
    }

    @Test
    fun testConvertShortTime() {
        val time = DATE1.toShortTimeInString()
        assertEquals("10:45AM", time)

        val time2 = DATE2.toShortTimeInString()
        assertEquals("01:45PM", time2)
    }

    @Test
    fun testConvertMediumDate() {
        val date = DATE1.toMediumDateInString()
        assertEquals("Oct 11, 2021", date)

        val date1 = DATE2.toMediumDateInString()
        assertEquals("Nov 11, 2021", date1)
    }

    @After
    fun tearDown() {
        unmockkAll()
    }

    companion object {
        private const val DATE1_IN_STRING = "2021-10-11T10:45:14+13:00"
        private const val DATE2_IN_STRING = "2021-11-11T13:45:14+13:00"

        private val DATE1 = Calendar.getInstance().apply {
            set(2021, 9, 11, 10, 45)
        }.time

        private val DATE2 = Calendar.getInstance().apply {
            set(2021, 10, 11, 13, 45)
        }.time
    }
}
