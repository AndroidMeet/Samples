package com.thundermaps.saferme.features.authentication.updatepassword.domain

import com.thundermaps.saferme.R
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PasswordStrengthLevelTest {
    @Test
    fun `verify too weak level`() {
        val status = PasswordStrengthLevel.TOO_WEAK
        assertEquals(0f, status.percentageWidth)
        assertNull(status.colorRes)
        assertEquals(R.string.password_status_too_weak, status.text)
    }

    @Test
    fun `verify weak level`() {
        val status = PasswordStrengthLevel.WEAK
        assertEquals(1f / 3f, status.percentageWidth)
        assertEquals(R.color.password_weak, status.colorRes)
        assertEquals(R.string.password_status_weak, status.text)
    }

    @Test
    fun `verify medium level`() {
        val status = PasswordStrengthLevel.MEDIUM
        assertEquals(2f / 3f, status.percentageWidth)
        assertEquals(R.color.password_medium, status.colorRes)
        assertEquals(R.string.password_status_medium, status.text)
    }

    @Test
    fun `verify strong level`() {
        val status = PasswordStrengthLevel.STRONG
        assertEquals(1f, status.percentageWidth)
        assertEquals(R.color.password_strong, status.colorRes)
        assertEquals(R.string.password_status_strong, status.text)
    }

    @Test
    fun `verify minLevel`() {
        assertEquals(PasswordStrengthLevel.TOO_WEAK, PasswordStrengthLevel.minLevel)
    }

    @Test
    fun `verify level is too weak by score less than 0`() {
        assertEquals(PasswordStrengthLevel.TOO_WEAK, PasswordStrengthLevel.ofLevel(-1))
    }

    @Test
    fun `verify level is too weak by score = 0`() {
        assertEquals(PasswordStrengthLevel.TOO_WEAK, PasswordStrengthLevel.ofLevel(0))
    }

    @Test
    fun `verify level is weak by score = 1`() {
        assertEquals(PasswordStrengthLevel.WEAK, PasswordStrengthLevel.ofLevel(1))
    }

    @Test
    fun `verify level is medium by score = 2`() {
        assertEquals(PasswordStrengthLevel.MEDIUM, PasswordStrengthLevel.ofLevel(2))
    }

    @Test
    fun `verify level is strong by score = 3`() {
        assertEquals(PasswordStrengthLevel.STRONG, PasswordStrengthLevel.ofLevel(3))
    }

    @Test
    fun `verify level is strong by score greater than 3`() {
        assertEquals(PasswordStrengthLevel.STRONG, PasswordStrengthLevel.ofLevel(4))
    }
}
