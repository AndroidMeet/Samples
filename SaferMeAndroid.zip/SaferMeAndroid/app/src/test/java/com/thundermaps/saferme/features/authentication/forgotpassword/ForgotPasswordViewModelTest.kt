package com.thundermaps.saferme.features.authentication.forgotpassword

import android.app.Application
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.thundermaps.apilib.android.api.requests.models.EmailBody
import com.thundermaps.apilib.android.api.resources.SessionsResource
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.AppIdProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class ForgotPasswordViewModelTest : BaseTest() {
    private val app: Application = mock {
        on { getString(R.string.login_email) } doReturn EMAIL_LABEL
        on { getString(R.string.login_email_empty_error) } doReturn EMPTY_EMAIL_ERROR
        on { getString(R.string.login_email_invalid) } doReturn INVALID_EMAIL_ERROR
    }
    private val sessionsResource: SessionsResource = mock()
    private val dispatcherContext = TestContextProvider()
    private val appIdProvider = AppIdProvider()
    private lateinit var viewModel: ForgotPasswordViewModel

    @Before
    fun setUp() {
        viewModel = ForgotPasswordViewModel(app, sessionsResource, dispatcherContext, appIdProvider)
    }

    @After
    fun tearDown() {
        verify(app).getString(R.string.login_email)
        verifyNoMoreInteractions(app, sessionsResource)
    }

    @Test
    fun `check empty email`() {
        viewModel.emailInput.text.value = ""

        viewModel.checkEmail()

        viewModel.emailInput.error.observeForTesting {
            assertFalse(viewModel.emailInput.error.value.isNullOrEmpty())
        }
        assertEquals(EMPTY_EMAIL_ERROR, viewModel.emailInput.error.value)
        verify(app).getString(R.string.login_email_invalid)
        verify(app).getString(R.string.login_email_empty_error)
        viewModel.isResetPasswordEnabled.observeForTesting {
            assertFalse(viewModel.isResetPasswordEnabled.value!!)
        }
    }

    @Test
    fun `check invalid email`() {
        viewModel.emailInput.text.value = "test@gawiiw"

        viewModel.checkEmail()

        viewModel.emailInput.error.observeForTesting {
            assertFalse(viewModel.emailInput.error.value.isNullOrEmpty())
        }
        assertEquals(INVALID_EMAIL_ERROR, viewModel.emailInput.error.value)
        verify(app).getString(R.string.login_email_invalid)
        verify(app).getString(R.string.login_email_empty_error)
        viewModel.isResetPasswordEnabled.observeForTesting {
            assertFalse(viewModel.isResetPasswordEnabled.value!!)
        }
    }

    @Test
    fun `check valid email`() {
        viewModel.emailInput.text.value = "test@gmail.com"

        viewModel.checkEmail()

        verify(app).getString(R.string.login_email_invalid)
        verify(app).getString(R.string.login_email_empty_error)

        viewModel.emailInput.error.observeForTesting {
            assertTrue(viewModel.emailInput.error.value.isNullOrEmpty())
        }

        viewModel.isResetPasswordEnabled.observeForTesting {
            assertTrue(viewModel.isResetPasswordEnabled.value!!)
        }
    }

    @Test
    fun `request change password success`() =
        dispatcherContext.testCoroutineDispatcher.runBlockingTest {
            val email = "test@gmail.com"
            val emailBody = EmailBody(email)
            val mockResult = Result.Success(email)
            whenever(sessionsResource.requestPassword(emailBody, appIdProvider.appId)).doReturn(
                mockResult
            )
            viewModel.emailInput.text.value = email

            viewModel.requestChangePassword()

            viewModel.requestStatus.observeForTesting {
                val result = viewModel.requestStatus.value
                assertEquals(mockResult, result)
            }

            val bodyCaptor = argumentCaptor<EmailBody>()
            val appIdCaptor = argumentCaptor<String>()
            verify(sessionsResource).requestPassword(bodyCaptor.capture(), appIdCaptor.capture())
            assertEquals(emailBody, bodyCaptor.firstValue)
            assertEquals(appIdProvider.appId, appIdCaptor.firstValue)
        }

    @Test
    fun `request change password error`() =
        dispatcherContext.testCoroutineDispatcher.runBlockingTest {
            val email = "test@gmail.com"
            val emailBody = EmailBody(email)
            val exception = Exception()
            val mockResult = Result.Error(null, exception)
            whenever(sessionsResource.requestPassword(emailBody, appIdProvider.appId)).doReturn(
                mockResult
            )
            viewModel.emailInput.text.value = email

            viewModel.requestChangePassword()

            viewModel.requestStatus.observeForTesting {
                val result = viewModel.requestStatus.value
                assertTrue(result!!.isError)
                assertEquals(mockResult, result)
            }

            val bodyCaptor = argumentCaptor<EmailBody>()
            val appIdCaptor = argumentCaptor<String>()
            verify(sessionsResource).requestPassword(bodyCaptor.capture(), appIdCaptor.capture())
            assertEquals(emailBody, bodyCaptor.firstValue)
            assertEquals(appIdProvider.appId, appIdCaptor.firstValue)
        }

    companion object {
        private const val EMAIL_LABEL = "Email"
        private const val EMPTY_EMAIL_ERROR = "Please enter your email"
        private const val INVALID_EMAIL_ERROR = "Email address is not valid"
    }
}
