package com.thundermaps.saferme.core.domain.utils

import com.saferme.obsidian.store.resources.ObsidianTeam
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GenericDiffTest {
    @Test
    fun `verify two lists are the same`() {
        val oldList = listOf(mockTeam1)
        val newList = listOf(mockTeam2)

        val genericDiff = GenericDiff(oldList, newList)

        assertEquals(1, genericDiff.oldListSize)
        assertEquals(1, genericDiff.newListSize)
        assertTrue(genericDiff.areContentsTheSame(0, 0))
        assertTrue(genericDiff.areItemsTheSame(0, 0))
    }

    @Test
    fun `verify two lists are the different`() {
        val oldList = listOf(mockTeam)
        val newList = listOf(mockTeam, mockTeam2)

        val genericDiff = GenericDiff(oldList, newList)

        assertEquals(1, genericDiff.oldListSize)
        assertEquals(2, genericDiff.newListSize)
        assertTrue(genericDiff.areContentsTheSame(0, 0))
        assertTrue(genericDiff.areItemsTheSame(0, 0))
        assertFalse(genericDiff.areContentsTheSame(0, 1))
        assertFalse(genericDiff.areItemsTheSame(0, 1))
    }

    companion object {
        private val mockTeam = ObsidianTeam(
            contactTracingEnabled = false,
            featureTasksEnabled = true,
            formContactTracingEnabled = false,
            guestsEnabled = false,
            id = 6129L,
            industry = null,
            location = null,
            name = "MT Test2",
            riskRegisterEnabled = true,
            ssoRequired = false,
            ssoTeamId = "en1owl6sq3c",
            userTimeout = null,
            wearablesEnabled = false,
            isAdmin = null,
            isManager = null,
            isOwner = null,
            mapboxAccessToken = null,
            mapboxDataSetId = null,
            mapboxUserName = null
        )

        private val mockTeam1 = mockTeam.copy(id = 2L)

        private val mockTeam2 = mockTeam.copy(id = 2L)
    }
}
