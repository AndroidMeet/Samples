package com.thundermaps.saferme

import androidx.lifecycle.MutableLiveData
import com.google.firebase.iid.FirebaseInstanceId
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.CategoryManager
import com.saferme.obsidian.ChannelManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.StateManager
import com.saferme.obsidian.TaskManager
import com.saferme.obsidian.TeamManager
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.saferme.obsidian.sync.resources.ReportSync
import com.saferme.obsidian.sync.resources.TaskSync
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.models.MapType
import com.thundermaps.saferme.core.ui.input.CheckBoxInput
import com.thundermaps.saferme.core.usecase.MapOptionsUseCase
import com.thundermaps.saferme.core.usecase.ReportUseCase
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase
import com.thundermaps.saferme.features.authentication.AuthenticationRepository
import com.thundermaps.saferme.features.main.MainViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@ExperimentalCoroutinesApi
class MainViewModelTest : BaseTest() {
    private val reportUseCase = ReportUseCase()
    private lateinit var viewModel: MainViewModel
    private val searchAddressUseCase: SearchAddressUseCase = mock {
        on { address } doReturn MutableLiveData(ADDRESS)
    }
    private val testContextProvider = TestContextProvider()
    private val repo = mock<AuthenticationRepository>()
    private val mapOptionsUseCase: MapOptionsUseCase = mock()
    private val channelManager: ChannelManager = mock()
    private val categoryManager: CategoryManager = mock()
    private val reportSync: ReportSync = mock()
    private val taskSync: TaskSync = mock()
    private val firebaseInstanceId: FirebaseInstanceId = mock()
    private val reportManager: ReportManager = mock {
        on { reportSync } doReturn reportSync
    }
    private val taskManager: TaskManager = mock {
        on { TaskSync() } doReturn taskSync
    }
    private val teamManager: TeamManager = mock()
    private val stateManager: StateManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { categoryManager } doReturn categoryManager
        on { channelsManager } doReturn channelManager
        on { reportManager } doReturn reportManager
        on { Tasks() } doReturn taskManager
        on { teamManager } doReturn teamManager
        on { stateManager } doReturn stateManager
    }

    @After
    fun tearDown() {
        verify(searchAddressUseCase).address
        verify(mapOptionsUseCase).mapType
        verify(mapOptionsUseCase).isOpeningMapOption
        verify(mapOptionsUseCase).loadEnabledChannels()
        verifyNoMoreInteractions(
            searchAddressUseCase,
            repo,
            mapOptionsUseCase,
            obsidianApi,
            categoryManager,
            channelManager,
            reportSync,
            reportManager,
            taskManager,
            taskSync,
            teamManager,
            stateManager
        )
    }

    private fun createViewModel() {
        viewModel = MainViewModel(
            repo,
            reportUseCase,
            searchAddressUseCase,
            mapOptionsUseCase,
            obsidianApi,
            testContextProvider,
            firebaseInstanceId
        )
    }

    @Test
    fun `will create report is false when start`() {
        createViewModel()

        assertFalse(viewModel.reporting.value!!)
        assertEquals(ADDRESS, viewModel.address.value)
    }

    @Test
    fun `invoke willCreateReport and map option is opening then reporting will be true and close map option`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(MutableLiveData(true))

        createViewModel()

        viewModel.openReportBottomView()

        reportUseCase.showingReport.observeForTesting {
            assertTrue(reportUseCase.showingReport.value!!)
        }

        verify(searchAddressUseCase).clearSearchSuggestion()
        verify(mapOptionsUseCase).closeMapOptions()
    }

    @Test
    fun `invoke willCreateReport and map option is closed then reporting will be true`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(MutableLiveData(false))

        createViewModel()

        viewModel.openReportBottomView()

        reportUseCase.showingReport.observeForTesting {
            assertTrue(reportUseCase.showingReport.value!!)
        }
        verify(searchAddressUseCase).clearSearchSuggestion()
    }

    @Test
    fun `invoke closeReport then value will be true`() {
        createViewModel()

        viewModel.closeReportView()
        reportUseCase.showingReport.observeForTesting {
            assertFalse(reportUseCase.showingReport.value!!)
        }
    }

    @Test
    fun `invoke getUserDetailsIfNeeded`() = runBlockingTest {
        createViewModel()

        viewModel.getUserDetailsIfNeeded()

        verify(repo).getUserDetailsIfNeeded()
    }

    @Test
    fun `invoke getClientsIfNeeded`() = runBlockingTest {
        createViewModel()

        viewModel.getClientsIfNeeded()

        verify(repo).getClientsIfNeeded()
    }

    @Test
    fun `set road map`() {
        createViewModel()

        viewModel.selectMapRoad()

        verifySelectedMap(MapType.ROAD)
    }

    @Test
    fun `set satellite map`() {
        createViewModel()

        viewModel.selectMapSatellite()

        verifySelectedMap(MapType.SATELLITE)
    }

    private fun verifySelectedMap(mapType: MapType) {
        val argumentCaptor = argumentCaptor<MapType>()
        verify(mapOptionsUseCase).updateMapType(argumentCaptor.capture())

        assertEquals(mapType, argumentCaptor.firstValue)
    }

    @Test
    fun `verify close map options`() {
        createViewModel()

        viewModel.closeMapOptions()

        verify(mapOptionsUseCase).closeMapOptions()
    }

    @Test
    fun `map type is road`() {
        val mapType = MutableLiveData(MapType.ROAD)
        whenever(mapOptionsUseCase.mapType).doReturn(mapType)

        createViewModel()

        viewModel.mapType.observeForTesting {
            assertEquals(MapType.ROAD, viewModel.mapType.value)
        }
    }

    @Test
    fun `map type is satellite`() {
        val mapType = MutableLiveData(MapType.SATELLITE)
        whenever(mapOptionsUseCase.mapType).doReturn(mapType)

        createViewModel()

        viewModel.mapType.observeForTesting {
            assertEquals(MapType.SATELLITE, viewModel.mapType.value)
        }
    }

    @Test
    fun `verify opening map options`() {
        val isOpening = MutableLiveData(true)
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(isOpening)

        createViewModel()

        viewModel.openingMapOptions.observeForTesting {
            assertTrue(viewModel.openingMapOptions.value!!)
        }
    }

    @Test
    fun `verify not opening map options`() {
        val isOpening = MutableLiveData(false)
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(isOpening)

        createViewModel()

        viewModel.openingMapOptions.observeForTesting {
            assertFalse(viewModel.openingMapOptions.value!!)
        }
    }

    @Test
    fun `verify is not showing bottom view when opening map option`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(true))

        createViewModel()

        assertFalse(viewModel.isNotShowingBottomView)
    }

    @Test
    fun `verify is not showing bottom view when reporting`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))

        reportUseCase.activateReport()

        createViewModel()

        assertFalse(viewModel.isNotShowingBottomView)
    }

    @Test
    fun `verify is not showing bottom view`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))

        createViewModel()

        assertTrue(viewModel.isNotShowingBottomView)
    }

    @Test
    fun `verify get channels`() = runBlockingTest {
        val channels = listOf(channel1, channel2)
        whenever(mapOptionsUseCase.loadChannels()).doReturn(channels)
        createViewModel()

        viewModel.loadChannel()

        viewModel.channelInputs.observeForTesting {
            viewModel.channelInputs.value?.let { inputs ->
                assertEquals(2, inputs.size)
                assertCheckboxInput(
                    CheckBoxInput(channel1.id, channel1.name, channel1.pinEnable),
                    inputs.first()
                )
                assertCheckboxInput(
                    CheckBoxInput(channel2.id, channel2.name, channel2.pinEnable),
                    inputs.last()
                )
            }
        }
        verify(mapOptionsUseCase).loadChannels()
    }

    @Test
    fun `verify update channel`() = runBlockingTest {
        val channelUpdate = channel1.copy(pinEnable = false)
        whenever(mapOptionsUseCase.updateChannel(channelUpdate)).thenReturn(Unit)

        `verify get channels`()

        viewModel.updateChannel(channelUpdate.id, channelUpdate.pinEnable)

        verify(mapOptionsUseCase).updateChannel(channelUpdate)
    }

    @Test
    fun `verify sync channels and categories`() = runBlockingTest {
        val channels = listOf(channel1, channel2)
        whenever(channelManager.syncChannels()).doReturn(channels)

        createViewModel()

        viewModel.syncChannelsAndCategories()

        verify(obsidianApi).channelsManager
        verify(obsidianApi).categoryManager
        verify(channelManager).syncChannels()
        val channelIdsArgumentCaptor = argumentCaptor<Int>()
        verify(categoryManager, times(2)).syncCategory(channelIdsArgumentCaptor.capture())
        assertEquals(channel1.id.toInt(), channelIdsArgumentCaptor.firstValue)
        assertEquals(channel2.id.toInt(), channelIdsArgumentCaptor.secondValue)
    }

    @Test
    fun `verify sync reports`() = runBlockingTest {
        createViewModel()

        viewModel.syncReports()

        verify(obsidianApi).reportManager
        verify(reportManager).reportSync
        verify(reportSync).synchronize()
    }

    @Test
    fun `verify sync tasks`() = runBlockingTest {
        createViewModel()

        viewModel.syncTasks()

        verify(obsidianApi).Tasks()
        verify(taskManager).TaskSync()
        verify(taskSync).synchronize()
    }

    @Test
    fun `verify sync team users`() = runBlockingTest {
        createViewModel()

        viewModel.syncTeamUsers()

        verify(obsidianApi).teamManager
        verify(teamManager).syncTeamUsers()
    }

    @Test
    fun `verify sync report states`() = runBlockingTest {
        createViewModel()

        viewModel.syncStates()

        verify(obsidianApi).stateManager
        verify(stateManager).syncStates()
    }

    private fun assertCheckboxInput(expect: CheckBoxInput, actual: CheckBoxInput) {
        assertEquals(expect.uniqueId, actual.uniqueId)
        assertEquals(expect.title, actual.title)
        assertEquals(expect.pinEnabled, actual.pinEnabled)
    }

    companion object {
        private const val ADDRESS = "Address"
        private val channel1 = ObsidianChannel(
            id = 30108L,
            allowPublicViewers = false,
            allowPublicComments = true,
            allowUserDeleteOwnReports = false,
            areNewReportsAnonymous = true,
            isBannersEnabled = false,
            categoryId = 193563L,
            description = "",
            isFormLocked = false,
            isHazardChannel = false,
            isAddonChannel = false,
            isDeletableBy = false,
            isManageableBy = true,
            isOperableBy = true,
            isReportableBy = true,
            lastReportDate = "2021-10-11T12:57:42+13:00",
            memberCount = 2,
            moderated = false,
            name = "Anonymous report",
            reportsCount = 4,
            riskControlsEditablity = "admins_only",
            slug = "Anonymous report",
            standardChannel = true,
            teamId = 459L,
            tuneInCount = 1,
            pinUrls = null,
            pinEnable = true
        )

        val channel2 = channel1.copy(id = 495L, name = "Channel 2")
    }
}
