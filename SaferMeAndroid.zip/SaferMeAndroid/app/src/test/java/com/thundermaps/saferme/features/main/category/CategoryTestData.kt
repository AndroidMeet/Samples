package com.thundermaps.saferme.features.main.category

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.saferme.obsidian.store.resources.ObsidianCategory
import com.thundermaps.apilib.android.api.responses.models.Category

internal object CategoryTestData {
    const val CHANNEL_ID = 329

    private val rawData = """
        [
          {
            "id": 193593,
            "name": "Private hazard",
            "label_name": "Report Category",
            "depth": 0,
            "pin_color": "green",
            "position": 85403,
            "parent_id": null,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198654,
            "name": "Sub1",
            "label_name": "Secondary Category",
            "depth": 1,
            "pin_color": "green",
            "position": 2,
            "parent_id": 193593,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198655,
            "name": "sub11",
            "label_name": "Tertiary Category",
            "depth": 2,
            "pin_color": "green",
            "position": 2,
            "parent_id": 198654,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198656,
            "name": "sub112",
            "label_name": null,
            "depth": 3,
            "pin_color": "green",
            "position": 2,
            "parent_id": 198655,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198657,
            "name": "sub111",
            "label_name": null,
            "depth": 3,
            "pin_color": "green",
            "position": 1,
            "parent_id": 198655,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198658,
            "name": "sub12",
            "label_name": "Tertiary Category",
            "depth": 2,
            "pin_color": "green",
            "position": 1,
            "parent_id": 198654,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198659,
            "name": "sub121",
            "label_name": null,
            "depth": 3,
            "pin_color": "green",
            "position": 2,
            "parent_id": 198658,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198660,
            "name": "sub122",
            "label_name": null,
            "depth": 3,
            "pin_color": "green",
            "position": 1,
            "parent_id": 198658,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198661,
            "name": "sub2",
            "label_name": "Secondary Category",
            "depth": 1,
            "pin_color": "green",
            "position": 1,
            "parent_id": 193593,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198662,
            "name": "sub21",
            "label_name": "Tertiary Category",
            "depth": 2,
            "pin_color": "green",
            "position": 3,
            "parent_id": 198661,
            "channel_id": $CHANNEL_ID
          },
          {
            "id": 198663,
            "name": "sub22",
            "label_name": "Tertiary Category",
            "depth": 2,
            "pin_color": "green",
            "position": 2,
            "parent_id": 198661,
            "channel_id":  $CHANNEL_ID
          },
          {
            "id": 198664,
            "name": "sub23",
            "label_name": "Tertiary Category",
            "depth": 2,
            "pin_color": "green",
            "position": 1,
            "parent_id": 198661,
            "channel_id":  $CHANNEL_ID
          }
        ]
    """.trimIndent()

    val categories: List<ObsidianCategory> =
        Gson().fromJson<List<Category>?>(rawData, object : TypeToken<List<Category>>() {}.type)
            .map { ObsidianCategory.of(it, CHANNEL_ID) }
}
