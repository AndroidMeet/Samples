package com.thundermaps.saferme.features.main.settings.domain

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import java.lang.reflect.Field
import java.lang.reflect.Modifier
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.Mock

@ExperimentalCoroutinesApi
class DeviceDetailsRepositoryImplTest {
    @Mock
    private lateinit var repo: DeviceDetailsRepositoryImpl

    @Mock
    private lateinit var mockContext: Context

    @Mock
    private val packageManager: PackageManager = mock {
        on { getPackageInfo(PACKAGE_NAME, 0) } doReturn packageInfo
    }

    @Mock
    private val packageInfo: PackageInfo = mock {
        this.mock.versionName = APP_VERSION
        this.mock.versionCode = APP_BUILD
    }

    @Before
    fun setUp() {
        mockContext = mock {
            on { packageManager } doReturn packageManager
        }
        repo = mock {
            on { getDeviceDetails() } doReturn DEVICE_DETAILS
        }
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(repo)
    }

    @Test
    fun `load device details`() {
        val deviceDetails = repo.getDeviceDetails()

        assertEquals(deviceDetails.appVersion, packageInfo.versionName)
        assertEquals(deviceDetails.appBuild.toInt(), packageInfo.versionCode)
        assertEquals(deviceDetails.deviceModel, "$DEVICE_NAME $DEVICE_MODEL")
        assertEquals(deviceDetails.deviceVersion, "$ANDROID $DEVICE_OS")

        verify(repo).getDeviceDetails()
    }

    companion object {
        private const val PACKAGE_NAME = "packageName"
        private const val ANDROID = "Android"
        private const val DEVICE_NAME = "Safer"
        private const val DEVICE_MODEL = "Test"
        private const val DEVICE_OS = "11"
        private const val APP_VERSION = "1.0"
        private const val APP_BUILD = 1
        private val DEVICE_DETAILS = DeviceDetails(
            APP_VERSION,
            APP_BUILD.toString(),
            "$DEVICE_NAME $DEVICE_MODEL",
            "$ANDROID $DEVICE_OS"
        )

        @Throws(Exception::class)
        fun setFinalStatic(field: Field, newValue: Any?) {
            field.isAccessible = true
            val modifiersField: Field = Field::class.java.getDeclaredField("modifiers")
            modifiersField.isAccessible = true
            modifiersField.setInt(field, field.modifiers and Modifier.FINAL.inv())
            field.set(null, newValue)
        }
    }
}
