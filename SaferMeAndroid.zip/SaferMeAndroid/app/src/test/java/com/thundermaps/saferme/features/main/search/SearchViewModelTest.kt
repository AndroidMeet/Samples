package com.thundermaps.saferme.features.main.search

import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.domain.models.SmSearchSuggestion
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class SearchViewModelTest : BaseTest() {
    private val testContextProvider = TestContextProvider()
    private val searchSuggestions = MutableLiveData(listOf<SmSearchSuggestion>())

    private val searchAddressUseCase: SearchAddressUseCase = mock {
        on { saferMeSearchSuggestions } doReturn searchSuggestions
    }
    private lateinit var searchViewModel: SearchViewModel

    @Before
    fun setUp() {
        searchViewModel = SearchViewModel(searchAddressUseCase, testContextProvider)
    }

    @After
    fun tearDown() {
        assertEquals(searchViewModel.suggestions, searchSuggestions)
        verify(searchAddressUseCase).saferMeSearchSuggestions
        verifyNoMoreInteractions(searchAddressUseCase)
    }

    @Test
    fun `verify search text`() {
        val query = "139 Papanui Road"
        searchViewModel.searchText(query)

        val textCaptor = argumentCaptor<String>()
        verify(searchAddressUseCase).didSearch(textCaptor.capture())

        assertEquals(query, textCaptor.firstValue)
    }

    @Test
    fun `verify did search selected`() {
        val smSearchSuggestion = mock<SmSearchSuggestion>()

        searchViewModel.didSearchSelected(smSearchSuggestion)

        val searchSuggestionCaptor = argumentCaptor<SmSearchSuggestion>()
        verify(searchAddressUseCase).didSelectSearchSuggestion(searchSuggestionCaptor.capture())
        assertEquals(smSearchSuggestion, searchSuggestionCaptor.firstValue)
        verifyNoMoreInteractions(smSearchSuggestion)
    }

    @Test
    fun `verify start search`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        searchViewModel.startSearch()
        verify(searchAddressUseCase).startSearch()
    }
}
