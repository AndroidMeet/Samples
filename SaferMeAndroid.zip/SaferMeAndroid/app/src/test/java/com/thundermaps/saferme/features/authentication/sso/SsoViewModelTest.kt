package com.thundermaps.saferme.features.authentication.sso

import android.app.Application
import android.content.res.Resources
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.anyOrNull
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.apilib.android.api.resources.SessionsResource
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.apilib.android.api.responses.models.SsoDetails
import com.thundermaps.apilib.android.api.responses.models.SsoSessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.AppIdProvider
import com.thundermaps.saferme.core.ui.Screen
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class SsoViewModelTest : BaseTest() {
    private val app: Application = mock {
        on { getString(R.string.sso_organization_id) } doReturn ORGANIZATION_ID_TEXT
        on { getString(R.string.sso_error) } doReturn ERROR_MESSAGE
    }
    private val sessionsManager: SessionsManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { provideSessionsManager() } doReturn sessionsManager
    }
    private val sessionsResource: SessionsResource = mock()
    private val dispatcherContext = TestContextProvider()
    private val appIdProvider = AppIdProvider()

    private lateinit var ssoViewModel: SsoViewModel

    @Before
    fun setUp() {
        ssoViewModel = SsoViewModel(
            app,
            obsidianApi,
            sessionsResource,
            dispatcherContext,
            appIdProvider
        )
    }

    @After
    fun tearDown() {
        verify(app).getString(R.string.sso_organization_id)
        verifyNoMoreInteractions(app, obsidianApi, sessionsResource)
    }

    @Test
    fun `enabled continue after enter text`() = runBlockingTest {
        ssoViewModel.organizationIdInput.text.value = SSO_ID

        ssoViewModel.isLoginSsoEnabled.observeForTesting {
            assertTrue(ssoViewModel.isLoginSsoEnabled.value!!)
        }
    }

    @Test
    fun `verify sso details success`() = dispatcherContext.testCoroutineDispatcher.runBlockingTest {
        ssoViewModel.organizationIdInput.text.value = SSO_ID

        val mockResult = Result.Success(ssoDetailsMock)
        whenever(sessionsResource.getSsoDetails(any(), any())).doReturn(mockResult)

        ssoViewModel.loadSsoDetails()

        val ssoIdCaptor = argumentCaptor<String>()
        val applicationIdCaptor = argumentCaptor<String>()
        verify(sessionsResource).getSsoDetails(ssoIdCaptor.capture(), applicationIdCaptor.capture())
        assertEquals(SSO_ID, ssoIdCaptor.firstValue)
        assertEquals(appIdProvider.appId, applicationIdCaptor.firstValue)
        ssoViewModel.ssoDetails.observeForTesting {
            val resultSsoDetails = ssoViewModel.ssoDetails.value
            assertTrue(resultSsoDetails?.isSuccess!!)
            assertEquals(ssoDetailsMock, resultSsoDetails.getNullableData())
        }
        ssoViewModel.progressSsoLogin.observeForTesting {
            assertTrue(ssoViewModel.progressSsoLogin.value?.isSuccess!!)
        }
    }

    @Test
    fun `verify sso details error from server`() =
        dispatcherContext.testCoroutineDispatcher.runBlockingTest {
            ssoViewModel.organizationIdInput.text.value = SSO_ID

            val exception = Exception()
            val mockResult = Result.Error(null, exception)
            whenever(sessionsResource.getSsoDetails(any(), any())).doReturn(mockResult)

            ssoViewModel.loadSsoDetails()

            val ssoIdCaptor = argumentCaptor<String>()
            val applicationIdCaptor = argumentCaptor<String>()
            verify(sessionsResource).getSsoDetails(
                ssoIdCaptor.capture(),
                applicationIdCaptor.capture()
            )
            assertEquals(SSO_ID, ssoIdCaptor.firstValue)
            assertEquals(appIdProvider.appId, applicationIdCaptor.firstValue)
            ssoViewModel.ssoDetails.observeForTesting {
                val resultSsoDetails = ssoViewModel.ssoDetails.value
                assertTrue(resultSsoDetails?.isError!!)
                assertEquals(exception, (resultSsoDetails as Result.Error).exception)
            }
            ssoViewModel.progressSsoLogin.observeForTesting {
                val status = ssoViewModel.progressSsoLogin.value
                assertTrue(status?.isError!!)
                assertEquals(exception, (status as Result.Error).exception)
            }
            ssoViewModel.isLoginSsoEnabled.observeForTesting {
                assertFalse(ssoViewModel.isLoginSsoEnabled.value!!)
            }
            verify(app).getString(R.string.sso_error)
        }

    @Test
    fun `verify sso details error unexpected`() =
        dispatcherContext.testCoroutineDispatcher.runBlockingTest {
            ssoViewModel.organizationIdInput.text.value = SSO_ID

            val exception = Resources.NotFoundException()
            whenever(sessionsResource.getSsoDetails(any(), any())).thenThrow(exception)

            ssoViewModel.loadSsoDetails()

            val ssoIdCaptor = argumentCaptor<String>()
            val applicationIdCaptor = argumentCaptor<String>()
            verify(sessionsResource).getSsoDetails(
                ssoIdCaptor.capture(),
                applicationIdCaptor.capture()
            )
            assertEquals(SSO_ID, ssoIdCaptor.firstValue)
            assertEquals(appIdProvider.appId, applicationIdCaptor.firstValue)
            ssoViewModel.ssoDetails.observeForTesting {
                val resultSsoDetails = ssoViewModel.ssoDetails.value
                assertTrue(resultSsoDetails?.isError!!)
                assertEquals(exception, (resultSsoDetails as Result.Error).exception)
            }
            ssoViewModel.progressSsoLogin.observeForTesting {
                val status = ssoViewModel.progressSsoLogin.value
                assertTrue(status?.isError!!)
                assertEquals(exception, (status as Result.Error).exception)
            }
            ssoViewModel.isLoginSsoEnabled.observeForTesting {
                assertFalse(ssoViewModel.isLoginSsoEnabled.value!!)
            }
            verify(app).getString(R.string.sso_error)
        }

    @Test
    fun `verify get sso sessions success`() =
        dispatcherContext.testCoroutineDispatcher.runBlockingTest {
            `verify sso details success`()
            val resultMock: Result<SsoSessions> = Result.Success(ssoSessionsMock)
            val code = "aigwoigoiw"
            whenever(sessionsResource.getSsoSessions(any(), any(), any(), anyOrNull())).doReturn(
                resultMock
            )

            ssoViewModel.loadSsoSessions(code)

            val codeCaptor = argumentCaptor<String>()
            val applicationCaptor = argumentCaptor<String>()
            val ssoDetailsCaptor = argumentCaptor<SsoDetails>()
            val nonceCaptor = argumentCaptor<String>()
            verify(sessionsResource).getSsoSessions(
                codeCaptor.capture(),
                applicationCaptor.capture(),
                ssoDetailsCaptor.capture(),
                nonceCaptor.capture()
            )
            assertEquals(code, codeCaptor.firstValue)
            assertEquals(appIdProvider.appId, applicationCaptor.firstValue)
            assertEquals(ssoDetailsMock, ssoDetailsCaptor.firstValue)
            assertEquals(ssoViewModel.nonce, nonceCaptor.firstValue)

            ssoViewModel.progressSsoLogin.observeForTesting {
                assertTrue(ssoViewModel.progressSsoLogin.value?.isSuccess!!)
            }

            verify(obsidianApi).provideSessionsManager()
            val sessionsCaptor = argumentCaptor<Sessions>()
            verify(sessionsManager).saveSessions(
                sessionsCaptor.capture(),
                applicationCaptor.capture()
            )
            assertEquals(appIdProvider.appId, applicationCaptor.secondValue)
            assertEquals(ssoSessionsMock.session, sessionsCaptor.firstValue)

            ssoViewModel.nextScreen.observeForTesting {
                assertEquals(Screen.MAP, ssoViewModel.nextScreen.value)
            }
            ssoViewModel.isLoginSsoEnabled.observeForTesting {
                assertTrue(ssoViewModel.isLoginSsoEnabled.value!!)
            }
        }

    @Test
    fun `verify get sso sessions error`() =
        dispatcherContext.testCoroutineDispatcher.runBlockingTest {
            `verify sso details success`()
            val exception = Exception()
            val resultMock: Result<SsoSessions> = Result.Error(null, exception)
            val code = "aigwoigoiw"
            whenever(sessionsResource.getSsoSessions(any(), any(), any(), anyOrNull())).doReturn(
                resultMock
            )

            ssoViewModel.loadSsoSessions(code)

            val codeCaptor = argumentCaptor<String>()
            val applicationCaptor = argumentCaptor<String>()
            val ssoDetailsCaptor = argumentCaptor<SsoDetails>()
            val nonceCaptor = argumentCaptor<String>()
            verify(sessionsResource).getSsoSessions(
                codeCaptor.capture(),
                applicationCaptor.capture(),
                ssoDetailsCaptor.capture(),
                nonceCaptor.capture()
            )
            assertEquals(code, codeCaptor.firstValue)
            assertEquals(appIdProvider.appId, applicationCaptor.firstValue)
            assertEquals(ssoDetailsMock, ssoDetailsCaptor.firstValue)
            assertEquals(ssoViewModel.nonce, nonceCaptor.firstValue)

            ssoViewModel.progressSsoLogin.observeForTesting {
                val status = ssoViewModel.progressSsoLogin.value
                assertTrue(status?.isError!!)
                assertEquals(exception, (status as Result.Error).exception)
            }
            ssoViewModel.isLoginSsoEnabled.observeForTesting {
                assertFalse(ssoViewModel.isLoginSsoEnabled.value!!)
            }
            verify(app).getString(R.string.sso_error)
        }

    @Test
    fun `verify clear nonce and state`() {
        ssoViewModel.clearNonceAndState()

        assertNull(ssoViewModel.nonce)
        assertNull(ssoViewModel.state)
    }

    companion object {
        private const val SSO_ID = "rwioir_rioirweoi"
        private const val ORGANIZATION_ID_TEXT = "Organization ID"
        private const val ERROR_MESSAGE = "Incorrect organization ID, try again."
        private const val AUTHORIZE_URI =
            "https://login.microsoftonline.com/282e54cb-3b4c-4641-80a8-32903203fc4d/oauth2/v2.0/authorize?client_id=354c253e-5d6c-4314-bd76-329032036603&response_type=code&scope=openid"
        private val ssoDetailsMock = SsoDetails(
            status = "enabled",
            ssoTeamId = SSO_ID,
            provider = "sm_azure_oauth2",
            tenantId = "282e54cb-3b4c-4641-80a8-32903203fc4d",
            clientId = "354c253e-5d6c-4314-bd76-329032036603",
            ssoScope = listOf("openid"),
            providerBaseUrl = "https://login.microsoftonline.com/282e54cb-3b4c-4641-80a8-32903203fc4d/oauth2/v2.0",
            authorizeUri = AUTHORIZE_URI,
            tokenExchangeUri = "https://api.staging.saferme.io/auth/sm_azure_oauth2/callback"
        )

        private val ssoSessionsMock = SsoSessions(
            status = "ok",
            strategy = "sm_azure_oauth2",
            Sessions(
                apiKey = "0716399c572e131951b3ad8abf82ca6f",
                clientUuid = "5afe20ad-8da2-4d72-88ac-185b9489b420",
                consentRequired = false,
                installationId = "hydra-saferme-LT8dxPWtwkHrGxKnhQOrmIYLkZkCsthu",
                teamId = 3232L,
                userId = 322323L,
                personalAccountOption = false,
                passwordUpdatePending = false,
                profileDetailsPending = false
            )
        )
    }
}
