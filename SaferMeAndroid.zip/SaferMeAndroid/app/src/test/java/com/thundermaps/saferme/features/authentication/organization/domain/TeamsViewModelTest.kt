package com.thundermaps.saferme.features.authentication.organization.domain

import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.data.repo.TeamRepository
import com.thundermaps.saferme.core.ui.Screen
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class TeamsViewModelTest : BaseTest() {
    private val obsidianTeam1: ObsidianTeam = mock()
    private val obsidianTeam: ObsidianTeam = mock()
    private val teams = listOf(obsidianTeam, obsidianTeam1)
    private val teamsLiveData = MutableLiveData(teams)
    private val teamsRepository: TeamRepository = mock {
        on { teams } doReturn teamsLiveData
    }
    private val testContextProvider = TestContextProvider()
    private lateinit var teamsViewModel: TeamsViewModel

    @Before
    fun setUp() {
        teamsViewModel = TeamsViewModel(teamsRepository, testContextProvider)
    }

    @After
    fun tearDown() {
        verify(teamsRepository).teams
        verifyNoMoreInteractions(teamsRepository, obsidianTeam1, obsidianTeam)
    }

    @Test
    fun `verify sync teams`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        teamsViewModel.syncTeams()

        verify(teamsRepository).syncTeam()
    }

    @Test
    fun `verify get teams`() {
        val result = teamsViewModel.teams

        result.observeForTesting {
            assertEquals(teamsLiveData, result)
            assertEquals(teams, result.value)
        }
    }

    @Test
    fun `verify select Team`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        val id = 329L
        val sessions = mock<Sessions> {
            on { teamId } doReturn id
            on { passwordUpdatePending } doReturn false
            on { profileDetailsPending } doReturn false
        }
        whenever(sessions.teamId).doReturn(id)

        whenever(teamsRepository.selectTeam(id)).doReturn(sessions)

        teamsViewModel.selectTeam(id)

        teamsViewModel.nextScreen.observeForTesting {
            assertEquals(Screen.MAP, teamsViewModel.nextScreen.value)
            verify(sessions).teamId
            verify(sessions).profileDetailsPending
            verify(sessions).passwordUpdatePending
            verifyNoMoreInteractions(sessions)
        }
        verify(teamsRepository).selectTeam(id)
    }
}
