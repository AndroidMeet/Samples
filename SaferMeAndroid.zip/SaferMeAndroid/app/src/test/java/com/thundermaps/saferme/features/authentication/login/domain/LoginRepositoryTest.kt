package com.thundermaps.saferme.features.authentication.login.domain

import android.content.res.Resources
import com.google.gson.Gson
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.BrandManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.apilib.android.api.requests.models.SessionBody
import com.thundermaps.apilib.android.api.requests.models.User
import com.thundermaps.apilib.android.api.resources.SessionsResource
import com.thundermaps.apilib.android.api.responses.models.ResponseError
import com.thundermaps.apilib.android.api.responses.models.ResponseException
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.AppIdProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class LoginRepositoryTest : BaseTest() {
    private val sessionsResource = mock<SessionsResource>()
    private val sessionsManager: SessionsManager = mock()
    private val brandManager: BrandManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { loginService } doReturn sessionsResource
        on { provideSessionsManager() } doReturn sessionsManager
        on { brandManager } doReturn brandManager
    }
    private val gson = Gson()
    private val accountLocker: AccountLocker = mock()

    private lateinit var loginRepository: LoginRepository
    private val appIdProvider = AppIdProvider()
    private val appId = appIdProvider.appId

    @Before
    fun setUp() {
        loginRepository = LoginRepositoryImpl(
            obsidianApi,
            accountLocker,
            appIdProvider
        )
    }

    @After
    fun tearDown() {
        verify(obsidianApi).loginService
        verify(sessionsResource).isStaging()
        verify(obsidianApi).provideSessionsManager()
        verifyNoMoreInteractions(
            obsidianApi,
            sessionsManager,
            accountLocker,
            sessionsResource,
            brandManager
        )
    }

    @Test
    fun `login success without pending then save the credential`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))
        val sessions = Sessions(
            "apiKey",
            true,
            439L,
            32902L,
            personalAccountOption = false,
            profileDetailsPending = false,
            passwordUpdatePending = false
        )
        val mockResult = Result.Success(sessions)
        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isSuccess)
        assertEquals(sessions, result.getNullableData())

        verify(sessionsManager).saveSessions(sessions, appId)

        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
        verify(accountLocker).resetLockedAccount(sessionBody.user.email)
    }

    @Test
    fun `login success with pending profile`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))
        val sessions = Sessions(
            "apiKey",
            true,
            439L,
            32902L,
            personalAccountOption = false,
            profileDetailsPending = true,
            passwordUpdatePending = false
        )
        val mockResult = Result.Success(sessions)
        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isSuccess)
        assertEquals(sessions, result.getNullableData())
        verify(sessionsManager).saveSessions(sessions, appId)

        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
        verify(accountLocker).resetLockedAccount(sessionBody.user.email)
    }

    @Test
    fun `login success with pending password`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))
        val sessions = Sessions(
            "apiKey",
            true,
            439L,
            32902L,
            personalAccountOption = false,
            profileDetailsPending = false,
            passwordUpdatePending = true
        )
        val mockResult = Result.Success(sessions)
        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isSuccess)
        assertEquals(sessions, result.getNullableData())
        verify(sessionsManager).saveSessions(sessions, appId)
        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
        verify(accountLocker).resetLockedAccount(sessionBody.user.email)
    }

    @Test
    fun `login success with pending password and profile`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))
        val sessions = Sessions(
            "apiKey",
            true,
            439L,
            32902L,
            personalAccountOption = false,
            profileDetailsPending = true,
            passwordUpdatePending = true
        )
        val mockResult = Result.Success(sessions)
        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isSuccess)
        assertEquals(sessions, result.getNullableData())
        verify(sessionsManager).saveSessions(sessions, appId)
        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
        verify(accountLocker).resetLockedAccount(sessionBody.user.email)
    }

    @Test
    fun `login with http exception`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))

        val responseException = ResponseException(
            """
            {
              "errors": [
                "Please enter your email and password"
              ],
              "failures": {
                "base": [
                  "Please enter your email and password"
                ]
              },
              "error_codes": {
                "base": [
                  {
                    "error": "bad_credentials"
                  }
                ]
              }
            }
        """.trimIndent().responseError()
        )
        val mockResult = Result.Error(null, responseException)
        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isError)

        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
        verify(accountLocker).increaseFailureTimes(sessionBody.user.email)
    }

    @Test
    fun `login error`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))

        val exception = Resources.NotFoundException()
        val mockResult = Result.Error(null, exception)

        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isError)

        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
    }

    @Test
    fun `login cancel exception`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))

        val exception = CancellationException()
        val mockResult = Result.Error(null, exception)

        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isError)

        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
    }

    @Test
    fun `login account locked error`() = runBlockingTest {
        val sessionBody = SessionBody(User("test@gmail.com", "123,54209250"))
        val responseException = ResponseException(
            """
            {
              "errors": [
                "Account locked"
              ],
              "failures": {
                "base": [
                  "Account locked"
                ]
              },
              "error_codes": {
                "base": [
                  {
                    "error": "account_locked"
                  }
                ]
              }
            }
        """.trimIndent().responseError()
        )
        val mockResult = Result.Error(null, responseException)
        whenever(sessionsResource.login(sessionBody, appId)).doReturn(mockResult)

        val result = loginRepository.login(sessionBody)

        assertTrue(result.isError)

        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(sessionsResource).login(sessionBodyCaptor.capture(), eq(appId))
        assertEquals(sessionBody, sessionBodyCaptor.firstValue)
        verify(accountLocker).lockAccount(sessionBody.user.email)
    }

    @Test
    fun `verify cached Sessions is not null`() = runBlockingTest {
        val sessions = mock<Sessions>()
        whenever(sessionsManager.getSessions()).doReturn(sessions)

        val result = loginRepository.getCacheSessions()
        assertEquals(sessions, result)

        verify(sessionsManager).getSessions()
        verifyNoMoreInteractions(sessions)
    }

    @Test
    fun `verify is locked Account`() = runBlockingTest {
        verifyAccountLocked(true)
    }

    @Test
    fun `verify is not locked Account`() = runBlockingTest {
        verifyAccountLocked(false)
    }

    @Test
    fun `verify sync brand`() = runBlockingTest {
        loginRepository.syncBrand()

        verify(obsidianApi).brandManager
        verify(brandManager).sync(appIdProvider.appId)
    }

    private suspend fun verifyAccountLocked(value: Boolean) {
        val email = "test@gmail.com"
        whenever(accountLocker.isLocked(any())).doReturn(value)
        val result = loginRepository.isAccountLocked(email)

        assertEquals(value, result)
        val emailArgumentCaptor = argumentCaptor<String>()
        verify(accountLocker).isLocked(emailArgumentCaptor.capture())
        assertEquals(email, emailArgumentCaptor.firstValue)
    }

    @Test
    fun `verify cached Sessions is null`() = runBlockingTest {
        whenever(sessionsManager.getSessions()).doReturn(null)
        val result = loginRepository.getCacheSessions()
        assertNull(result)

        verify(sessionsManager).getSessions()
    }

    @Test
    fun `verify select staging env`() {
        loginRepository.useStagingEnv()

        val stagingCaptor = argumentCaptor<Boolean>()
        verify(sessionsManager).setToStagingEnvironment(stagingCaptor.capture())
        assertTrue(stagingCaptor.firstValue)

        runBlockingTest {
            loginRepository.isStaging.observeForTesting {
                assertTrue(loginRepository.isStaging.value!!)
            }
        }
    }

    @Test
    fun `verify select live env`() {
        loginRepository.useLiveEnv()

        val stagingCaptor = argumentCaptor<Boolean>()
        verify(sessionsManager).setToStagingEnvironment(stagingCaptor.capture())
        assertFalse(stagingCaptor.firstValue)

        runBlockingTest {
            loginRepository.isStaging.observeForTesting {
                assertFalse(loginRepository.isStaging.value!!)
            }
        }
    }

    private fun String.responseError() = gson.fromJson(this, ResponseError::class.java)
}
