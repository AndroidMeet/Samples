package com.thundermaps.saferme.features.main.profile.domain

import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.TeamManager
import com.saferme.obsidian.authentication.SessionsManager
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.apilib.android.api.responses.models.Avatar
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.apilib.android.api.responses.models.UserDetails
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class ProfileRepositoryImplTest {
    private val avatarMock = mock<Avatar>()
    private val teamMock = mock<ObsidianTeam> {
        on { id } doReturn TEAM_ID
        on { name } doReturn TEAM_NAME
    }
    private val teamsMock = listOf(teamMock)
    private val userDetailsMock = mock<UserDetails> {
        on { firstName } doReturn FIRST_NAME
        on { lastName } doReturn LAST_NAME
        on { avatar } doReturn avatarMock
    }
    private val sessionsManagerMock: SessionsManager = mock()
    private val teamManagerMock: TeamManager = mock()
    private val obsidianApi = mock<ObsidianApi> {
        on { provideSessionsManager() } doReturn sessionsManagerMock
        on { teamManager } doReturn teamManagerMock
    }
    private val sessionsMock = mock<Sessions> {
        on { teamId } doReturn TEAM_ID
    }
    private lateinit var repo: ProfileRepository

    @Before
    fun setUp() {
        repo = ProfileRepositoryImpl(obsidianApi)
    }

    @Test
    fun `get profile success`() = runBlockingTest {
        whenever(sessionsManagerMock.userDetails).doReturn(userDetailsMock)
        whenever(sessionsManagerMock.getSessions()).doReturn(sessionsMock)
        whenever(teamManagerMock.getTeamsSync()).doReturn(teamsMock)

        val result = repo.getProfile().getNullableData()
        assertEquals("$FIRST_NAME $LAST_NAME", result?.name)
        assertEquals(TEAM_NAME, result?.team)
        assertEquals(avatarMock, result?.avatar)
        val expectedResult = Profile("$FIRST_NAME $LAST_NAME", TEAM_NAME, avatarMock)
        assertEquals(expectedResult, result)
        verify(sessionsMock, times(2)).teamId
        verify(teamMock).id
        verify(teamMock).name
        verify(userDetailsMock).firstName
        verify(userDetailsMock).lastName
        verify(userDetailsMock).avatar
        commonVerify()
    }

    @Test
    fun `get profile error when userDetails = null`() = runBlockingTest {
        whenever(sessionsManagerMock.userDetails).doReturn(null)
        whenever(sessionsManagerMock.getSessions()).doReturn(sessionsMock)
        whenever(teamManagerMock.getTeamsSync()).doReturn(teamsMock)

        val result = repo.getProfile()

        assertTrue(result.isError)
        assertEquals(
            ProfileRepositoryImpl.INVALIDATE_DATA_MESSAGE,
            (result as Result.Error).exception.message
        )

        verify(sessionsMock).teamId
        commonVerify()
    }

    @Test
    fun `get profile error when sessions = null`() = runBlockingTest {
        whenever(sessionsManagerMock.userDetails).doReturn(userDetailsMock)
        whenever(sessionsManagerMock.getSessions()).doReturn(null)
        whenever(teamManagerMock.getTeamsSync()).doReturn(teamsMock)

        val result = repo.getProfile()

        assertTrue(result.isError)
        assertEquals(
            ProfileRepositoryImpl.INVALIDATE_DATA_MESSAGE,
            (result as Result.Error).exception.message
        )
        commonVerify()
    }

    @Test
    fun `get profile error when teams is empty`() = runBlockingTest {
        whenever(sessionsManagerMock.userDetails).doReturn(userDetailsMock)
        whenever(sessionsManagerMock.getSessions()).doReturn(sessionsMock)
        whenever(teamManagerMock.getTeamsSync()).doReturn(emptyList())

        val result = repo.getProfile()

        assertTrue(result.isError)
        assertEquals(
            ProfileRepositoryImpl.INVALIDATE_DATA_MESSAGE,
            (result as Result.Error).exception.message
        )
        verify(sessionsMock).teamId

        commonVerify()
    }

    private suspend fun commonVerify() {
        verify(obsidianApi).provideSessionsManager()
        verify(obsidianApi).teamManager
        verify(sessionsManagerMock).userDetails
        verify(sessionsManagerMock).getSessions()
        verify(teamManagerMock).getTeamsSync()
        verify(teamManagerMock).syncTeam()
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(
            obsidianApi,
            teamManagerMock,
            sessionsManagerMock,
            userDetailsMock,
            teamMock,
            avatarMock,
            sessionsMock
        )
    }

    companion object {
        private const val TEAM_NAME = "Safer Test"
        private const val TEAM_ID = 456L
        private const val FIRST_NAME = "Joe"
        private const val LAST_NAME = "Clinton"
    }
}
