package com.thundermaps.saferme.features.main.map

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.JsonObject
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.maps.CameraState
import com.mapbox.maps.EdgeInsets
import com.mapbox.turf.TurfConstants
import com.mapbox.turf.TurfTransformation
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.BrandManager
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.ShapesManager
import com.saferme.obsidian.store.resources.ObsidianBrand
import com.saferme.obsidian.store.resources.ObsidianReport
import com.thundermaps.apilib.android.api.responses.models.Clients
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.models.CustomSearchResult
import com.thundermaps.saferme.core.domain.models.MapType
import com.thundermaps.saferme.core.usecase.MapOptionsUseCase
import com.thundermaps.saferme.core.usecase.ReportUseCase
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase.Companion.DEFAULT_POINT
import com.thundermaps.saferme.core.usecase.ShapeData
import java.util.UUID
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@ExperimentalCoroutinesApi
class MapViewModelTest : BaseTest() {
    private val app = mock<SaferMeApplication>()
    private val reportUseCase = ReportUseCase()
    private val addressLiveData: LiveData<String?> = MutableLiveData("Address")
    private val addressSearchResult: LiveData<CustomSearchResult?> = MutableLiveData(mock())
    private val clients = mock<Clients> {
        on { radius } doReturn (MapViewModel.DEFAULT_SAFETY_RADIUS_IN_KM * 1000).toFloat()
    }
    private val brandLiveData = MutableLiveData<ObsidianBrand>(mock {
        on { defaultZoom } doReturn 16.0F
    })
    private val brandManager: BrandManager = mock {
        on { getBrandAsync() } doReturn brandLiveData
    }

    private val searchAddressUseCase: SearchAddressUseCase = mock {
        on { address } doReturn addressLiveData
        on { addressSearchResult } doReturn addressSearchResult
    }

    private val shapesManager: ShapesManager = mock {}

    private val testContextProvider = TestContextProvider()

    private val mapOptionsUseCase: MapOptionsUseCase = mock {
        on { clients } doReturn clients
    }

    private val reportManager: ReportManager = mock()

    private lateinit var viewModel: MapViewModel
    private fun createViewModel() {
        viewModel = MapViewModel(
            app,
            reportUseCase,
            searchAddressUseCase,
            mapOptionsUseCase,
            brandManager,
            shapesManager,
            reportManager,
            testContextProvider
        )
    }

    @After
    fun tearDown() {
        verify(searchAddressUseCase).address
        verify(mapOptionsUseCase).mapType
        verify(mapOptionsUseCase).isOpeningMapOption
        verify(mapOptionsUseCase).selectedChannels
        verify(brandManager).getBrandAsync()
        verify(reportManager).readAllReportsByTeam()
        verify(searchAddressUseCase).shapeData
        verifyNoMoreInteractions(
            searchAddressUseCase,
            mapOptionsUseCase,
            brandManager,
            shapesManager,
            reportManager,
            app,
            clients
        )
    }

    @Test
    fun `verify default values`() {
        createViewModel()

        assertFalse(viewModel.reporting.value!!)
        assertFalse(viewModel.isGpsVisible.value!!)
        assertEquals(viewModel.cameraOptions.value, CameraOptionStorage.value)
        assertEquals(viewModel.mapZoomLevel, MapViewModel.DEFAULT_MAP_ZOOM_LEVEL, 0.0)
        assertEquals(viewModel.address.value, addressLiveData.value)
        assertFalse(viewModel.canLocateToCurrentPosition)
    }

    @Test
    fun `invoke showGpsButton then the value will be true`() {
        createViewModel()

        viewModel.showGpsButton()

        viewModel.isGpsVisible.observeForTesting {
            assertTrue(viewModel.isGpsVisible.value!!)
        }
    }

    @Test
    fun `invoke hideGpsButton then the value will be false`() {
        createViewModel()

        viewModel.hideGpsButton()

        viewModel.isGpsVisible.observeForTesting {
            assertFalse(viewModel.isGpsVisible.value!!)
        }
    }

    @Test
    fun `invoke store camera state then verify the value`() {
        createViewModel()

        viewModel.storeCameraOptions(cameraState)
        verifyStoreCameraState()
    }

    private fun verifyStoreCameraState() {
        viewModel.cameraOptions.observeForTesting {
            val resultCameraOptions = viewModel.cameraOptions.value

            assertEquals(cameraState.center, resultCameraOptions!!.center)
            assertEquals(cameraState.zoom, resultCameraOptions.zoom)
            assertEquals(cameraState.padding, resultCameraOptions.padding)
            assertEquals(cameraState.bearing, resultCameraOptions.bearing)
            assertEquals(cameraState.pitch, resultCameraOptions.pitch)
        }

        assertEquals(viewModel.mapZoomLevel, cameraState.zoom, 0.0)
    }

    @Test
    fun `invoke search`() = runBlockingTest {
        createViewModel()

        viewModel.searchAddress(DEFAULT_POINT)

        verify(searchAddressUseCase).clearSearchSuggestion()
        verify(searchAddressUseCase).didSearch(DEFAULT_POINT)
    }

    @Test
    fun `invoke closeBottomView will close reporting`() {
        reportUseCase.activateReport()
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))
        createViewModel()

        viewModel.closeBottomViews()

        viewModel.reporting.observeForever {
            assertFalse(viewModel.reporting.value!!)
        }
        verify(searchAddressUseCase).clearSearchPoint()
    }

    @Test
    fun `invoke closeBottomView will close map options`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(true))

        createViewModel()

        viewModel.closeBottomViews()

        verify(mapOptionsUseCase).closeMapOptions()
    }

    @Test
    fun `invoke closeBottomView will close map options and close reporting`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(true))
        reportUseCase.activateReport()

        createViewModel()

        viewModel.closeBottomViews()

        viewModel.reporting.observeForever {
            assertFalse(viewModel.reporting.value!!)
        }
        verify(searchAddressUseCase).clearSearchPoint()
        verify(mapOptionsUseCase).closeMapOptions()
    }

    @Test
    fun `invoke closeBottomView will do nothing`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))

        createViewModel()

        viewModel.closeBottomViews()
    }

    @Test
    fun `invoke onCleared`() {
        createViewModel()

        viewModel.invokeOnClear()

        verify(searchAddressUseCase).clear()
    }

    @Test
    fun `map type is road`() {
        val mapType = MutableLiveData(MapType.ROAD)
        whenever(mapOptionsUseCase.mapType).doReturn(mapType)
        whenever(app.getString(R.string.mapbox_streets)).doReturn(MAPBOX_STREETS)
        createViewModel()

        viewModel.mapStyle.observeForTesting {
            assertEquals(MAPBOX_STREETS, viewModel.mapStyle.value)
        }
        verify(app).getString(R.string.mapbox_streets)
    }

    @Test
    fun `map type is satellite`() {
        val mapType = MutableLiveData(MapType.SATELLITE)
        whenever(mapOptionsUseCase.mapType).doReturn(mapType)
        whenever(app.getString(R.string.satellite_streets)).doReturn(SATELLITE_STREETS)
        createViewModel()

        viewModel.mapStyle.observeForTesting {
            assertEquals(SATELLITE_STREETS, viewModel.mapStyle.value)
        }

        verify(app).getString(R.string.satellite_streets)
    }

    @Test
    fun `open map options will call open map options`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))

        createViewModel()

        viewModel.openMapOptions()

        verify(mapOptionsUseCase).openMapOptions()
    }

    @Test
    fun `open map options will not call open map options if this view is showing`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(true))

        createViewModel()

        viewModel.openMapOptions()
    }

    @Test
    fun `open map options will call open map options and close reporting`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))

        createViewModel()
        reportUseCase.activateReport()

        viewModel.openMapOptions()

        verify(mapOptionsUseCase).openMapOptions()
        viewModel.reporting.observeForTesting {
            assertFalse(viewModel.reporting.value!!)
        }
        verify(searchAddressUseCase).clearSearchPoint()
    }

    @Test
    fun `open map options will not call open map options if the view is opened`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(true))

        createViewModel()

        viewModel.openMapOptions()
    }

    @Test
    fun `verify is showing bottom view when opening map option`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(true))

        createViewModel()

        assertTrue(viewModel.isOpeningBottomView)
    }

    @Test
    fun `verify is showing bottom view when reporting`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))

        reportUseCase.activateReport()

        createViewModel()

        assertTrue(viewModel.isOpeningBottomView)
    }

    @Test
    fun `verify is not showing bottom view`() {
        whenever(mapOptionsUseCase.isOpeningMapOption).thenReturn(MutableLiveData(false))

        createViewModel()

        assertFalse(viewModel.isOpeningBottomView)
    }

    @Test
    fun `verify opening map options`() {
        val isOpening = MutableLiveData(true)
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(isOpening)

        createViewModel()

        viewModel.isOpeningMapOptions.observeForTesting {
            assertTrue(viewModel.isOpeningMapOptions.value!!)
        }
    }

    @Test
    fun `verify not opening map options`() {
        val isOpening = MutableLiveData(false)
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(isOpening)

        createViewModel()

        viewModel.isOpeningMapOptions.observeForTesting {
            assertFalse(viewModel.isOpeningMapOptions.value!!)
        }
    }

    @Test
    fun `verify sync feature collection`() = runBlockingTest {
        createViewModel()
        viewModel.syncFeatureCollection()

        verify(shapesManager).sync()
    }

    @Test
    fun `verify update camera point`() {
        createViewModel()
        viewModel.updateCameraOption(testPoint)
        viewModel.cameraOptions.observeForTesting {
            assertEquals(testPoint, viewModel.cameraOptions.value?.center)
        }
    }

    @Test
    fun `verify will search address by point when activating report and suggestion is null`() =
        runBlockingTest {
            reportUseCase.activateReport()
            createViewModel()
            val point = Point.fromLngLat(32.0, 33.0)
            viewModel.searchAddressByPointIfNeeded(point)

            verify(searchAddressUseCase).currentSearchSuggestion
            verify(searchAddressUseCase).clearSearchSuggestion()
            val pointArgument = argumentCaptor<Point>()
            verify(searchAddressUseCase).didSearch(pointArgument.capture())
            assertEquals(point, pointArgument.firstValue)
        }

    @Test
    fun `verify won't search address by point when not active report and suggestion is null`() {
        reportUseCase.deactivateReport()
        createViewModel()
        viewModel.searchAddressByPointIfNeeded(testPoint)
    }

    @Test
    fun `verify won't search address by point when active report and suggestion not null`() {
        reportUseCase.activateReport()
        whenever(searchAddressUseCase.currentSearchSuggestion).doReturn(mock())
        createViewModel()
        viewModel.searchAddressByPointIfNeeded(testPoint)

        verify(searchAddressUseCase).currentSearchSuggestion
    }

    @Test
    fun `verify will update location when suggestion is null`() {
        createViewModel()
        viewModel.updateIndicatorLocationChange(testPoint)

        viewModel.isGpsVisible.observeForTesting {
            assertFalse(viewModel.isGpsVisible.value!!)
        }

        viewModel.cameraOptions.observeForTesting {
            val result = viewModel.cameraOptions.value
            assertEquals(testPoint, result!!.center)
        }

        verifyBubbleChange(testPoint)
        verify(searchAddressUseCase).currentSearchSuggestion
    }

    @Test
    fun `verify will not update location when search suggestion is not null`() {
        whenever(searchAddressUseCase.currentSearchSuggestion).doReturn(mock())

        createViewModel()

        viewModel.updateIndicatorLocationChange(testPoint)

        verifyBubbleChange(testPoint)
        verify(searchAddressUseCase).currentSearchSuggestion
    }

    private fun verifyBubbleChange(point: Point) {
        val expectedPolygon = TurfTransformation.circle(
            point,
            (clients.radius / 1000).toDouble(),
            TurfConstants.UNIT_DEFAULT
        )
        viewModel.bubblePolygon.observeForTesting {
            assertEquals(expectedPolygon, viewModel.bubblePolygon.value)
            verify(clients, times(2)).radius
            verify(mapOptionsUseCase).clients
        }
    }

    @Test
    fun `verify gpsButton clicked`() {
        createViewModel()

        viewModel.gpsButtonClicked(cameraState)

        verifyStoreCameraState()
        assertTrue(viewModel.canLocateToCurrentPosition)
        verify(searchAddressUseCase).clearSearch()
    }

    @Test
    fun `verify will close bottom views if creating report`() {
        reportUseCase.activateReport()
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(MutableLiveData(false))
        createViewModel()
        viewModel.closeBottomViewsIfNeeded()

        viewModel.reporting.observeForever {
            assertFalse(viewModel.reporting.value!!)
        }
        verify(searchAddressUseCase).clearSearch()
        verify(searchAddressUseCase).clearSearchPoint()
    }

    @Test
    fun `verify will close bottom views if opening map option`() {
        reportUseCase.deactivateReport()
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(MutableLiveData(true))
        createViewModel()
        viewModel.closeBottomViewsIfNeeded()

        viewModel.reporting.observeForever {
            assertFalse(viewModel.reporting.value!!)
        }
        verify(searchAddressUseCase).clearSearch()
        verify(mapOptionsUseCase).closeMapOptions()
        verify(mapOptionsUseCase).isOpeningMapOption
    }

    @Test
    fun `verify will not call if not reporint or opening map option`() {
        reportUseCase.deactivateReport()
        whenever(mapOptionsUseCase.isOpeningMapOption).doReturn(MutableLiveData(false))
        createViewModel()
        viewModel.closeBottomViewsIfNeeded()

        viewModel.reporting.observeForever {
            assertFalse(viewModel.reporting.value!!)
        }
        verify(mapOptionsUseCase).isOpeningMapOption
    }

    @Test
    fun `verify will create report`() {
        createViewModel()
        viewModel.activeReport()

        assertTrue(reportUseCase.showingReport.value!!)
    }

    @Test
    fun `verify reset report data`() {
        createViewModel()

        viewModel.resetReportData()

        assertNull(viewModel.createReportEvent.value)
    }

    @Test
    fun `verify reset creating report`() {
        createViewModel()

        viewModel.resetCreatingReport()

        viewModel.createReportEvent.observeForTesting {
            assertFalse(viewModel.createReportEvent.value?.willCreateReport!!)
        }

        verify(searchAddressUseCase).addressSearchResult
    }

    @Test
    fun `verify get Shape Data`() {
        val shapeMock = mock<ShapeData>()
        val resultLiveData = MutableLiveData(shapeMock)
        whenever(searchAddressUseCase.shapeData).doReturn(resultLiveData)

        createViewModel()

        viewModel.shapeData.observeForTesting {
            assertEquals(shapeMock, viewModel.shapeData.value)
        }
    }

    @Test
    fun `verify report manager has all valid pins which the same appearance`() {
        val uuid1 = UUID.randomUUID().toString()
        val uuid2 = UUID.randomUUID().toString()
        val testAppearance = "generic_steal"
        val location1 = JsonObject().apply {
            addProperty("longitude", 39.202)
            addProperty("latitude", 32.909)
        }
        val location2 = JsonObject().apply {
            addProperty("longitude", 40.202)
            addProperty("latitude", 40.909)
        }
        val report1 = mock<ObsidianReport> {
            on { uuid } doReturn uuid1
            on { title } doReturn "Report 1"
            on { address } doReturn "address 1"
            on { location } doReturn location1
            on { appearance } doReturn testAppearance
        }
        val report2 = mock<ObsidianReport> {
            on { uuid } doReturn uuid2
            on { title } doReturn "Report 2"
            on { address } doReturn "address 2"
            on { location } doReturn location2
            on { appearance } doReturn testAppearance
        }
        val allReportLiveData = MutableLiveData(listOf(report1, report2))
        whenever(reportManager.readAllReportsByTeam()).doReturn(allReportLiveData)

        createViewModel()

        viewModel.pins.observeForTesting {
            val mapPins = viewModel.pins.value
            assertNotNull(mapPins)

            val pins = mapPins!![testAppearance]
            assertEquals(2, pins!!.size)

            assertNotNull(pins.firstOrNull { it.id() == uuid1 })
            assertNotNull(pins.firstOrNull { it.id() == uuid2 })
        }
    }

    @Test
    fun `verify report manager has all valid pins which the different appearances`() {
        val uuid1 = UUID.randomUUID().toString()
        val uuid2 = UUID.randomUUID().toString()
        val testAppearance1 = "generic_steal"
        val testAppearance2 = "generic_red"
        val location1 = JsonObject().apply {
            addProperty("longitude", 39.202)
            addProperty("latitude", 32.909)
        }
        val location2 = JsonObject().apply {
            addProperty("longitude", 40.202)
            addProperty("latitude", 40.909)
        }
        val report1 = mock<ObsidianReport> {
            on { uuid } doReturn uuid1
            on { title } doReturn "Report 1"
            on { address } doReturn "address 1"
            on { location } doReturn location1
            on { appearance } doReturn testAppearance1
        }
        val report2 = mock<ObsidianReport> {
            on { uuid } doReturn uuid2
            on { title } doReturn "Report 2"
            on { address } doReturn "address 2"
            on { location } doReturn location2
            on { appearance } doReturn testAppearance2
        }
        val allReportLiveData = MutableLiveData(listOf(report1, report2))
        whenever(reportManager.readAllReportsByTeam()).doReturn(allReportLiveData)

        createViewModel()

        viewModel.pins.observeForTesting {
            val mapPins = viewModel.pins.value
            assertNotNull(mapPins)

            val pins = mapPins!![testAppearance1]
            assertEquals(1, pins!!.size)
            assertNotNull(pins.firstOrNull { it.id() == uuid1 })

            val pins2 = mapPins[testAppearance2]
            assertEquals(1, pins2!!.size)
            assertNotNull(pins2.firstOrNull { it.id() == uuid2 })
        }
    }

    @Test
    fun `verify report manager has some valid pins`() {
        val uuid1 = UUID.randomUUID().toString()
        val uuid2 = UUID.randomUUID().toString()
        val testAppearance1 = "generic_steal"
        val testAppearance2 = "none"
        val location1 = JsonObject().apply {
            addProperty("longitude", 39.202)
            addProperty("latitude", 32.909)
        }
        val location2 = JsonObject().apply {
            addProperty("longitude", 40.202)
            addProperty("latitude", 40.909)
        }
        val report1 = mock<ObsidianReport> {
            on { uuid } doReturn uuid1
            on { title } doReturn "Report 1"
            on { address } doReturn "address 1"
            on { location } doReturn location1
            on { appearance } doReturn testAppearance1
        }
        val report2 = mock<ObsidianReport> {
            on { uuid } doReturn uuid2
            on { title } doReturn "Report 2"
            on { address } doReturn "address 2"
            on { location } doReturn location2
            on { appearance } doReturn testAppearance2
        }
        val allReportLiveData = MutableLiveData(listOf(report1, report2))
        whenever(reportManager.readAllReportsByTeam()).doReturn(allReportLiveData)

        createViewModel()

        viewModel.pins.observeForTesting {
            val mapPins = viewModel.pins.value
            assertNotNull(mapPins)

            val pins = mapPins!![testAppearance1]
            assertEquals(1, pins!!.size)
            assertNotNull(pins.firstOrNull { it.id() == uuid1 })

            val pins2 = mapPins[testAppearance2]

            assertNull(pins2)
        }
    }

    @Test
    fun `verify disable move to current location`() {
        createViewModel()
        viewModel.disableMoveToCurrentLocation()

        assertFalse(viewModel.canLocateToCurrentPosition)
    }

    @Test
    fun `verify render shapes controller`() {
        val shapes: FeatureCollection = mock()
        createViewModel()

        assertTrue(viewModel.canRender(shapes))
        assertFalse(viewModel.canRender(shapes))
    }

    companion object {
        private val cameraState = CameraState(
            Point.fromLngLat(154.7772114, -41.2887953),
            EdgeInsets(0.0, 0.0, 480.0, 320.0),
            18.0,
            1.0,
            2.0
        )

        private val testPoint = Point.fromLngLat(32.0, 33.0)

        private const val MAPBOX_STREETS = "mapbox://mapbox_streets"
        private const val SATELLITE_STREETS = "mapbox://satellite_streets"
    }
}
