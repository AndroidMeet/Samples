package com.thundermaps.saferme.features.main.reports.all

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.store.resources.ObsidianReport
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.getFormFields
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.locationObject
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.reportStateObject
import com.saferme.obsidian.store.resources.ObsidianReport.Companion.riskLevelObject
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.util.TimeUtil
import io.mockk.every
import io.mockk.mockkObject
import io.mockk.unmockkAll
import java.util.Calendar
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class AllReportsViewModelTest : BaseTest() {
    private val application: SaferMeApplication = mock {
        on { getString(R.string.anonymous) } doReturn ANONYMOUS
    }
    private val reportManager: ReportManager = mock()
    private lateinit var allReportsViewModel: AllReportsViewModel

    @Before
    fun setUp() {
        mockkObject(TimeUtil)
        every { TimeUtil.convertIsoDateStringToDate(DATE1_IN_STRING) } returns Calendar.getInstance()
            .apply {
                set(2021, 9, 11, 10, 45)
            }.time

        every { TimeUtil.convertIsoDateStringToDate(DATE2_IN_STRING) } returns Calendar.getInstance()
            .apply {
                set(2021, 10, 11, 13, 45)
            }.time
        allReportsViewModel = AllReportsViewModel(application, reportManager)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(application, reportManager)
        unmockkAll()
    }

    @Test
    fun `verify get all reports`() = runBlockingTest {
        val obsidianReport1 = mock<ObsidianReport> {
            on { id } doReturn REPORT_ID1
            on { uuid } doReturn REPORT_ID1.toString()
            on { isoCreatedAt } doReturn DATE1_IN_STRING
        }
        val obsidianReport2 = mock<ObsidianReport> {
            on { id } doReturn REPORT_ID2
            on { uuid } doReturn REPORT_ID2.toString()
            on { isoCreatedAt } doReturn DATE2_IN_STRING
        }
        val reports = listOf(obsidianReport1, obsidianReport2)
        val mockReport: LiveData<List<ObsidianReport>> = MutableLiveData(reports)
        whenever(reportManager.readAll()).doReturn(mockReport)

        val cardsLiveData = allReportsViewModel.getReports()

        cardsLiveData.observeForTesting {
            cardsLiveData.value?.let { cardDatas ->
                assertEquals(2, cardDatas.size)
                val firstCard = cardDatas.first()
                assertEquals(firstCard.id, REPORT_ID2.toString())
                assertEquals(cardDatas.last().id, REPORT_ID1.toString())
            }
        }

        verify(reportManager).readAll()
        verifyReportMock(obsidianReport1)
        verifyReportMock(obsidianReport2)
        verify(application).getString(R.string.anonymous)
        verifyNoMoreInteractions(obsidianReport1, obsidianReport2)
    }

    private fun verifyReportMock(obsidianReport: ObsidianReport) {
        verify(obsidianReport).uuid
        verify(obsidianReport).isoCreatedAt
        verify(obsidianReport).title
        verify(obsidianReport).categoriesTitle
        verify(obsidianReport).getFormFields
        verify(obsidianReport).reportStateObject
        verify(obsidianReport).riskLevelObject
        verify(obsidianReport).address
        verify(obsidianReport).locationObject
        verify(obsidianReport).userShortName
    }

    companion object {
        private const val REPORT_ID1 = 1
        private const val REPORT_ID2 = 2
        private const val DATE1_IN_STRING = "2021-10-11T10:45:14+13:00"
        private const val DATE2_IN_STRING = "2021-11-11T13:45:14+13:00"
        private const val ANONYMOUS = "anonymous"
    }
}
