package com.thundermaps.saferme.core.usecase

import android.content.Context
import android.content.SharedPreferences
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.preference.PreferenceManager
import com.mapbox.geojson.Feature
import com.mapbox.geojson.Point
import com.mapbox.search.QueryType
import com.mapbox.search.ReverseGeoOptions
import com.mapbox.search.ReverseGeocodingSearchEngine
import com.mapbox.search.SearchCallback
import com.mapbox.search.SearchEngine
import com.mapbox.search.SearchOptions
import com.mapbox.search.SearchRequestTask
import com.mapbox.search.result.SearchAddress
import com.mapbox.search.result.SearchResult
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.anyOrNull
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.atLeast
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.Provider
import com.saferme.obsidian.ShapesManager
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.models.CustomSearchResult
import com.thundermaps.saferme.core.domain.models.SmSearchSuggestion
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase.Companion.DEFAULT_POINT
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase.Companion.POINT_NEAR_POLYGON
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase.Companion.POINT_NEAR_THE_LINE
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase.Companion.POINT_ON_THE_LINE
import com.thundermaps.saferme.core.usecase.SearchAddressUseCase.Companion.RECENT_SEARCH_SUGGESTION_KEY
import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestRule

@ExperimentalCoroutinesApi
class SearchAddressUseCaseTest {
    private lateinit var searchAddressUseCase: SearchAddressUseCase
    private val context: Context = mock()
    private val reverseSearchEngine: ReverseGeocodingSearchEngine = mock()
    private val shapesManager: ShapesManager = mock {}

    private val sessions: Sessions = mock {
        on { userId } doReturn USER_ID
    }
    private val sessionsManager: SessionsManager = mock {
        on { getSessions() } doReturn sessions
    }
    private val obsidianApi: ObsidianApi = mock {
        on { provideSessionsManager() } doReturn sessionsManager
        on { shapesManager } doReturn shapesManager
    }
    private val searchEngine: SearchEngine = mock()
    private val sharedPreferences: SharedPreferences = mock {
        on { edit() } doReturn mock()
    }

    @Rule
    @JvmField
    var rule: TestRule = InstantTaskExecutorRule()

    private fun setupSearchAddressUseCase() {
        mockkStatic(PreferenceManager::class)
        every { PreferenceManager.getDefaultSharedPreferences(context) } returns sharedPreferences
        searchAddressUseCase = SearchAddressUseCase(
            context,
            searchEngine,
            reverseSearchEngine,
            obsidianApi,
            Provider.gson
        )
    }

    @After
    fun tearDown() {
        unmockkAll()
        verify(obsidianApi).shapesManager
        verify(shapesManager, atLeast(1)).featureCollection
        verifyNoMoreInteractions(
            context,
            reverseSearchEngine,
            searchEngine,
            obsidianApi,
            sessionsManager,
            sessions,
            sharedPreferences,
            shapesManager
        )
    }

    @Test
    fun `search return error then address is built from location`() = runBlockingTest {
        val task: SearchRequestTask = mock()
        val optionArgument = argumentCaptor<ReverseGeoOptions>()
        val callBack = argumentCaptor<SearchCallback>()
        whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
            val argument = it.arguments[1]
            val searchCallback = argument as SearchCallback
            searchCallback.onError(mock())
            task
        }
        setupSearchAddressUseCase()
        searchAddressUseCase.didSearch(DEFAULT_POINT)

        verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

        assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
        assertEquals(1, optionArgument.firstValue.limit)

        searchAddressUseCase.address.observeForTesting {
            assertEquals(
                searchAddressUseCase.getLocationInString(),
                searchAddressUseCase.address.value
            )
        }

        searchAddressUseCase.clear()
        verify(task).cancel()

        verifyNoMoreInteractions(task)
    }

    @Test
    fun `search return no result then address is built from location`() = runBlockingTest {
        val task: SearchRequestTask = mock()
        val optionArgument = argumentCaptor<ReverseGeoOptions>()
        val callBack = argumentCaptor<SearchCallback>()
        whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
            val argument = it.arguments[1]
            val searchCallback = argument as SearchCallback
            searchCallback.onResults(emptyList(), mock())
            task
        }
        setupSearchAddressUseCase()
        searchAddressUseCase.didSearch(DEFAULT_POINT)

        verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

        assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
        assertEquals(1, optionArgument.firstValue.limit)

        searchAddressUseCase.address.observeForTesting {
            assertEquals(
                searchAddressUseCase.getLocationInString(),
                searchAddressUseCase.address.value
            )
        }

        searchAddressUseCase.clear()
        verify(task).cancel()

        verifyNoMoreInteractions(task)
    }

    @Test
    fun `search return searchResult without address then address is built from location`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            val searchResult: SearchResult = mock()
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(listOf(searchResult), mock())
                task
            }
            setupSearchAddressUseCase()
            searchAddressUseCase.didSearch(DEFAULT_POINT)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
            assertEquals(1, optionArgument.firstValue.limit)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(
                    searchAddressUseCase.getLocationInString(),
                    searchAddressUseCase.address.value
                )
            }

            searchAddressUseCase.addressSearchResult.observeForTesting {
                assertEquals(
                    CUSTOM_SEARCH_RESULT.copy(
                        address = null,
                        Point.fromLngLat(0.0, 0.0)
                    ), searchAddressUseCase.addressSearchResult.value
                )
            }

            searchAddressUseCase.clear()
            verify(task).cancel()

            verify(searchResult).coordinate
            verify(searchResult).address
        }

    @Test
    fun `search return searchResult with address no houseNumber then address is built from location`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            val addressSearch: SearchAddress = mock()
            val searchResult: SearchResult = mock {
                on { address } doReturn addressSearch
            }
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(listOf(searchResult), mock())
                task
            }
            setupSearchAddressUseCase()
            searchAddressUseCase.didSearch(DEFAULT_POINT)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
            assertEquals(1, optionArgument.firstValue.limit)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(
                    searchAddressUseCase.getLocationInString(),
                    searchAddressUseCase.address.value
                )
            }

            searchAddressUseCase.addressSearchResult.observeForTesting {
                assertEquals(
                    CUSTOM_SEARCH_RESULT.copy(
                        address = null,
                        Point.fromLngLat(0.0, 0.0)
                    ), searchAddressUseCase.addressSearchResult.value
                )
            }

            searchAddressUseCase.clear()
            verify(task).cancel()

            verify(searchResult).coordinate
            verify(searchResult).address
            verify(addressSearch).formattedAddress(SearchAddress.FormatStyle.Full)
            verifyNoMoreInteractions(task, searchResult, addressSearch)
        }

    @Test
    fun `search return valid address`() = runBlockingTest {
        val task: SearchRequestTask = mock()
        val optionArgument = argumentCaptor<ReverseGeoOptions>()
        val callBack = argumentCaptor<SearchCallback>()
        val addressSearch: SearchAddress = mock {
            on { formattedAddress(any()) } doReturn "$HOUSE_NUMBER $STREET"
        }
        val searchResult: SearchResult = mock {
            on { address } doReturn addressSearch
        }
        whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
            val argument = it.arguments[1]
            val searchCallback = argument as SearchCallback
            searchCallback.onResults(listOf(searchResult), mock())
            task
        }
        setupSearchAddressUseCase()
        searchAddressUseCase.didSearch(DEFAULT_POINT)

        verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

        assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
        assertEquals(1, optionArgument.firstValue.limit)

        searchAddressUseCase.address.observeForTesting {
            assertEquals(
                "$HOUSE_NUMBER $STREET",
                searchAddressUseCase.address.value
            )
        }

        searchAddressUseCase.clear()
        verify(task).cancel()

        verify(searchResult).coordinate
        verify(searchResult).address
        verify(addressSearch).formattedAddress(SearchAddress.FormatStyle.Full)
        verifyNoMoreInteractions(task, searchResult, addressSearch)
    }

    @Test
    fun `verify start search with empty use`() = runBlockingTest {
        setupSearchAddressUseCase()
        whenever(sharedPreferences.getString(any(), anyOrNull())).doReturn(SEARCH_SUGGESTION_DATA)
        searchAddressUseCase.startSearch()

        assertNull(searchAddressUseCase.currentSearchSuggestion)

        verifyBuildFileName()
        searchAddressUseCase.saferMeSearchSuggestions.observeForTesting {
            assertFalse(searchAddressUseCase.saferMeSearchSuggestions.value.isNullOrEmpty())
        }
        verify(sharedPreferences).getString("$RECENT_SEARCH_SUGGESTION_KEY$USER_ID", null)
    }

    @Test
    fun `verify did select search suggestion`() = runBlockingTest {
        setupSearchAddressUseCase()
        val smSearchSuggestion = SmSearchSuggestion("39 Rossall", null)

        searchAddressUseCase.didSelectSearchSuggestion(smSearchSuggestion)

        verifyBuildFileName()
        assertEquals(smSearchSuggestion, searchAddressUseCase.currentSearchSuggestion)
        verify(sharedPreferences).edit()
    }

    @Test
    fun `verify search Text`() {

        setupSearchAddressUseCase()
        val query = "45 Papanui"
        searchAddressUseCase.didSearch(query)

        assertNull(searchAddressUseCase.currentSearchSuggestion)
        val optionCaptor = argumentCaptor<SearchOptions>()
        val queryCaptor = argumentCaptor<String>()
        verify(searchEngine).search(queryCaptor.capture(), optionCaptor.capture(), any())
        assertEquals(query, queryCaptor.firstValue)
        val searchOptions = optionCaptor.firstValue
        assertEquals(10, searchOptions.limit)
        assertEquals(listOf(QueryType.ADDRESS), searchOptions.types)
    }

    @Test
    fun `search return error then address is built from location with feature collection`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onError(mock())
                task
            }

            val liveData = MutableLiveData(featureCollection)
            whenever(shapesManager.featureCollection).doReturn(liveData)

            setupSearchAddressUseCase()
            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    shapesManager.featureCollection.value,
                    searchAddressUseCase.shapeData.value?.shapes
                )
                assertNull(
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }
            searchAddressUseCase.didSearch(DEFAULT_POINT)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
            assertEquals(1, optionArgument.firstValue.limit)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(
                    POLYGON_ADDRESS,
                    searchAddressUseCase.address.value
                )
            }

            searchAddressUseCase.clear()
            verify(task, times(2)).cancel()

            verifyNoMoreInteractions(task)
        }

    @Test
    fun `search return no result then address is built from location with feature collection`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(emptyList(), mock())
                task
            }

            val liveData = MutableLiveData(featureCollection)
            whenever(shapesManager.featureCollection).doReturn(liveData)
            setupSearchAddressUseCase()
            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    shapesManager.featureCollection.value,
                    searchAddressUseCase.shapeData.value?.shapes
                )
                assertNull(
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }
            searchAddressUseCase.didSearch(DEFAULT_POINT)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
            assertEquals(1, optionArgument.firstValue.limit)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(
                    POLYGON_ADDRESS,
                    searchAddressUseCase.address.value
                )
            }

            searchAddressUseCase.clear()
            verify(task, times(2)).cancel()

            verifyNoMoreInteractions(task)
        }

    @Test
    fun `search return searchResult without address then address is built from location with feature collection`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            val searchResult: SearchResult = mock()
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(listOf(searchResult), mock())
                task
            }

            val liveData = MutableLiveData(featureCollection)
            whenever(shapesManager.featureCollection).doReturn(liveData)
            setupSearchAddressUseCase()
            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    shapesManager.featureCollection.value,
                    searchAddressUseCase.shapeData.value?.shapes
                )
                assertNull(
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }
            searchAddressUseCase.didSearch(DEFAULT_POINT)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
            assertEquals(1, optionArgument.firstValue.limit)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(
                    POLYGON_ADDRESS,
                    searchAddressUseCase.address.value
                )
            }

            searchAddressUseCase.addressSearchResult.observeForTesting {
                assertEquals(CUSTOM_SEARCH_RESULT, searchAddressUseCase.addressSearchResult.value)
            }

            searchAddressUseCase.clear()
            verify(task, times(2)).cancel()

            verify(searchResult).coordinate
            verify(searchResult).address
            verifyNoMoreInteractions(task, searchResult)
        }

    @Test
    fun `search return searchResult with address no houseNumber then address is built from location with feature collection`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            val addressSearch: SearchAddress = mock()
            val point: Point = mock {
                on { latitude() } doReturn LATITUDE
                on { longitude() } doReturn LONGITUDE
            }

            val searchResult: SearchResult = mock {
                on { address } doReturn addressSearch
                on { coordinate } doReturn point
            }
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(listOf(searchResult), mock())
                task
            }

            val liveData = MutableLiveData(featureCollection)
            whenever(shapesManager.featureCollection).doReturn(liveData)
            setupSearchAddressUseCase()
            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    shapesManager.featureCollection.value,
                    searchAddressUseCase.shapeData.value?.shapes
                )
                assertNull(
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }
            searchAddressUseCase.didSearch(DEFAULT_POINT)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)
            assertEquals(1, optionArgument.firstValue.limit)

            searchAddressUseCase.addressSearchResult.observeForTesting {
                assertEquals(CUSTOM_SEARCH_RESULT, searchAddressUseCase.addressSearchResult.value)
            }

            searchAddressUseCase.clear()
            verify(task, times(2)).cancel()

            verify(searchResult).address
            verify(searchResult).coordinate

            verify(addressSearch).formattedAddress(SearchAddress.FormatStyle.Full)

            verifyNoMoreInteractions(task, searchResult, addressSearch)
        }

    @Test
    fun `search return valid address with feature collection`() = runBlockingTest {
        val task: SearchRequestTask = mock()
        val optionArgument = argumentCaptor<ReverseGeoOptions>()
        val callBack = argumentCaptor<SearchCallback>()
        val addressSearch: SearchAddress = mock {
            on { formattedAddress(any()) } doReturn "$HOUSE_NUMBER $STREET"
        }
        val point: Point = mock {
            on { latitude() } doReturn LATITUDE
            on { longitude() } doReturn LONGITUDE
        }

        val searchResult: SearchResult = mock {
            on { address } doReturn addressSearch
            on { coordinate } doReturn point
        }
        whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
            val argument = it.arguments[1]
            val searchCallback = argument as SearchCallback
            searchCallback.onResults(listOf(searchResult), mock())
            task
        }

        val liveData = MutableLiveData(featureCollection)
        whenever(shapesManager.featureCollection).doReturn(liveData)
        setupSearchAddressUseCase()
        searchAddressUseCase.shapeData.observeForTesting {
            assertEquals(
                shapesManager.featureCollection.value,
                searchAddressUseCase.shapeData.value?.shapes
            )
            assertNull(
                searchAddressUseCase.shapeData.value?.selectedShape
            )
        }

        searchAddressUseCase.didSearch(DEFAULT_POINT)

        verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

        assertEquals(DEFAULT_POINT, optionArgument.firstValue.center)

        searchAddressUseCase.address.observeForTesting {
            assertEquals(POLYGON_ADDRESS, searchAddressUseCase.address.value)
        }

        searchAddressUseCase.clear()
        verify(task, times(2)).cancel()

        verify(searchResult).address
        verify(searchResult).coordinate

        verify(addressSearch).formattedAddress(SearchAddress.FormatStyle.Full)
        verifyNoMoreInteractions(task, searchResult, addressSearch)
    }

    @Test
    fun `search return valid address with feature collection nearby the polygon`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            val addressSearch: SearchAddress = mock {
                on { formattedAddress(any()) } doReturn POLYGON_ADDRESS
            }
            val point: Point = mock {
                on { latitude() } doReturn LATITUDE
                on { longitude() } doReturn LONGITUDE
            }

            val searchResult: SearchResult = mock {
                on { address } doReturn addressSearch
                on { coordinate } doReturn point
            }
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(listOf(searchResult), mock())
                task
            }

            val liveData = MutableLiveData(featureCollection)
            whenever(shapesManager.featureCollection).doReturn(liveData)
            setupSearchAddressUseCase()
            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    shapesManager.featureCollection.value,
                    searchAddressUseCase.shapeData.value?.shapes
                )
                assertNull(
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }

            searchAddressUseCase.didSearch(POINT_NEAR_POLYGON)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(POINT_NEAR_POLYGON, optionArgument.firstValue.center)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(POLYGON_ADDRESS, searchAddressUseCase.address.value)
            }

            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    searchAddressUseCase.shapeData.value?.shapes?.features?.get(5)?.json()
                        ?.let { Feature.fromJson(it) },
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }

            searchAddressUseCase.clear()
            verify(task, times(2)).cancel()

            verify(searchResult).address
            verify(searchResult).coordinate
            verify(shapesManager, times(2)).featureCollection

            verify(addressSearch).formattedAddress(SearchAddress.FormatStyle.Full)
            verifyNoMoreInteractions(task, searchResult, addressSearch)
        }

    @Test
    fun `search return valid address with feature collection on the line`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            val addressSearch: SearchAddress = mock {
                on { formattedAddress(any()) } doReturn POINT_ON_THE_LINE_STRING_ADDRESS
            }
            val point: Point = mock {
                on { latitude() } doReturn LATITUDE
                on { longitude() } doReturn LONGITUDE
            }

            val searchResult: SearchResult = mock {
                on { address } doReturn addressSearch
                on { coordinate } doReturn point
            }
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(listOf(searchResult), mock())
                task
            }

            val liveData = MutableLiveData(featureCollection)
            whenever(shapesManager.featureCollection).doReturn(liveData)
            setupSearchAddressUseCase()
            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    shapesManager.featureCollection.value,
                    searchAddressUseCase.shapeData.value?.shapes
                )
            }

            searchAddressUseCase.didSearch(POINT_ON_THE_LINE)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(POINT_ON_THE_LINE, optionArgument.firstValue.center)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(POINT_ON_THE_LINE_STRING_ADDRESS, searchAddressUseCase.address.value)
            }

            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    searchAddressUseCase.shapeData.value?.shapes?.features?.get(1)?.json()
                        ?.let { Feature.fromJson(it) },
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }

            searchAddressUseCase.clear()
            verify(task, times(2)).cancel()

            verify(searchResult).address
            verify(searchResult).coordinate
            verify(shapesManager, times(2)).featureCollection

            verify(addressSearch).formattedAddress(SearchAddress.FormatStyle.Full)
            verifyNoMoreInteractions(task, searchResult, addressSearch)
        }

    @Test
    fun `search return valid address with feature collection nearby the line`() =
        runBlockingTest {
            val task: SearchRequestTask = mock()
            val optionArgument = argumentCaptor<ReverseGeoOptions>()
            val callBack = argumentCaptor<SearchCallback>()
            val addressSearch: SearchAddress = mock {
                on { formattedAddress(any()) } doReturn NEARBY_LINESTRING_ADDRESS
            }
            val point: Point = mock {
                on { latitude() } doReturn LATITUDE
                on { longitude() } doReturn LONGITUDE
            }

            val searchResult: SearchResult = mock {
                on { address } doReturn addressSearch
                on { coordinate } doReturn point
            }
            whenever(reverseSearchEngine.search(any(), any())).thenAnswer {
                val argument = it.arguments[1]
                val searchCallback = argument as SearchCallback
                searchCallback.onResults(listOf(searchResult), mock())
                task
            }

            val liveData = MutableLiveData(featureCollection)
            whenever(shapesManager.featureCollection).doReturn(liveData)
            setupSearchAddressUseCase()
            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    shapesManager.featureCollection.value,
                    searchAddressUseCase.shapeData.value?.shapes
                )
            }

            searchAddressUseCase.didSearch(POINT_NEAR_THE_LINE)

            verify(reverseSearchEngine).search(optionArgument.capture(), callBack.capture())

            assertEquals(POINT_NEAR_THE_LINE, optionArgument.firstValue.center)

            searchAddressUseCase.address.observeForTesting {
                assertEquals(NEARBY_LINESTRING_ADDRESS, searchAddressUseCase.address.value)
            }

            searchAddressUseCase.shapeData.observeForTesting {
                assertEquals(
                    searchAddressUseCase.shapeData.value?.shapes?.features?.get(3)?.json()
                        ?.let { Feature.fromJson(it) },
                    searchAddressUseCase.shapeData.value?.selectedShape
                )
            }

            searchAddressUseCase.clear()
            verify(task, times(2)).cancel()

            verify(searchResult).address
            verify(searchResult).coordinate
            verify(shapesManager, times(2)).featureCollection

            verify(addressSearch).formattedAddress(SearchAddress.FormatStyle.Full)
            verifyNoMoreInteractions(task, searchResult, addressSearch)
        }

    @Test
    fun `verify clear search point`() {
        val liveData = MutableLiveData(featureCollection)
        whenever(shapesManager.featureCollection).doReturn(liveData)

        setupSearchAddressUseCase()

        searchAddressUseCase.clearSearchPoint()

        searchAddressUseCase.shapeData.observeForTesting {
            searchAddressUseCase.shapeData.value?.let {
                assertNull(it.closestPoint)
                assertNull(it.selectedShape)
            }
        }
    }

    private fun verifyBuildFileName() {
        verify(obsidianApi).provideSessionsManager()
        verify(sessionsManager).getSessions()
        verify(sessions).userId
    }

    companion object {
        private const val USER_ID = 3290L
        private const val LATITUDE = 50.652111
        private const val LONGITUDE = -3.174039
        private const val HOUSE_NUMBER = "74"
        private const val STREET = "Rossall Street"
        private const val POLYGON_ADDRESS = "farm-5\n" +
                "lease-5 subsection-5: method 2"
        private const val NEARBY_LINESTRING_ADDRESS = "Point Near the Line\n" +
                "Site 2 Block C West: Riser 2"
        private const val POINT_ON_THE_LINE_STRING_ADDRESS = "Point On the Line\n" +
                "Site 2 Block A East: Riser 57"
        private val SEARCH_SUGGESTION_DATA = """
            [{"address":"24 Winchester Street, Merivale, Christchurch, Canterbury, New Zealand, 8014","isRecent":false,"point":{"coordinates":[172.62152099609375,-43.51875686645508],"type":"Point"}},{"address":"57 Andover Street, Merivale, Christchurch, Canterbury, New Zealand, 8014","isRecent":true,"point":{"coordinates":[172.6230926513672,-43.51934051513672],"type":"Point"}},{"address":"78 Andover Street, Merivale, Christchurch, Canterbury, New Zealand, 8014","isRecent":true,"point":{"coordinates":[172.62432861328125,-43.519134521484375],"type":"Point"}},{"address":"75 Andover Street, Merivale, Christchurch, Canterbury, New Zealand, 8014","isRecent":true,"point":{"coordinates":[172.6241455078125,-43.51885223388672],"type":"Point"}},{"address":"116 Rossall Street, Merivale, Christchurch, Canterbury, New Zealand, 8014","isRecent":true,"point":{"coordinates":[172.6147918701172,-43.51742172241211],"type":"Point"}},{"address":"78 Derby Street, St Albans, Christchurch, Canterbury, New Zealand, 8014","isRecent":false,"point":{"coordinates":[172.63211059570312,-43.519081115722656],"type":"Point"}},{"address":"45 Winchester Street, Merivale, Christchurch, Canterbury, New Zealand, 8014","isRecent":false,"point":{"coordinates":[172.62013244628906,-43.518211364746094],"type":"Point"}},{"address":"119 Rossall Street, Merivale, Christchurch, Canterbury, New Zealand, 8014","isRecent":true,"point":{"coordinates":[172.6123504638672,-43.515254974365234],"type":"Point"}}]
        """.trimIndent()

        private val GEO_JSON_DATA = """
            {"type":"FeatureCollection","features":[{"type":"Feature","geometry":{"type":"LineString","coordinates":[[-3.16933,50.640283],[-3.16933,50.640347]]},"id":"00056956-6e34-ff7e-1786-e340ab246ad5","properties":{"farm":"Offshore Shellfish","lease":"Numbers","is_selectable":"true"}},{"type":"Feature","geometry":{"type":"LineString","coordinates":[[-3.182074,50.650703],[-3.179547,50.650994]]},"id":"00068e82c6d1c86295b000b9b8051b11","properties":{"farm":"Point On the Line","lease":"Site 2","subsection":"Block A East","method":"Riser","item":57,"is_selectable":"true"}},{"type":"Feature","geometry":{"type":"LineString","coordinates":[[-3.23623,50.586343],[-3.236142,50.586343]]},"id":"000e30f1443d60bf70ee126732b40bd0","properties":{"farm":"Offshore Shellfish","lease":"Numbers"}},{"type":"Feature","geometry":{"type":"LineString","coordinates":[[-3.182592,50.6511],[-3.182471,50.651114]]},"id":"000ee740816637e103dd6cd674d385c2","properties":{"farm":"Point Near the Line","lease":"Site 2","subsection":"Block C West","method":"Riser","item":2}},{"type":"Feature","geometry":{"type":"LineString","coordinates":[[-3.22345,50.585184],[-3.223362,50.585184]]},"id":"00261800-7c09-8f3f-8e9f-cb2683a01b84","properties":{"farm":"Offshore Shellfish","lease":"Numbers"}},{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[-3.174039,50.652111],[-3.17402,50.652045],[-3.174088,50.652037],[-3.174107,50.652103],[-3.174039,50.652111]]]},"id":"1d41d5c173e16afdea0e0c19fcaf6385","properties":{"farm":"farm-5","lease":"lease-5","subsection":"subsection-5","method":"method","item":2}}]}
        """.trimIndent()

        private val featureCollection =
            io.github.dellisd.spatialk.geojson.FeatureCollection.fromJson(GEO_JSON_DATA)

        private val CUSTOM_SEARCH_RESULT = CustomSearchResult(
            address = POLYGON_ADDRESS,
            Point.fromLngLat(LONGITUDE, LATITUDE)
        )
    }
}
