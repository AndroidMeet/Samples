package com.thundermaps.saferme.features.main.changeorganization

import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.store.resources.ObsidianTeam
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.data.repo.TeamRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.times

@ExperimentalCoroutinesApi
class ChangeOrganizationViewModelTest : BaseTest() {
    private val obsidianTeam1: ObsidianTeam = mock {
        on { name } doReturn TEAM_NAME_1
        on { id } doReturn TEAM_ID_1
    }
    private val obsidianTeam: ObsidianTeam = mock()
    private val teams = listOf(obsidianTeam, obsidianTeam1)
    private val teamsLiveData = MutableLiveData(teams)
    private val teamsRepository: TeamRepository = mock {
        on { teams } doReturn teamsLiveData
    }
    private val testContextProvider = TestContextProvider()
    private lateinit var teamsViewModel: ChangeOrganizationViewModel

    @Before
    fun setUp() {
        teamsViewModel = ChangeOrganizationViewModel(teamsRepository, testContextProvider)
    }

    @After
    fun tearDown() {
        verify(teamsRepository).teams
        verifyNoMoreInteractions(teamsRepository, obsidianTeam1, obsidianTeam)
    }

    @Test
    fun `verify sync teams`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        teamsViewModel.syncTeams(TEAM_NAME_1)

        assertEquals(teamsViewModel.selectedTeamName.value, TEAM_NAME_1)
        verify(teamsRepository).syncTeam()
    }

    @Test
    fun `verify get teams`() {
        val result = teamsViewModel.teams

        result.observeForTesting {
            assertEquals(teamsLiveData, result)
            assertEquals(teams, result.value)
        }
    }

    @Test
    fun `verify change Organization`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            val sessions = mock<Sessions> {
                on { teamId } doReturn TEAM_ID_1
                on { passwordUpdatePending } doReturn false
                on { profileDetailsPending } doReturn false
            }
            whenever(sessions.teamId).doReturn(TEAM_ID_1)

            whenever(teamsRepository.selectTeam(TEAM_ID_1)).doReturn(sessions)

            teamsViewModel.selectTeam(obsidianTeam1)
            assertEquals(teamsViewModel.selectedTeamName.value, TEAM_NAME_1)

            verify(obsidianTeam1).id
            verify(obsidianTeam1).name
            verify(teamsRepository).selectTeam(TEAM_ID_1)
        }

    companion object {
        const val TEAM_NAME_1 = "Team 1"
        const val TEAM_ID_1 = 329L
    }
}
