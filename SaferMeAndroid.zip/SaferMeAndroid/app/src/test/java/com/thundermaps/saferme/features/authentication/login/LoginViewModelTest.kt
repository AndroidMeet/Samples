package com.thundermaps.saferme.features.authentication.login

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.thundermaps.apilib.android.api.requests.models.SessionBody
import com.thundermaps.apilib.android.api.responses.models.ErrorCode
import com.thundermaps.apilib.android.api.responses.models.ErrorCodes
import com.thundermaps.apilib.android.api.responses.models.ResponseError
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.data.exceptions.SaferMeException
import com.thundermaps.saferme.core.ui.Screen
import com.thundermaps.saferme.features.authentication.login.domain.LoginRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import timber.log.Timber

@ExperimentalCoroutinesApi
class LoginViewModelTest : BaseTest() {
    private val application: Application = mock {
        on { getString(R.string.login_password) } doReturn PASSWORD_LABEL
        on { getString(R.string.login_email) } doReturn EMAIL_LABEL
    }
    private val _isStagingLiveData = MutableLiveData(true)
    private val loginRepository: LoginRepository = mock {
        on { isStaging } doReturn _isStagingLiveData
    }
    private val testContextProvider = TestContextProvider()
    private lateinit var loginViewModel: LoginViewModel

    @Before
    fun setUp() {
        loginViewModel = LoginViewModel(application, loginRepository, testContextProvider)
        verify(loginRepository).isStaging
        runBlockingTest {
            verify(loginRepository).syncBrand()
        }
    }

    @After
    fun tearDown() {
        verify(application).getString(R.string.login_email)
        verify(application).getString(R.string.login_password)
        verifyNoMoreInteractions(application, loginRepository)
    }

    @Test
    fun `Login button is disable when viewModal is initialized`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            loginViewModel.isReadyForLogin.observeForTesting {
                val value = loginViewModel.isReadyForLogin.value
                assertFalse(value!!)
            }

            assertEquals(EMAIL_LABEL, loginViewModel.userInput.title)
            assertEquals(PASSWORD_LABEL, loginViewModel.passwordInput.title)
        }

    @Test
    fun `Email is null and verify error message`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            mockEmailErrorMessages()
            val isEmailNotValid = loginViewModel.checkEmail()

            assertTrue(isEmailNotValid)
            assertTrue(loginViewModel.userInput.isError)
            assertEquals(EMAIL_EMPTY_OR_NULL, loginViewModel.userInput.error.value)

            verifyCallEmailErrorMessages()
        }

    @Test
    fun `Email is empty and verify error message`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            mockEmailErrorMessages()
            val email = ""

            loginViewModel.userInput.text.value = email
            whenever(loginRepository.isAccountLocked(email)).doReturn(false)

            val isEmailNotValid = loginViewModel.checkEmail()

            assertTrue(isEmailNotValid)
            assertTrue(loginViewModel.userInput.isError)
            assertEquals(EMAIL_EMPTY_OR_NULL, loginViewModel.userInput.error.value)

            val emailCaptor = argumentCaptor<String>()
            verify(loginRepository).isAccountLocked(emailCaptor.capture())
            assertEquals(email, emailCaptor.firstValue)

            verifyCallEmailErrorMessages()
        }

    @Test
    fun `Email is not valid and verify error message`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            mockEmailErrorMessages()
            whenever(loginRepository.isAccountLocked(any())).doReturn(false)
            loginViewModel.userInput.text.value = "test@abc"

            val isEmailNotValid = loginViewModel.checkEmail()

            assertTrue(isEmailNotValid)
            assertTrue(loginViewModel.userInput.isError)
            assertEquals(EMAIL_INVALID, loginViewModel.userInput.error.value)

            val emailCaptor = argumentCaptor<String>()
            verify(loginRepository).isAccountLocked(emailCaptor.capture())
            assertEquals(loginViewModel.userInput.text.value, emailCaptor.firstValue)

            verifyCallEmailErrorMessages()
        }

    @Test
    fun `Email is valid and no error`() {
        mockEmailErrorMessages()
        val email = "test@gmail.com"

        loginViewModel.userInput.text.value = email

        val isEmailNotValid = loginViewModel.checkEmail()

        assertFalse(isEmailNotValid)
        assertFalse(loginViewModel.userInput.isError)
        assertNull(loginViewModel.userInput.error.value)

        verifyCallEmailErrorMessages()
    }

    private fun verifyCallEmailErrorMessages() {
        verify(application).getString(R.string.login_email_empty_error)
        verify(application).getString(R.string.login_email_invalid)
    }

    private fun mockEmailErrorMessages() {
        whenever(application.getString(R.string.login_email_empty_error)).doReturn(
            EMAIL_EMPTY_OR_NULL
        )
        whenever(application.getString(R.string.login_email_invalid)).doReturn(EMAIL_INVALID)
    }

    @Test
    fun `Password is null and verify error message`() {
        whenever(application.getString(R.string.login_password_empty_error)).doReturn(
            PASSWORD_EMPTY_OR_NULL
        )

        val isPasswordNotValid = loginViewModel.checkPassword()

        assertTrue(isPasswordNotValid)
        assertTrue(loginViewModel.passwordInput.isError)
        assertEquals(PASSWORD_EMPTY_OR_NULL, loginViewModel.passwordInput.error.value)

        verify(application).getString(R.string.login_password_empty_error)
    }

    @Test
    fun `Password is empty and verify error message`() {
        whenever(application.getString(R.string.login_password_empty_error)).doReturn(
            PASSWORD_EMPTY_OR_NULL
        )

        loginViewModel.passwordInput.text.value = ""

        val isPasswordNotValid = loginViewModel.checkPassword()

        assertTrue(isPasswordNotValid)
        assertTrue(loginViewModel.passwordInput.isError)
        assertEquals(PASSWORD_EMPTY_OR_NULL, loginViewModel.passwordInput.error.value)

        verify(application).getString(R.string.login_password_empty_error)
    }

    @Test
    fun `Password is too short and verify error message`() {
        whenever(application.getString(R.string.login_password_empty_error)).doReturn(
            PASSWORD_EMPTY_OR_NULL
        )
        whenever(application.getString(R.string.login_password_too_short)).doReturn(
            PASSWORD_TOO_SHORT
        )

        loginViewModel.passwordInput.text.value = "43di"

        val isPasswordNotValid = loginViewModel.checkPassword()

        assertTrue(isPasswordNotValid)
        assertTrue(loginViewModel.passwordInput.isError)
        assertEquals(PASSWORD_TOO_SHORT, loginViewModel.passwordInput.error.value)

        verify(application).getString(R.string.login_password_empty_error)
        verify(application).getString(R.string.login_password_too_short)
    }

    @Test
    fun `Password is valid and no error`() {
        whenever(application.getString(R.string.login_password_empty_error)).doReturn(
            PASSWORD_EMPTY_OR_NULL
        )
        loginViewModel.passwordInput.text.value = "439fj232902932"

        val isPasswordNotValid = loginViewModel.checkPassword()

        assertFalse(isPasswordNotValid)
        assertFalse(loginViewModel.passwordInput.isError)
        assertNull(loginViewModel.passwordInput.error.value)

        verify(application).getString(R.string.login_password_empty_error)
    }

    @Test
    fun `Login button is disabled with invalid email and valid password`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            whenever(loginRepository.isAccountLocked(any())).doReturn(false)
            `Email is not valid and verify error message`()
            `Password is valid and no error`()

            loginViewModel.isReadyForLogin.observeForTesting {
                assertFalse(loginViewModel.isReadyForLogin.value!!)
            }

            val emailCaptor = argumentCaptor<String>()
            verify(loginRepository, times(2)).isAccountLocked(emailCaptor.capture())
            assertEquals(loginViewModel.userInput.text.value, emailCaptor.firstValue)
        }

    @Test
    fun `Login button is disabled with valid email and invalid password`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {

            `Email is not valid and verify error message`()
            `Password is too short and verify error message`()

            loginViewModel.isReadyForLogin.observeForTesting {
                assertFalse(loginViewModel.isReadyForLogin.value!!)
            }

            val emailCaptor = argumentCaptor<String>()
            verify(loginRepository, times(4)).isAccountLocked(emailCaptor.capture())
            assertEquals(loginViewModel.userInput.text.value, emailCaptor.firstValue)
            assertEquals(loginViewModel.userInput.text.value, emailCaptor.secondValue)
        }

    @Test
    fun `Login button is enable with valid email, valid password and not lock account`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            whenever(loginRepository.isAccountLocked(any())).doReturn(false)

            `Email is valid and no error`()
            `Password is valid and no error`()

            loginViewModel.isReadyForLogin.observeForTesting {
                Timber.e("result: ${loginViewModel.isReadyForLogin.value}")
                assertTrue(loginViewModel.isReadyForLogin.value!!)
            }
        }

    @Test
    fun `Login success, sessions has pending profile = false and pending password = false then next screen Map`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            val email = "test@gmail.com"
            val password = "12390293932"

            loginViewModel.userInput.text.value = email
            loginViewModel.passwordInput.text.value = password

            val sessions = Sessions(
                "apiKey",
                true,
                439L,
                32902L,
                personalAccountOption = false,
                profileDetailsPending = false,
                passwordUpdatePending = false
            )
            val state = Result.Success(sessions)

            whenever(loginRepository.login(any())).doReturn(state)

            loginViewModel.login()

            loginViewModel.loginResult.observeForTesting {
                assertEquals(sessions, loginViewModel.loginResult.value?.getNullableData())
            }
            loginViewModel.nextScreen.observeForTesting {
                assertEquals(Screen.MAP, loginViewModel.nextScreen.value)
            }
            val sessionBodyCaptor = argumentCaptor<SessionBody>()
            verify(loginRepository).login(sessionBodyCaptor.capture())
            verify(loginRepository).getCacheSessions()
            val user = sessionBodyCaptor.firstValue.user
            assertEquals(email, user.email)
            assertEquals(password, user.password)
        }

    @Test
    fun `Login success, sessions has pending profile = true, pending password = false then next screen is Update profile`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            val email = "test@gmail.com"
            val password = "12390293932"

            loginViewModel.userInput.text.value = email
            loginViewModel.passwordInput.text.value = password

            val sessions = Sessions(
                "apiKey",
                true,
                439L,
                32902L,
                personalAccountOption = false,
                profileDetailsPending = true,
                passwordUpdatePending = false
            )
            val state = Result.Success(sessions)

            whenever(loginRepository.login(any())).doReturn(state)

            loginViewModel.login()

            loginViewModel.loginResult.observeForTesting {
                assertEquals(sessions, loginViewModel.loginResult.value?.getNullableData())
            }
            loginViewModel.nextScreen.observeForTesting {
                assertEquals(Screen.UPDATE_PROFILE, loginViewModel.nextScreen.value)
            }
            val sessionBodyCaptor = argumentCaptor<SessionBody>()
            verify(loginRepository).login(sessionBodyCaptor.capture())
            verify(loginRepository).getCacheSessions()

            val user = sessionBodyCaptor.firstValue.user
            assertEquals(email, user.email)
            assertEquals(password, user.password)
        }

    @Test
    fun `Login success, sessions has pending profile = true, pending password = true then next screen is Update profile`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            val email = "test@gmail.com"
            val password = "12390293932"

            loginViewModel.userInput.text.value = email
            loginViewModel.passwordInput.text.value = password

            val sessions = Sessions(
                "apiKey",
                true,
                439L,
                32902L,
                personalAccountOption = false,
                profileDetailsPending = true,
                passwordUpdatePending = true
            )
            val state = Result.Success(sessions)

            whenever(loginRepository.login(any())).doReturn(state)

            loginViewModel.login()

            loginViewModel.loginResult.observeForTesting {
                assertEquals(sessions, loginViewModel.loginResult.value?.getNullableData())
            }
            loginViewModel.nextScreen.observeForTesting {
                assertEquals(Screen.UPDATE_PROFILE, loginViewModel.nextScreen.value)
            }
            val sessionBodyCaptor = argumentCaptor<SessionBody>()
            verify(loginRepository).login(sessionBodyCaptor.capture())
            verify(loginRepository).getCacheSessions()

            val user = sessionBodyCaptor.firstValue.user
            assertEquals(email, user.email)
            assertEquals(password, user.password)
        }

    @Test
    fun `Login success, sessions has pending profile = false, pending password = true then next screen is Update password`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            val email = "test@gmail.com"
            val password = "12390293932"

            loginViewModel.userInput.text.value = email
            loginViewModel.passwordInput.text.value = password

            val sessions = Sessions(
                "apiKey",
                true,
                439L,
                32902L,
                personalAccountOption = false,
                profileDetailsPending = false,
                passwordUpdatePending = true
            )
            val state = Result.Success(sessions)

            whenever(loginRepository.login(any())).doReturn(state)

            loginViewModel.login()

            loginViewModel.loginResult.observeForTesting {
                assertEquals(sessions, loginViewModel.loginResult.value?.getNullableData())
            }
            loginViewModel.nextScreen.observeForTesting {
                assertEquals(Screen.UPDATE_PASSWORD, loginViewModel.nextScreen.value)
            }
            val sessionBodyCaptor = argumentCaptor<SessionBody>()
            verify(loginRepository).login(sessionBodyCaptor.capture())
            verify(loginRepository).getCacheSessions()

            val user = sessionBodyCaptor.firstValue.user
            assertEquals(email, user.email)
            assertEquals(password, user.password)
        }

    @Test
    fun `Login Error`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        val email = "test@gmail.com"
        val password = "12390293932"
        whenever(application.getString(R.string.login_email_or_password_incorrect)).doReturn(
            EMAIL_OR_PASSWORD_INCORRECT
        )

        loginViewModel.userInput.text.value = email
        loginViewModel.passwordInput.text.value = password

        val exception = NullPointerException()

        whenever(loginRepository.login(any())).doReturn(Result.Error<Sessions>(null, exception))

        loginViewModel.login()

        val sessionBodyCaptor = argumentCaptor<SessionBody>()
        verify(loginRepository).login(sessionBodyCaptor.capture())

        val user = sessionBodyCaptor.firstValue.user
        assertEquals(email, user.email)
        assertEquals(password, user.password)

        loginViewModel.loginResult.observeForTesting {
            val value = loginViewModel.loginResult.value
            assertTrue(value?.isError!!)
            assertNull(value.getNullableData())
            assertEquals(exception, (value as Result.Error).exception)
        }

        loginViewModel.nextScreen.observeForTesting {
            assertNull(loginViewModel.nextScreen.value)
            assertTrue(loginViewModel.userInput.isError)
            assertTrue(loginViewModel.passwordInput.isError)
            assertEquals(EMAIL_OR_PASSWORD_INCORRECT, loginViewModel.passwordInput.error.value)
            assertEquals(EMAIL_OR_PASSWORD_INCORRECT, loginViewModel.userInput.error.value)
            verify(application).getString(R.string.login_email_or_password_incorrect)
        }

        verify(loginRepository).getCacheSessions()
    }

    @Test
    fun `Login with a locked account`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            val email = "test@gmail.com"
            val password = "12390293932"
            val responseError = ResponseError(
                errorCodes = ErrorCodes(listOf(ErrorCode("account_locked")))
            )

            loginViewModel.userInput.text.value = email
            loginViewModel.passwordInput.text.value = password

            val exception = SaferMeException(responseError)
            whenever(loginRepository.isAccountLocked(email)).doReturn(true)
            whenever(loginRepository.login(any())).doReturn(Result.Error<Sessions>(null, exception))

            loginViewModel.login()

            val sessionBodyCaptor = argumentCaptor<SessionBody>()
            verify(loginRepository).login(sessionBodyCaptor.capture())
            val user = sessionBodyCaptor.firstValue.user
            assertEquals(email, user.email)
            assertEquals(password, user.password)

            loginViewModel.loginResult.observeForTesting {
                val value = loginViewModel.loginResult.value
                assertTrue(value?.isError!!)
                assertNull(value.getNullableData())
                assertEquals(exception, (value as Result.Error).exception)
            }

            loginViewModel.nextScreen.observeForTesting {
                assertNull(loginViewModel.nextScreen.value)
                assertTrue(loginViewModel.isAccountLocked.value!!)
                assertTrue(loginViewModel.userInput.isError)
                assertEquals(" ", loginViewModel.passwordInput.error.value)
                assertTrue(loginViewModel.passwordInput.isError)
                assertEquals(" ", loginViewModel.userInput.error.value)
            }

            val emailCaptor = argumentCaptor<String>()
            verify(loginRepository).isAccountLocked(emailCaptor.capture())
            assertEquals(email, emailCaptor.firstValue)

            verify(loginRepository).getCacheSessions()
        }

    @Test
    fun `select Staging environment`() = runBlockingTest {
        _isStagingLiveData.value = true
        loginViewModel.selectStaging()

        loginViewModel.isStaging.observeForTesting {
            assertTrue(loginViewModel.isStaging.value!!)
        }

        verify(loginRepository).useStagingEnv()
        verify(loginRepository, times(2)).syncBrand()
    }

    @Test
    fun `select Live environment`() = runBlockingTest {
        _isStagingLiveData.value = false
        loginViewModel.selectLive()

        loginViewModel.isStaging.observeForTesting {
            assertFalse(loginViewModel.isStaging.value!!)
        }
        verify(loginRepository).useLiveEnv()
        verify(loginRepository, times(2)).syncBrand()
    }

    companion object {
        private const val EMAIL_LABEL = "Email"
        private const val PASSWORD_LABEL = "Password"
        private const val PASSWORD_TOO_SHORT = "Password is too short"
        private const val PASSWORD_EMPTY_OR_NULL = "Password is empty"
        private const val EMAIL_EMPTY_OR_NULL = "Email is empty"
        private const val EMAIL_INVALID = "Email is invalid"
        private const val EMAIL_OR_PASSWORD_INCORRECT = "Email or password is incorrect"
    }
}
