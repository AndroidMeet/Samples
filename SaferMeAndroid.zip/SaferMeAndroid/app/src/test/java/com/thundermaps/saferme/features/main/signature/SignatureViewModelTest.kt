package com.thundermaps.saferme.features.main.signature

import android.app.Application
import android.graphics.Bitmap
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.saferme.obsidian.FileAttachmentManager
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.domain.models.Signature
import java.io.FileOutputStream
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@ExperimentalCoroutinesApi
class SignatureViewModelTest : BaseTest() {
    private val application: Application = mock {
        on { getString(R.string.hint_name) } doReturn NAME_LABEL
    }
    private val testContextProvider = TestContextProvider()
    private val fileAttachmentManager: FileAttachmentManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { fileAttachmentManager } doReturn fileAttachmentManager
    }
    private lateinit var viewModel: SignatureViewModel

    private fun createViewModel() {
        viewModel = SignatureViewModel(application, obsidianApi, testContextProvider)
    }

    @After
    fun tearDown() {
        verify(application).getString(R.string.hint_name)
        verifyNoMoreInteractions(application, obsidianApi, fileAttachmentManager)
    }

    @Test
    fun `verify default value`() {
        createViewModel()

        assertEquals(NAME_LABEL, viewModel.nameInput.title)
        val signature = viewModel.signature.value?.getNullableData()
        assertNull(signature)
        assertNull(signature?.formFieldSignature)

        assertFalse(viewModel.isReadyToPopBack)
        verifyIsReady(false)
    }

    @Test
    fun `verify update signature`() {
        val signatureMock: Signature = mock()
        createViewModel()

        viewModel.updateSignature(signatureMock)

        assertFalse(viewModel.isReadyToPopBack)
        assertEquals(signatureMock, viewModel.signature.value?.getNullableData())
    }

    @Test
    fun `verify change signature then signature image will be changed`() = runBlockingTest {
        val sign = mock<Bitmap>()
        createViewModel()
        viewModel.updateSign(sign)

        verifySetSign(sign)
        verifyIsReady(false)
        verifyNoMoreInteractions(sign)
    }

    @Test
    fun `verify change signature and name then ready to save`() {
        val sign = mock<Bitmap>()
        val name = "John Lee"
        createViewModel()

        viewModel.nameInput.text.value = name
        viewModel.updateSign(sign)

        verifySetSign(sign)
        verifyIsReady(true)
    }

    @Test
    fun `verify submit signature`() = runBlockingTest {
        val sign = mock<Bitmap>()
        val name = "John Lee"
        createViewModel()

        viewModel.nameInput.text.value = name
        viewModel.updateSign(sign)

        viewModel.submitSignature()

        verifySetSign(sign)
        verifyIsReady(true)
        verify(obsidianApi).fileAttachmentManager
        val filepathArgumentCaptor = argumentCaptor<String>()
        verify(fileAttachmentManager).uploadPhoto(filepathArgumentCaptor.capture())
        assertTrue(filepathArgumentCaptor.firstValue.contains("sign.png"))
    }

    private fun verifySetSign(sign: Bitmap) {
        assertEquals(sign, viewModel.sign)
        val compressFormatArgumentCaptor = argumentCaptor<Bitmap.CompressFormat>()
        val percentageArgumentCaptor = argumentCaptor<Int>()
        val fileArgumentCaptor = argumentCaptor<FileOutputStream>()

        verify(sign).compress(
            compressFormatArgumentCaptor.capture(),
            percentageArgumentCaptor.capture(),
            fileArgumentCaptor.capture()
        )
        assertEquals(Bitmap.CompressFormat.PNG, compressFormatArgumentCaptor.firstValue)
        assertEquals(100, percentageArgumentCaptor.firstValue)
        verify(application).cacheDir
        verifyNoMoreInteractions(sign)
    }

    private fun verifyIsReady(expect: Boolean) {
        viewModel.isReadyToSave.observeForTesting {
            viewModel.isReadyToSave.value?.let {
                assertEquals(expect, it)
            }
        }
    }

    companion object {
        private const val NAME_LABEL = "Name *"
    }
}
