package com.thundermaps.saferme.features.main.profile

import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.features.main.profile.domain.Profile
import com.thundermaps.saferme.features.main.profile.domain.ProfileRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class ProfileViewModelTest : BaseTest() {
    private val mockProfile = mock<Profile>()
    private val testContextProvider = TestContextProvider()
    private val profileRepository = mock<ProfileRepository>()

    private lateinit var profileViewModel: ProfileViewModel

    @Before
    fun setup() {
        profileViewModel = ProfileViewModel(profileRepository, testContextProvider)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(profileRepository)
    }

    @Test
    fun `load profile success`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        val mockResult = Result.Success(mockProfile)
        whenever(profileRepository.getProfile()).doReturn(mockResult)

        profileViewModel.loadProfile()

        profileViewModel.profile.observeForTesting {
            assertEquals(mockProfile, profileViewModel.profile.value)
        }
        verify(profileRepository).getProfile()
    }

    @Test
    fun `load profile error`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        val mockResult = Result.Error(null, Exception("Error"))
        whenever(profileRepository.getProfile()).doReturn(mockResult)

        profileViewModel.loadProfile()

        profileViewModel.profile.observeForTesting {
            assertNull(profileViewModel.profile.value)
        }
        verify(profileRepository).getProfile()
    }
}
