package com.thundermaps.saferme.features.authentication.login.domain

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.features.authentication.login.domain.AccountLocker.Companion.DEFAULT_FAILURE_TIMES
import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.AfterClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class AccountLockerTest : BaseTest() {
    private val context = mock<Context>()
    private val editor = mock<SharedPreferences.Editor>()
    private val sharedPreferences = mock<SharedPreferences> {
        on { edit() } doReturn editor
    }

    private lateinit var accountLocker: AccountLocker

    @Before
    fun setUp() {
        mockkStatic(PreferenceManager::class)
        every { PreferenceManager.getDefaultSharedPreferences(context) } returns sharedPreferences
        accountLocker = AccountLocker(context)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(context, editor)
        tearDownClass()
    }

    @Test
    fun `account is failure login 6 times and reset app then allow login`() = runBlockingTest {
        val email = "test@gmail.com"
        whenever(sharedPreferences.getInt(email, DEFAULT_FAILURE_TIMES)).doReturn(6)

        assertFalse(accountLocker.isLocked(email))

        val argumentCaptor = argumentCaptor<String>()
        verify(sharedPreferences).getInt(argumentCaptor.capture(), eq(DEFAULT_FAILURE_TIMES))
        assertEquals(email, argumentCaptor.firstValue)
    }

    @Test
    fun `account is locked and failure at least one time after start`() = runBlockingTest {
        val email = "test@gmail.com"
        accountLocker.lockAccount(email)
        whenever(sharedPreferences.getInt(email, DEFAULT_FAILURE_TIMES)).doReturn(6)

        assertTrue(accountLocker.isLocked(email))

        val argumentCaptor = argumentCaptor<String>()
        verify(sharedPreferences).getInt(argumentCaptor.capture(), eq(DEFAULT_FAILURE_TIMES))
        assertEquals(email, argumentCaptor.firstValue)

        verify(sharedPreferences).edit()
        val emailCaptor = argumentCaptor<String>()
        val valueCaptor = argumentCaptor<Int>()
        verify(editor).putInt(emailCaptor.capture(), valueCaptor.capture())
        assertEquals(email, emailCaptor.firstValue)
        assertEquals(6, valueCaptor.firstValue)
        verify(editor).commit()
    }

    @Test
    fun `verify account is not locked`() = runBlockingTest {
        val email = "test@gmail.com"
        whenever(sharedPreferences.getInt(email, DEFAULT_FAILURE_TIMES)).doReturn(3)

        assertFalse(accountLocker.isLocked(email))

        val argumentCaptor = argumentCaptor<String>()
        verify(sharedPreferences).getInt(argumentCaptor.capture(), eq(DEFAULT_FAILURE_TIMES))
        assertEquals(email, argumentCaptor.firstValue)
    }

    @Test
    fun `verify locked`() = runBlockingTest {
        val email = "test@gmail.com"
        accountLocker.lockAccount(email)

        verify(sharedPreferences).edit()
        val emailCaptor = argumentCaptor<String>()
        val valueCaptor = argumentCaptor<Int>()
        verify(editor).putInt(emailCaptor.capture(), valueCaptor.capture())
        assertEquals(email, emailCaptor.firstValue)
        assertEquals(6, valueCaptor.firstValue)
        verify(editor).commit()
    }

    @Test
    fun `verify 2 accounts which one is locked and other not locked`() = runBlockingTest {
        `verify locked`()
        val lockedEmail = "test@gmail.com"
        val notLockedEmail = "locked@gmail.com"
        whenever(sharedPreferences.getInt(lockedEmail, DEFAULT_FAILURE_TIMES)).doReturn(8)
        whenever(sharedPreferences.getInt(notLockedEmail, DEFAULT_FAILURE_TIMES)).doReturn(3)

        assertTrue(accountLocker.isLocked(lockedEmail))
        assertFalse(accountLocker.isLocked(notLockedEmail))

        val argumentCaptor = argumentCaptor<String>()
        verify(sharedPreferences, times(2)).getInt(
            argumentCaptor.capture(), eq(
                DEFAULT_FAILURE_TIMES
            )
        )

        assertEquals(lockedEmail, argumentCaptor.firstValue)
        assertEquals(notLockedEmail, argumentCaptor.secondValue)
    }

    @Test
    fun `verify reset lock account`() = runBlockingTest {
        val email = "test@gmail.com"
        accountLocker.resetLockedAccount(email)

        verify(sharedPreferences).edit()
        val emailCaptor = argumentCaptor<String>()
        verify(editor).remove(emailCaptor.capture())
        assertEquals(email, emailCaptor.firstValue)
        verify(editor).commit()
    }

    @Test
    fun `verify increase time account`() = runBlockingTest {
        val email = "test@gmail.com"
        whenever(sharedPreferences.getInt(email, DEFAULT_FAILURE_TIMES)).doReturn(2)
        accountLocker.increaseFailureTimes(email)

        verify(sharedPreferences).edit()
        val emailCaptor = argumentCaptor<String>()
        val valueCaptor = argumentCaptor<Int>()
        verify(editor).putInt(emailCaptor.capture(), valueCaptor.capture())
        assertEquals(email, emailCaptor.firstValue)
        assertEquals(3, valueCaptor.firstValue)
        verify(editor).commit()
    }

    companion object {
        @AfterClass
        @JvmStatic
        fun tearDownClass() {
            unmockkAll()
        }
    }
}
