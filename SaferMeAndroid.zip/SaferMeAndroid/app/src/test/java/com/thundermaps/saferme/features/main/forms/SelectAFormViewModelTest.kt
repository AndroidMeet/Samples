package com.thundermaps.saferme.features.main.forms

import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.saferme.obsidian.ChannelManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.store.resources.ObsidianChannel
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class SelectAFormViewModelTest : BaseTest() {
    private val channelManager: ChannelManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { channelsManager } doReturn channelManager
    }
    private val testContextProvider = TestContextProvider()

    private lateinit var selectAFormViewModel: SelectAFormViewModel

    @Before
    fun setUp() {
        selectAFormViewModel = SelectAFormViewModel(obsidianApi, testContextProvider)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(channelManager, obsidianApi)
    }

    @Test
    fun `verify synChannels`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        val channels = listOf<ObsidianChannel>(mock(), mock())
        val liveData = MutableLiveData(channels)
        whenever(channelManager.readAll()).doReturn(liveData)

        selectAFormViewModel.fetchChannels()

        selectAFormViewModel.channels.observeForTesting {
            assertEquals(channels, selectAFormViewModel.channels.value)
        }

        assertFalse(selectAFormViewModel.canAutoSync)
        verify(channelManager).syncChannels()
        verify(channelManager).readAll()
        verify(obsidianApi, times(2)).channelsManager
    }

    @Test
    fun `verify autoSync`() {
        selectAFormViewModel.resetNumberOfSync()

        assertTrue(selectAFormViewModel.canAutoSync)
    }
}
