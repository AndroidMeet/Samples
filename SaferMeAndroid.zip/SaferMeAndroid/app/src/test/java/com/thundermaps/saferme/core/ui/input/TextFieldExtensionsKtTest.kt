package com.thundermaps.saferme.core.ui.input

import com.thundermaps.saferme.BaseTest
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@ExperimentalCoroutinesApi
class TextFieldExtensionsKtTest : BaseTest() {
    @Test
    fun `Text field is null and have error`() {
        val errorString = "Text is null"
        val textFieldInput = TextFieldInput("test")

        val result = textFieldInput.isEmptyOrNull(errorString)
        assertTrue(result)
        assertTrue(textFieldInput.isError)
        assertEquals(errorString, textFieldInput.error.value)
    }

    @Test
    fun `Text field is empty and have error`() {
        val errorString = "Text is empty"
        val textFieldInput = TextFieldInput("test")
        textFieldInput.text.value = ""

        val result = textFieldInput.isEmptyOrNull(errorString)
        assertTrue(result)
        assertTrue(textFieldInput.isError)
        assertEquals(errorString, textFieldInput.error.value)
    }

    @Test
    fun `Text field is not null, empty and no error`() {
        val errorString = "Text is empty"
        val textFieldInput = TextFieldInput("test")
        textFieldInput.text.value = "Valid"

        val result = textFieldInput.isEmptyOrNull(errorString)
        assertFalse(result)
        assertFalse(textFieldInput.isError)
        assertNull(textFieldInput.error.value)
    }

    @Test
    fun `Text field email is empty and have error`() {
        val errorString = "Text is empty"
        val textFieldInput = TextFieldInput("test")
        textFieldInput.text.value = ""

        val result = textFieldInput.verifyEmail(errorString, null)
        assertTrue(result)
        assertTrue(textFieldInput.isError)
        assertEquals(errorString, textFieldInput.error.value)
    }

    @Test
    fun `Text field email is null and have error`() {
        val errorString = "Text is null"
        val textFieldInput = TextFieldInput("test")
        textFieldInput.text.value = ""

        val result = textFieldInput.verifyEmail(errorString, null)
        assertTrue(result)
        assertTrue(textFieldInput.isError)
        assertEquals(errorString, textFieldInput.error.value)
    }

    @Test
    fun `Text field email is not null, empty but invalid`() = runBlockingTest {
        val emailInvalid = "Email is invalid"
        val textFieldInput = TextFieldInput("test")
        textFieldInput.text.value = "test@saferrr"

        val result = textFieldInput.verifyEmail(null, emailInvalid)
        assertTrue(result)
        assertTrue(textFieldInput.isError)
        assertEquals(emailInvalid, textFieldInput.error.value)
    }

    @Test
    fun `Text field email is not null, empty and valid`() = runBlockingTest {
        val errorString = "Error"
        val emailInvalid = "Email is invalid"
        val textFieldInput = TextFieldInput("test")
        textFieldInput.text.value = "test@gmail.com"

        val result = textFieldInput.verifyEmail(errorString, emailInvalid)
        assertFalse(result)
        assertFalse(textFieldInput.isError)
        assertNull(textFieldInput.error.value)
    }
}
