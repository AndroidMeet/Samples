package com.thundermaps.saferme.features.main.task

import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.saferme.obsidian.ReportManager
import com.saferme.obsidian.TaskManager
import com.saferme.obsidian.authentication.SessionsManager
import com.saferme.obsidian.sync.resources.ReportSync
import com.saferme.obsidian.sync.resources.TaskSync
import com.thundermaps.apilib.android.api.responses.models.UserDetails
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.SaferMeApplication
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.features.main.tasks.TasksViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Test

@ExperimentalCoroutinesApi
class TaskViewModelTest : BaseTest() {
    private val application: SaferMeApplication = mock {
        on { getString(R.string.anonymous) } doReturn anonymous
    }

    private val reportSyncMock: ReportSync = mock()
    private val reportManager: ReportManager = mock {
        on { reportSync } doReturn reportSyncMock
    }

    private val taskSyncMock: TaskSync = mock()
    private val taskManager: TaskManager = mock {
        on { TaskSync() } doReturn taskSyncMock
    }
    private val sessionsManager: SessionsManager = mock()
    private val userDetailsMock = mock<UserDetails> {
        on { id } doReturn USER_ID
    }

    private val testContextProvider = TestContextProvider()
    private lateinit var taskViewModel: TasksViewModel

    private fun createViewModel() {
        taskViewModel = TasksViewModel(
            application, taskManager, reportManager, sessionsManager, testContextProvider
        )
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(
            application,
            taskManager,
            taskSyncMock,
            sessionsManager,
            userDetailsMock
        )
    }

    @Test
    fun `verify read sync task when viewModel is initialed with user details is null`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {

            createViewModel()

            verify(taskManager).TaskSync()
            verify(taskSyncMock).synchronize()
            verify(sessionsManager).userDetails
        }

    companion object {
        private const val USER_ID = 3290L
        private const val anonymous = "anonymous"
    }
}
