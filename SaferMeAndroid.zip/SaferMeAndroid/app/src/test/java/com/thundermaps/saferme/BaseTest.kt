package com.thundermaps.saferme

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import org.junit.Rule
import org.junit.rules.TestRule

open class BaseTest {
    @Rule
    @JvmField
    val rule: TestRule = InstantTaskExecutorRule()
}
