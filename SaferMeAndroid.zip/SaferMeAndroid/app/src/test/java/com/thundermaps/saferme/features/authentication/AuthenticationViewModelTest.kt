package com.thundermaps.saferme.features.authentication

import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class AuthenticationViewModelTest : BaseTest() {
    private val testContextProvider = TestContextProvider()
    private val repo: AuthenticationRepository = mock()
    private lateinit var viewModel: AuthenticationViewModel

    @Before
    fun setUp() {
        viewModel = AuthenticationViewModel(repo, testContextProvider)
    }

    @Test
    fun `verify get user details success`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            viewModel.getUserDetails()

            verify(repo).getUserDetails()
        }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(repo)
    }
}
