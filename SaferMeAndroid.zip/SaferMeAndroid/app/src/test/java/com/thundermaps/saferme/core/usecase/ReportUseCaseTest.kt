package com.thundermaps.saferme.core.usecase

import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.observeForTesting
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class ReportUseCaseTest : BaseTest() {
    private lateinit var reportUseCase: ReportUseCase

    @Before
    fun setup() {
        reportUseCase = ReportUseCase()
    }

    @Test
    fun `verify default showing is false`() {
        reportUseCase.showingReport.observeForTesting {
            assertFalse(reportUseCase.showingReport.value!!)
        }
    }

    @Test
    fun `verify active report then value will be true`() {
        reportUseCase.activateReport()

        reportUseCase.showingReport.observeForTesting {
            assertTrue(reportUseCase.showingReport.value!!)
        }
    }

    @Test
    fun `verify de-active report then value will be false`() {
        reportUseCase.deactivateReport()

        reportUseCase.showingReport.observeForTesting {
            assertFalse(reportUseCase.showingReport.value!!)
        }
    }

    @Test
    fun `verify reset creating report`() {
        reportUseCase.resetCreatingReport()
        reportUseCase.creatingReport.observeForTesting {
            assertFalse(reportUseCase.creatingReport.value!!)
        }
    }

    @Test
    fun `verify create report clicked`() {
        reportUseCase.createReportButtonClicked()

        assertFalse(reportUseCase.showingReport.value!!)
        assertTrue(reportUseCase.creatingReport.value!!)
    }
}
