package com.thundermaps.saferme.features.authentication

import android.content.res.Resources
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.times
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.raygun.raygun4android.RaygunClient
import com.raygun.raygun4android.messages.shared.RaygunUserInfo
import com.saferme.obsidian.MeManager
import com.saferme.obsidian.ObsidianApi
import com.saferme.obsidian.StateManager
import com.saferme.obsidian.authentication.SessionsManager
import com.thundermaps.apilib.android.api.responses.models.Clients
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.apilib.android.api.responses.models.Sessions
import com.thundermaps.apilib.android.api.responses.models.UserDetails
import com.thundermaps.saferme.BaseTest
import io.mockk.Runs
import io.mockk.every
import io.mockk.just
import io.mockk.mockkStatic
import io.mockk.slot
import io.mockk.unmockkAll
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.AfterClass
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class AuthenticationRepositoryTest : BaseTest() {
    private val userDetails: UserDetails = mock {
        on { id } doReturn USER_ID
        on { firstName } doReturn FIRST_NAME
        on { lastName } doReturn LAST_NAME
        on { email } doReturn EMAIL
    }

    private val sessions = mock<Sessions> {
        on { teamId } doReturn TEAM_ID
    }
    private val sessionsManager: SessionsManager = mock {
        on { getSessions() } doReturn sessions
    }
    private val stateManager: StateManager = mock()
    private val myInfoManager: MeManager = mock()
    private val obsidianApi: ObsidianApi = mock {
        on { provideSessionsManager() } doReturn sessionsManager
        on { meManager } doReturn myInfoManager
        on { stateManager } doReturn stateManager
    }

    private lateinit var authenticationRepository: AuthenticationRepository

    @Before
    fun setUp() {
        authenticationRepository = AuthenticationRepository(obsidianApi)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(obsidianApi, sessionsManager, myInfoManager, userDetails, sessions, stateManager)
        tearDownClass()
    }

    @Test
    fun `get user details success`() = runBlockingTest {
        val mockResult = Result.Success(userDetails)
        whenever(myInfoManager.getUserDetails()).doReturn(mockResult)
        val slot = slot<RaygunUserInfo>()
        mockkStatic(RaygunClient::class)
        every { RaygunClient.setUser(capture(slot)) } just Runs

        authenticationRepository.getUserDetails()

        val userInfo = slot.captured
        assertEquals(USER_ID.toString(), userInfo.identifier)
        assertEquals(FIRST_NAME, userInfo.firstName)
        assertEquals("$FIRST_NAME $LAST_NAME", userInfo.fullName)
        assertEquals(EMAIL, userInfo.email)

        val userDetailsArgumentCaptor = argumentCaptor<UserDetails>()
        verify(userDetails).id
        verify(userDetails, times(2)).firstName
        verify(userDetails).lastName
        verify(userDetails).email
        verifyProvideMeManagerAndSessionsManager()
        verify(sessionsManager).updateUserDetails(userDetailsArgumentCaptor.capture())
        assertEquals(userDetails, userDetailsArgumentCaptor.firstValue)

        verify(myInfoManager).getUserDetails()
        verifySwitchTeam()
    }

    @Test
    fun `if user details is exist then will not request getUserDetails with 'getUserDetailsIfNeeded'`() =
        runBlockingTest {
            val userDetailsMock = mock<UserDetails>()

            whenever(sessionsManager.userDetails).thenReturn(userDetailsMock)

            authenticationRepository.getUserDetailsIfNeeded()

            verify(sessionsManager).userDetails
            verify(obsidianApi).provideSessionsManager()
        }

    @Test
    fun `if user details = null then will request getUserDetails with 'getUserDetailsIfNeeded'`() =
        runBlockingTest {
            val mockResult = Result.Success(userDetails)
            whenever(myInfoManager.getUserDetails()).doReturn(mockResult)
            val slot = slot<RaygunUserInfo>()
            mockkStatic(RaygunClient::class)
            every { RaygunClient.setUser(capture(slot)) } just Runs

            authenticationRepository.getUserDetailsIfNeeded()

            val userInfo = slot.captured
            assertEquals(USER_ID.toString(), userInfo.identifier)
            assertEquals(FIRST_NAME, userInfo.firstName)
            assertEquals("$FIRST_NAME $LAST_NAME", userInfo.fullName)
            assertEquals(EMAIL, userInfo.email)

            val userDetailsArgumentCaptor = argumentCaptor<UserDetails>()
            verify(userDetails).id
            verify(userDetails, times(2)).firstName
            verify(userDetails).lastName
            verify(userDetails).email
            verify(sessionsManager).updateUserDetails(userDetailsArgumentCaptor.capture())
            assertEquals(userDetails, userDetailsArgumentCaptor.firstValue)

            verify(myInfoManager).getUserDetails()
            verify(sessionsManager).userDetails
            verifySwitchTeam()
            verifyProvideMeManagerAndSessionsManager()
        }

    @Test
    fun `get user details error`() = runBlockingTest {
        val exception: Resources.NotFoundException = mock()
        val mockResult = Result.Error<UserDetails>(null, exception)
        whenever(myInfoManager.getUserDetails()).doReturn(mockResult)

        authenticationRepository.getUserDetails()

        verifyProvideMeManagerAndSessionsManager()
        verify(myInfoManager).getUserDetails()
        verifyNoMoreInteractions(exception)
    }

    @Test
    fun `get user clients success`() = runBlockingTest {
        val mockResult = Result.Success(clients)
        whenever(myInfoManager.getClients()).doReturn(mockResult)

        authenticationRepository.getClients()

        verify(sessionsManager).updateClients(clients)
        verify(myInfoManager).getClients()
        verifyProvideMeManagerAndSessionsManager()
    }

    @Test
    fun `if clients is exist then will not request getClients with 'getClientsIfNeeded'`() = runBlockingTest {
        whenever(sessionsManager.clients).thenReturn(clients)

        authenticationRepository.getClientsIfNeeded()

        verify(sessionsManager).clients
        verify(obsidianApi).provideSessionsManager()
    }

    @Test
    fun `if clients = null then will request getClients with 'getClientsIfNeeded'`() = runBlockingTest {
        val mockResult = Result.Success(clients)
        whenever(myInfoManager.getClients()).doReturn(mockResult)

        authenticationRepository.getClientsIfNeeded()

        verify(sessionsManager).updateClients(clients)
        verify(myInfoManager).getClients()
        verify(sessionsManager).clients
        verifyProvideMeManagerAndSessionsManager()
    }

    @Test
    fun `get clients error`() = runBlockingTest {
        val exception: Resources.NotFoundException = mock()
        val mockResult = Result.Error<Clients>(null, exception)
        whenever(myInfoManager.getClients()).doReturn(mockResult)

        authenticationRepository.getClients()

        verify(myInfoManager).getClients()

        verifyNoMoreInteractions(exception)
        verifyProvideMeManagerAndSessionsManager()
    }

    private suspend fun verifySwitchTeam() {
        verify(sessionsManager).getSessions()
        verify(sessions).teamId
        verify(obsidianApi).stateManager
        val teamIdArgumentCaptor = argumentCaptor<Int>()
        verify(stateManager).switchTeamAndSyncStates(teamIdArgumentCaptor.capture())
        assertEquals(TEAM_ID.toInt(), teamIdArgumentCaptor.firstValue)
    }

    private fun verifyProvideMeManagerAndSessionsManager() {
        verify(obsidianApi).meManager
        verify(obsidianApi).provideSessionsManager()
    }

    companion object {
        private const val USER_ID = 3290L
        private const val EMAIL = "aabc@gmail.com"
        private const val FIRST_NAME = "first"
        private const val LAST_NAME = "last"
        private const val TEAM_ID = 392L
        @AfterClass
        @JvmStatic
        fun tearDownClass() {
            unmockkAll()
        }

        private val clients = Clients(
            isPushCapable = false,
            pushNotificationEnabled = true,
            radius = 456.0f,
            badge = 39,
            channels = emptyList()
        )
    }
}
