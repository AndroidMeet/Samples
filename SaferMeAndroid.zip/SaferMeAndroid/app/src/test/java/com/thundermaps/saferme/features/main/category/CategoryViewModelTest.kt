package com.thundermaps.saferme.features.main.category

import androidx.lifecycle.MutableLiveData
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.saferme.obsidian.CategoryManager
import com.saferme.obsidian.ObsidianApi
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.core.coroutine.TestContextProvider
import com.thundermaps.saferme.core.coroutine.observeForTesting
import com.thundermaps.saferme.core.ui.extensions.replace
import com.thundermaps.saferme.features.main.category.CategoryTestData.CHANNEL_ID
import com.thundermaps.saferme.features.main.category.CategoryTestData.categories
import com.thundermaps.saferme.features.main.category.model.CategoryData
import com.thundermaps.saferme.features.main.category.model.DepthLevel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class CategoryViewModelTest : BaseTest() {
    private val categoryManager: CategoryManager = mock {
        on { getCategories(any()) } doReturn MutableLiveData(categories)
    }
    private val obsidianApi: ObsidianApi = mock {
        on { categoryManager } doReturn categoryManager
    }

    private lateinit var categoryViewModel: CategoryViewModel

    private val testContextProvider = TestContextProvider()

    @Before
    fun setUp() {
        categoryViewModel = CategoryViewModel(obsidianApi, testContextProvider)
        categoryViewModel.updateChannelId(CHANNEL_ID)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(categoryManager, obsidianApi)
    }

    @Test
    fun `verify sync categories`() = testContextProvider.testCoroutineDispatcher.runBlockingTest {
        categoryViewModel.syncCategory()

        verify(obsidianApi).categoryManager

        val channelIdCaptor = argumentCaptor<Int>()
        verify(categoryManager).syncCategory(channelIdCaptor.capture())
        assertEquals(CHANNEL_ID, channelIdCaptor.firstValue)
    }

    @Test
    fun `verify getCategories categories`() =
        testContextProvider.testCoroutineDispatcher.runBlockingTest {
            val categoryLiveData = categoryViewModel.getSavedCategories()

            categoryLiveData.observeForTesting {
                assertEquals(categories, categoryLiveData.value)

                verify(obsidianApi).categoryManager

                val channelIdCaptor = argumentCaptor<Int>()
                verify(categoryManager).getCategories(channelIdCaptor.capture())
                assertEquals(CHANNEL_ID, channelIdCaptor.firstValue)
            }
        }

    @Test
    fun `verify update categories data`() {
        categoryViewModel.updateCategoryData(categories)

        categoryViewModel.categories.observeForTesting {
            assertEquals(
                categories.filter { it.depth == 1 }.map { CategoryData.of(it, false) },
                categoryViewModel.categories.value
            )
        }
    }

    @Test
    fun `verify select level 1 category`() {
        categoryViewModel.updateCategoryData(categories)

        verifySelectLevel1Category()
    }

    @Test
    fun `verify select one category level 1 then select category level 1`() {
        categoryViewModel.updateCategoryData(categories)

        val previousSelectedItem = level1Categories.last()

        verifySelectLevel1AfterSelectOtherCategory(previousSelectedItem)
    }

    @Test
    fun `verify select one category level 2 then select category level 1`() {
        categoryViewModel.updateCategoryData(categories)

        val previousSelectedItem = allCategories.first { it.depth == DepthLevel.SECOND_LEVEL }

        verifySelectLevel1AfterSelectOtherCategory(previousSelectedItem)
    }

    @Test
    fun `verify select one category level 3 then select category level 1`() {
        categoryViewModel.updateCategoryData(categories)

        val previousSelectedItem = allCategories.first { it.depth == DepthLevel.THIRD_LEVEL }

        verifySelectLevel1AfterSelectOtherCategory(previousSelectedItem)
    }

    private fun verifySelectLevel1AfterSelectOtherCategory(item: CategoryData) {
        categoryViewModel.updateCategoryData(categories)

        categoryViewModel.onItemSelect(item)

        verifySelectLevel1Category()
    }

    private fun verifySelectLevel1Category() {
        val selectItem = level1Categories.first()
        categoryViewModel.onItemSelect(selectItem)

        val expectedItems = level1Categories.toMutableList()
        val selectedItem = selectItem.copy(isSelected = true)
        val childrenSelectItem = allCategories.filter { it.parentId == selectItem.id }
        expectedItems.replace(selectItem, selectedItem)

        val index = expectedItems.indexOf(selectedItem)
        expectedItems.addAll(index + 1, childrenSelectItem)

        categoryViewModel.categories.observeForTesting {
            categoryViewModel.categories.value?.let { list ->
                assertTrue(list.contains(selectedItem))
                assertEquals(expectedItems, list)
            }
        }
    }

    @Test
    fun `verify select Level 2 category`() {
        categoryViewModel.updateCategoryData(categories)
        verifySelectLevel2Category()
    }

    @Test
    fun `verify select Level 2, then level 2 category`() {
        categoryViewModel.updateCategoryData(categories)

        val level1SelectItem = level1Categories.first()
        val siblingOfSelectItems = allCategories.filter { it.parentId == level1SelectItem.id }

        val previous = siblingOfSelectItems.last()
        categoryViewModel.onItemSelect(previous)

        verifySelectLevel2Category()
    }

    @Test
    fun `verify select Level 3 of sibling, then level 2 category`() {
        categoryViewModel.updateCategoryData(categories)

        val level1SelectItem = level1Categories.first()
        val siblingOfSelectItems = allCategories.filter { it.parentId == level1SelectItem.id }

        val sibling = siblingOfSelectItems.last()
        val previousSelectItem = allCategories.first { it.parentId == sibling.id }
        categoryViewModel.onItemSelect(previousSelectItem)

        verifySelectLevel2Category()
    }

    @Test
    fun `verify select Level 3 child of Level 2 then level 2 category`() {
        categoryViewModel.updateCategoryData(categories)

        val level1SelectItem = level1Categories.first()
        val siblingOfSelectItems = allCategories.filter { it.parentId == level1SelectItem.id }

        val category = siblingOfSelectItems.first()
        val previousSelectItem = allCategories.first { it.parentId == category.id }
        categoryViewModel.onItemSelect(previousSelectItem)

        verifySelectLevel2Category()
    }

    private fun verifySelectLevel2Category() {
        val expectedItems = mutableListOf<CategoryData>().also { it.addAll(level1Categories) }
        val level1SelectItem = level1Categories.first()
        val siblingOfSelectItems = allCategories.filter { it.parentId == level1SelectItem.id }

        val selectItem = siblingOfSelectItems.first()
        categoryViewModel.onItemSelect(selectItem)

        val indexOfParent = expectedItems.indexOf(level1SelectItem)
        expectedItems.replace(level1SelectItem, level1SelectItem.copy(isSelected = true))

        expectedItems.addAll(indexOfParent + 1, siblingOfSelectItems)
        val indexOfSelectItem = expectedItems.indexOf(selectItem)
        val selectedItem = selectItem.copy(isSelected = true)
        expectedItems.replace(selectItem, selectedItem)

        val childrenSelectItem = allCategories.filter { it.parentId == selectItem.id }
        if (childrenSelectItem.isNotEmpty()) {
            expectedItems.addAll(indexOfSelectItem + 1, childrenSelectItem)
        }

        categoryViewModel.categories.observeForTesting {
            categoryViewModel.categories.value?.let { list ->
                assertTrue(list.contains(selectedItem))

                assertEquals(expectedItems, list)
            }
        }
    }

    @Test
    fun `verify select level 3 category`() {
        val expectedItems = mutableListOf<CategoryData>().also { it.addAll(level1Categories) }

        val selectItem = allCategories.first { it.depth == DepthLevel.THIRD_LEVEL }
        categoryViewModel.onItemSelect(selectItem)

        val siblingsOfSelectItem = allCategories.filter { it.parentId == selectItem.parentId }
        val parentOfSelectItem = allCategories.first { it.id == selectItem.parentId }
        val siblingsOfParentOfSelectItem =
            allCategories.filter { it.parentId == parentOfSelectItem.parentId }
        val parentOfParentOfSelectItem =
            allCategories.first { it.id == parentOfSelectItem.parentId }

        val indexOfParentOfParentOfSelectItem = expectedItems.indexOf(parentOfParentOfSelectItem)
        if (siblingsOfParentOfSelectItem.isNotEmpty()) {
            expectedItems.addAll(
                indexOfParentOfParentOfSelectItem + 1,
                siblingsOfParentOfSelectItem
            )
        }
        expectedItems.replace(
            parentOfParentOfSelectItem,
            parentOfParentOfSelectItem.copy(isSelected = true)
        )

        val indexOfParentOfSelectItem = expectedItems.indexOf(parentOfSelectItem)
        if (siblingsOfSelectItem.isNotEmpty()) {
            expectedItems.addAll(indexOfParentOfSelectItem + 1, siblingsOfSelectItem)
        }
        expectedItems.replace(parentOfSelectItem, parentOfSelectItem.copy(isSelected = true))

        val selectedItem = selectItem.copy(isSelected = true)
        expectedItems.replace(selectItem, selectedItem)

        categoryViewModel.categories.observeForTesting {
            categoryViewModel.categories.value?.let { list ->
                assertTrue(list.contains(selectedItem))
                assertEquals(expectedItems, list)
            }
        }
    }

    @Test
    fun `verify no children`() {
        categoryViewModel.updateCategoryData(categories)
        assertTrue(categoryViewModel.hasNoChildren(198663))
        assertFalse(categoryViewModel.hasNoChildren(198655))
    }

    @Test
    fun `get category titles which current category has no parent`() {
        categoryViewModel.updateCategoryData(categories)

        val titles = categoryViewModel.getCategoryTitles(null, titles = "sub11")
        assertEquals("sub11", titles)
    }

    @Test
    fun `get category titles which current category has parent`() {
        categoryViewModel.updateCategoryData(categories)

        val titles = categoryViewModel.getCategoryTitles(198654, titles = "sub11")
        assertEquals("sub11, Sub1, Private hazard", titles)
    }

    @Test
    fun `verify update category`() {
        val categoryData = CategoryData.of(categories.first { it.id == 198655 }, true)
        categoryViewModel.updateCategoryData(categories)
        val extendedCategory = categoryViewModel.getExtendedCategoryData(categoryData)

        assertEquals(categoryData, extendedCategory.categoryData)
        assertEquals("sub11, Sub1, Private hazard", extendedCategory.categoryTitles)
    }

    companion object {
        private val allCategories = categories.map { CategoryData.of(it, false) }
        private val level1Categories = allCategories.filter { it.depth == DepthLevel.FIRST_LEVEL }
    }
}
