package com.thundermaps.saferme.features.authentication.forgotpassword.sent

import android.app.Application
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.thundermaps.saferme.BaseTest
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.coroutine.observeForTesting
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@ExperimentalCoroutinesApi
class ForgotPasswordSentViewModelTest : BaseTest() {
    private val app: Application = mock()
    private lateinit var viewModel: ForgotPasswordSentViewModel

    @Before
    fun setUp() {
        viewModel = ForgotPasswordSentViewModel(app)
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(app)
    }

    @Test
    fun `update the sent email`() = runBlockingTest {
        val emailWithBoldHtml = "<b>$EMAIL_ADDRESS</b>"
        val dataResult = "$SENT_MESSAGE_PLACEHOLDER $emailWithBoldHtml"
        whenever(
            app.getString(
                R.string.forgot_password_send_message_placeholder,
                emailWithBoldHtml
            )
        ).doReturn(dataResult)

        viewModel.updateEmail(EMAIL_ADDRESS)

        viewModel.sentSpannedMessage.observeForTesting {
            assertEquals(dataResult.toSpannedText(), viewModel.sentSpannedMessage.value)
        }

        val emailCaptor = argumentCaptor<String>()
        val holderCaptor = argumentCaptor<Int>()
        verify(app).getString(holderCaptor.capture(), emailCaptor.capture())
        assertEquals(R.string.forgot_password_send_message_placeholder, holderCaptor.firstValue)
        assertEquals(emailWithBoldHtml, emailCaptor.firstValue)
    }

    companion object {
        private const val EMAIL_ADDRESS = "test@gmail.com"
        private const val SENT_MESSAGE_PLACEHOLDER = "We have emailed a password reset link to"
    }
}
