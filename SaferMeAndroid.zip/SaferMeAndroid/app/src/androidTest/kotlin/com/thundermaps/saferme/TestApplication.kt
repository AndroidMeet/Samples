package com.thundermaps.saferme

import dagger.hilt.android.testing.CustomTestApplication

@Suppress("unused")
@CustomTestApplication(BaseApplication::class)
interface TestApplication
