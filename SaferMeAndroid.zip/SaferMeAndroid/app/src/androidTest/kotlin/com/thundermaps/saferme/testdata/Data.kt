package com.thundermaps.saferme.testdata

import com.thundermaps.apilib.android.api.responses.models.ErrorCode
import com.thundermaps.apilib.android.api.responses.models.ErrorCodes
import com.thundermaps.apilib.android.api.responses.models.Failures
import com.thundermaps.apilib.android.api.responses.models.ResponseError
import com.thundermaps.apilib.android.api.responses.models.Sessions

@Suppress("unused")
object Data {
    val sessions = Sessions(
        "apiKey",
        true,
        439L,
        32902L,
        personalAccountOption = false,
        profileDetailsPending = false,
        passwordUpdatePending = false
    )

    val badCredentialsResponseError = ResponseError(
        errors = listOf("Please enter your email and password"),
        failures = Failures(listOf("Please enter your email and password")),
        errorCodes = ErrorCodes(listOf(ErrorCode("bad_credentials")))
    )

    val lockedAccountResponseError = ResponseError(
        errors = listOf("Locked account"),
        failures = Failures(listOf("Your account has been locked")),
        errorCodes = ErrorCodes(listOf(ErrorCode("account_locked")))
    )
}
