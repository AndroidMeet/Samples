package com.thundermaps.saferme.features.authentication.login

import com.thundermaps.saferme.R
import io.github.kakaocup.kakao.edit.KEditText
import io.github.kakaocup.kakao.edit.KTextInputLayout
import io.github.kakaocup.kakao.progress.KProgressBar
import io.github.kakaocup.kakao.screen.Screen
import io.github.kakaocup.kakao.text.KButton
import io.github.kakaocup.kakao.text.KTextView

class LoginScreen : Screen<LoginScreen>() {
    val progressView = KProgressBar { withId(R.id.progress_circular) }
    val emailInputLayout = KTextInputLayout { withId(R.id.email_input_layout) }
    val emailTextField = KEditText { withId(R.id.email_edittext) }
    val lockedTextView = KTextView { withId(R.id.locked_text) }
    val passwordInputLayout = KTextInputLayout { withId(R.id.password_input_layout) }
    val passwordTextField = KEditText { withId(R.id.password_edittext) }
    val loginButton = KButton { withText(R.string.login_button) }
    val loginSsoButton = KButton { withText(R.string.login_sso) }
    val forgotPasswordButton = KButton { withText(R.string.login_forgot_password) }
}
