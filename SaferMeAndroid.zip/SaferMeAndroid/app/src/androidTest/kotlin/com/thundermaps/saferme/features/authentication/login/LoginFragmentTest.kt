import androidx.navigation.Navigation
import androidx.navigation.testing.TestNavHostController
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.atLeast
import com.nhaarman.mockitokotlin2.doReturn
import com.nhaarman.mockitokotlin2.mock
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.verifyNoMoreInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.thundermaps.apilib.android.api.requests.models.SessionBody
import com.thundermaps.apilib.android.api.responses.models.Result
import com.thundermaps.saferme.R
import com.thundermaps.saferme.core.data.exceptions.SaferMeException
import com.thundermaps.saferme.features.authentication.login.LoginFragment
import com.thundermaps.saferme.features.authentication.login.LoginScreen
import com.thundermaps.saferme.features.authentication.login.domain.LoginRepository
import com.thundermaps.saferme.features.authentication.login.domain.di.LoginModule
import com.thundermaps.saferme.launchFragmentInHiltContainer
import com.thundermaps.saferme.testdata.Data.badCredentialsResponseError
import com.thundermaps.saferme.testdata.Data.sessions
import dagger.hilt.android.testing.BindValue
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.UninstallModules
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Ignore
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
@UninstallModules(LoginModule::class)
@MediumTest
@HiltAndroidTest
@ExperimentalCoroutinesApi
class LoginFragmentTest {
    @get:Rule
    var hiltRule = HiltAndroidRule(this)

    private val navController by lazy { TestNavHostController(ApplicationProvider.getApplicationContext()) }

    @BindValue
    val loginRepository = mock<LoginRepository>()

    private val loginScreen = LoginScreen()

    @Before
    fun setUp() {
        hiltRule.inject()
    }

    @After
    fun tearDown() {
        verifyNoMoreInteractions(loginRepository)
    }

    @Test
    @Ignore
    fun openLoginScreen() = runBlockingTest {
        launchLoginFragment()
        loginScreen {
            listOf(
                emailInputLayout,
                emailTextField,
                passwordInputLayout,
                passwordTextField,
                loginButton,
                loginSsoButton,
                forgotPasswordButton
            ).forEach {
                it.isVisible()
            }

            progressView.isGone()
            lockedTextView.isGone()
            emailTextField.containsText("")
            emailInputLayout.hasHint(R.string.login_email)

            passwordTextField.containsText("")
            passwordInputLayout.hasHint(R.string.login_password)

            loginButton.isDisabled()
            loginSsoButton.isEnabled()
            forgotPasswordButton.isEnabled()
        }

        commonVerifyRepository()
    }

    @Test
    fun verifyLockedAccount() = runBlockingTest {
        val userEmail = "abc@test.me"
        whenever(loginRepository.isAccountLocked(any())).doReturn(true)
        launchLoginFragment()

        loginScreen {
            emailTextField.typeText(userEmail)

            loginButton.isDisabled()

            lockedTextView.isVisible()
        }
        verify(loginRepository, atLeast(1)).isAccountLocked(any())
        commonVerifyRepository()
    }

    @Test
    fun verifyEnterCredentialsAndLoginSuccessThenNavigateToSelectTeam() = runBlockingTest {
        whenever(loginRepository.isAccountLocked(any())).doReturn(false)
        whenever(loginRepository.login(any())).doReturn(
            Result.Success(
                sessions.copy(
                    teamId = null
                )
            )
        )
        launchLoginFragment()

        verifyLogin(R.id.teamsFragment)
    }

    @Test
    fun verifyEnterCredentialsAndLoginSuccessThenNavigateToUpdatePassword() = runBlockingTest {
        whenever(loginRepository.isAccountLocked(any())).doReturn(false)
        whenever(loginRepository.login(any())).doReturn(
            Result.Success(
                sessions.copy(
                    passwordUpdatePending = true
                )
            )
        )
        launchLoginFragment()

        verifyLogin(R.id.updatePasswordFragment)
    }

    @Test
    fun verifyEnterCredentialsAndLoginSuccessThenNavigateToMainActivity() = runBlockingTest {

        whenever(loginRepository.isAccountLocked(any())).doReturn(false)
        whenever(loginRepository.login(any())).doReturn(Result.Success(sessions))
        launchLoginFragment()

        verifyLogin(R.id.mainActivity)
    }

    @Test
    fun verifyLoginWithBadCredentials() = runBlockingTest {
        whenever(loginRepository.isAccountLocked(any())).doReturn(false)
        whenever(loginRepository.login(any())).doReturn(
            Result.Error(
                null,
                SaferMeException(badCredentialsResponseError)
            )
        )
        launchLoginFragment()

        verifyLogin()

        loginScreen {
            emailInputLayout.hasError(R.string.login_email_or_password_incorrect)
            passwordInputLayout.hasError(R.string.login_email_or_password_incorrect)
        }
    }

    private fun processLogin() {
        loginScreen {
            emailTextField.typeText(USER_EMAIL)
            passwordTextField.typeText(PASSWORD)

            loginButton.isEnabled()

            loginButton.click()
        }
    }

    private suspend fun verifyLogin(targetString: Int? = null) {
        processLogin()

        val body = argumentCaptor<SessionBody>()
        verify(loginRepository).login(body.capture())
        assertEquals(USER_EMAIL, body.firstValue.user.email)
        assertEquals(PASSWORD, body.firstValue.user.password)
        if (targetString != null) {
            assertEquals(targetString, navController.currentDestination?.id)
        }
        verify(loginRepository, atLeast(1)).isAccountLocked(any())
        commonVerifyRepository()
    }

    private suspend fun commonVerifyRepository() {
        verify(loginRepository).syncBrand()
        verify(loginRepository).isStaging
        verify(loginRepository).getCacheSessions()
    }

    private fun launchLoginFragment() {
        launchFragmentInHiltContainer<LoginFragment> {
            (this as? LoginFragment)?.delayLauncherTime = 0
            navController.setGraph(R.navigation.authentication)
            navController.setCurrentDestination(R.id.loginFragment)
            Navigation.setViewNavController(requireView(), navController)
        }
    }

    companion object {
        private const val USER_EMAIL = "abc@test.me"
        private const val PASSWORD = "3Aye9$2932!A"
    }
}
