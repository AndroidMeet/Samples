package com.thundermaps.saferme.features.main.map

import com.thundermaps.saferme.R
import io.github.kakaocup.kakao.common.views.KView
import io.github.kakaocup.kakao.screen.Screen

@Suppress("unused")
class MapScreen : Screen<MapScreen>() {
    val mapView = KView { withId(R.id.map_view) }
}
