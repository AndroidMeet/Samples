import java.io.FileInputStream
import java.util.Properties

plugins {
    id(Config.PluginIds.android)
    id(Config.PluginIds.kotlinAndroid)
    id(Config.PluginIds.kapt)
    id(Config.PluginIds.jacoco)
    id(Config.PluginIds.hilt)
    id(Config.PluginIds.navigation)
    id(Config.PluginIds.kotlinParcelize)
    id(Config.PluginIds.googleService)
}

apply(from = "${rootProject.projectDir}/jacoco.gradle.kts")
tasks.getByName(Constants.JACOCO_DEBUG_TEST_REPORT) {
    dependsOn(
        Constants.TEST_SAFER_ME_DEBUG_UNIT_TEST,
        Constants.CONNECTED_SAFER_ME_DEBUG_ANDROID_TEST,
        Constants.CREATED_SAFER_ME_DEBUG_COVERAGE_REPORT
    )
}

val retrieveVersionName = if (project.hasProperty(Constants.VERSION_NAME)) {
    project.ext[Constants.VERSION_NAME].toString()
} else {
    Constants.DEFAULT_VERSION_NAME
}

val retrieveVersionCode = if (project.hasProperty(Constants.VERSION_CODE)) {
    project.ext[Constants.VERSION_CODE].toString().toInt()
} else {
    Constants.DEFAULT_VERSION_CODE
}

val keysPropertiesFile = rootProject.file("keys.properties")
val keysProperties = Properties()
keysProperties.load(FileInputStream(keysPropertiesFile))

android {
    val debug = "debug"
    val release = "release"
    val saferMe = "saferme"
    val smartoysters = "smartoysters"
    val stringType = "String"

    compileSdk = Versions.compileSdk

    defaultConfig {
        versionCode = retrieveVersionCode
        versionName = retrieveVersionName
        minSdk = Versions.minSdk
        targetSdk = Versions.targetSdk
        applicationId = Application.saferMeId
        testApplicationId = Application.testId
        testInstrumentationRunner = Constants.TEST_RUNNER
        vectorDrawables.useSupportLibrary = true
        val raygunKey = keysProperties.getProperty("raygunApiKey")
        buildConfigField(stringType, "RAYGUN_API_KEY", raygunKey)
        buildConfigField(
            stringType,
            "GOOGLE_GEOCODING_TOKEN",
            keysProperties.getProperty("googleGeocodingKey")
        )
        manifestPlaceholders["raygun_api_key"] = raygunKey

        ndk {
            abiFilters += listOf("x86", "x86_64", "armeabi-v7a", "arm64-v8a")
        }
    }

    signingConfigs {
        create(release) {
        }
    }

    testOptions {
        animationsDisabled = true

        unitTests.isIncludeAndroidResources = true
        unitTests.isReturnDefaultValues = true
    }

    buildTypes {
        getByName(release) {
            isDebuggable = false
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName(release)
            isTestCoverageEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            buildConfigField(
                stringType,
                "SEGMENT_KEY",
                keysProperties.getProperty("segmentReleaseKey")
            )
        }
        getByName(debug) {
            isMinifyEnabled = false
            isTestCoverageEnabled =
                project.ext[Constants.RETRIEVE_TEST_COVERAGE_ENABLED].toString().toBoolean()
            buildConfigField(
                stringType,
                "SEGMENT_KEY",
                keysProperties.getProperty("segmentDebugKey")
            )
            // Crashlytics properties for beta distribution
            ext {
                set("betaDistributionReleaseNotesFilePath", "releaseNotes.txt")
                set("betaDistributionGroupAliases", "RedBullTestTeam")
            }
        }
    }

    flavorDimensions.add("default")

    productFlavors {
        create(saferMe) {
            applicationId = Application.saferMeId
        }
        create(smartoysters) {
            applicationId = Application.smartOysters
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    lint {
        isAbortOnError = false
    }

    buildFeatures {
        dataBinding = true
        viewBinding = true
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_1_8.toString()
    }

    packagingOptions {
        resources.pickFirsts.add("**")
        resources.merges.add("**/attach_hotspot_windows.dll")
        resources.merges.add("META-INF/AL2.0")
        resources.merges.add("META-INF/LGPL2.1")
        resources.merges.add("META-INF/licenses/ASM")
    }
}

dependencies {
    implementation(Libraries.kotlinStdlib)

    implementation(Libraries.coreKtx)
    implementation(Libraries.appcompat)
    implementation(Libraries.material)
    implementation(Libraries.constraintLayout)

    implementation(Libraries.kotlinCoroutineAndroid)
    implementation(Libraries.lifecycleViewmodelKtx)
    implementation(Libraries.lifecycleRuntimeKtx)
    implementation(Libraries.lifecycleExtensions)
    implementation(Libraries.lifecycleCommonJava)
    implementation(Libraries.lifecycleLiveData)
    implementation(Libraries.viewpager2)
    implementation(Libraries.preferenceManager)
    implementation(Libraries.swipeRefresh)
    implementation(Libraries.webKit)
    implementation(Libraries.fcm)

    implementation(Libraries.timber)

    implementation(Libraries.room)
    implementation(Libraries.startup)
    kapt(Libraries.roomCompiler)

    implementation(Libraries.navigationFragmentKtx)
    implementation(Libraries.navigationUiKtx)
    implementation(Libraries.navigationRuntimeKtx)

    implementation(Libraries.hilt)
    kapt(Libraries.hiltCompiler)

    implementation(Libraries.obsidian)
    implementation(Libraries.saferMeApi)

    implementation(Libraries.zxcv)
    implementation(Libraries.raygun)

    implementation(Libraries.googleServicesLocation)
    implementation(Libraries.mapboxCore)
    implementation(Libraries.mapboxSdk)
    implementation(Libraries.mapboxSearch)
    implementation(Libraries.mapboxTurf)
    implementation(Libraries.geojson)

    implementation(Libraries.glide)
    kapt(Libraries.glideCompiler)

    implementation(Libraries.veil)
    implementation(Libraries.rangeSeekbar)
    implementation(Libraries.photoView)
    implementation(Libraries.signaturePad)
    implementation(Libraries.lottieAnimation)

    androidTestImplementation(TestLibraries.androidxJunit)
    androidTestImplementation(TestLibraries.androidxRunner)
    androidTestImplementation(TestLibraries.androidxTestRule)
    androidTestImplementation(TestLibraries.androidTestCore)
    androidTestImplementation(TestLibraries.espresso)
    androidTestImplementation(TestLibraries.kakao)
    androidTestImplementation(TestLibraries.hiltAndroidTest)
    kaptAndroidTest(TestLibraries.hiltAndroidCompiler)
    androidTestImplementation(TestLibraries.junit)
    androidTestImplementation(TestLibraries.kotlinCoroutineTest)
    androidTestImplementation(TestLibraries.mockitoAndroid)
    androidTestImplementation(TestLibraries.mockitoCore)
    androidTestImplementation(TestLibraries.mockitoKotlin2)
    androidTestImplementation(TestLibraries.navigationTest)

    debugImplementation(TestLibraries.fragmentTesting)

    testImplementation(TestLibraries.junit)
    testImplementation(TestLibraries.hamcrest)
    testImplementation(TestLibraries.archCoreTest)
    testImplementation(TestLibraries.hamcrestLibrary)
    testImplementation(TestLibraries.kotlinCoroutineTest)
    testImplementation(TestLibraries.mockitoCore)
    testImplementation(TestLibraries.mockitoKotlin2)
    testImplementation(TestLibraries.mockk)
}
